import { Bookmark, Check, ImageOff, MapPin, ShieldCheck, Star, Tag, Wrench } from 'lucide-react';
import { Link } from 'wouter';
import type { Listing, ServiceProfile } from '@workspace/api-client-react';
import { initials, listingTone, money, relativeDate } from '@/lib/format';

export function ListingVisual({ listing, large = false }: { listing: Listing; large?: boolean }) {
  return <div className={`relative flex ${large ? 'min-h-[250px] sm:min-h-[320px]' : 'h-[148px]'} items-center justify-center overflow-hidden rounded-[20px] ${listingTone(listing)}`}>
    <span className="absolute -right-10 -top-12 h-32 w-32 rounded-full border-[17px] border-white/30" />
    <span className="absolute -bottom-12 -left-8 h-28 w-28 rounded-full bg-white/20" />
    {listing.imageUrl ? <img src={listing.imageUrl} alt={listing.title} className="absolute inset-0 h-full w-full object-cover" data-testid={`img-listing-${listing.id}`} /> : <div className="relative grid h-20 w-20 place-items-center rounded-[24px] bg-white/60 text-secondary shadow-sm backdrop-blur"><span className="font-display text-lg font-bold tracking-[-.05em]">{listing.kind === 'service' ? <Wrench className="h-8 w-8" /> : <Tag className="h-8 w-8" />}</span></div>}
    <span className="absolute bottom-3 left-3 rounded-lg bg-white/75 px-2 py-1 text-[9px] font-bold uppercase tracking-[.13em] text-secondary backdrop-blur">{listing.kind === 'service' ? 'xizmat' : listing.condition === 'used' ? 'ishlatilgan' : 'mahsulot'}</span>
  </div>;
}

export function ListingCard({ listing, saved, onSave }: { listing: Listing; saved?: boolean; onSave?: () => void }) {
  return <article className="group overflow-hidden rounded-[22px] border border-border bg-card shadow-card transition duration-300 hover:-translate-y-1 hover:shadow-float" data-testid={`card-listing-${listing.id}`}>
    <div className="relative">
      <Link href={`/listings/${listing.id}`} data-testid={`link-listing-${listing.id}`}><ListingVisual listing={listing} /></Link>
      {onSave && <button type="button" onClick={onSave} aria-label={saved ? 'Saqlanganlardan olib tashlash' : 'Saqlash'} data-testid={`button-save-listing-${listing.id}`} className={`absolute right-3 top-3 grid h-9 w-9 place-items-center rounded-full transition active:scale-90 ${saved ? 'bg-[#fff0e8] text-primary' : 'bg-white/90 text-secondary'}`}><Bookmark className={`h-4 w-4 ${saved ? 'fill-current' : ''}`} /></button>}
    </div>
    <Link href={`/listings/${listing.id}`} data-testid={`link-listing-title-${listing.id}`} className="block p-3.5">
      <div className="flex items-start justify-between gap-2"><h3 className="line-clamp-2 min-h-[36px] font-display text-[14px] font-bold leading-tight tracking-[-.025em]">{listing.title}</h3><span className={`mt-1 h-2 w-2 shrink-0 rounded-full ${listing.kind === 'service' ? 'bg-[#5ca772]' : 'bg-primary'}`} /></div>
      <p className="mt-1.5 line-clamp-1 text-[11px] text-muted-foreground">{listing.category} · {listing.district}</p>
      <p className="mt-3 font-display text-[15px] font-bold text-primary" data-testid={`text-price-${listing.id}`}>{money(listing.price)}</p>
      <div className="mt-2.5 flex items-center gap-2 text-[10px] font-semibold text-muted-foreground"><span className="grid h-7 w-7 place-items-center rounded-full bg-[#d9ebe0] text-[9px] font-bold text-secondary">{initials(listing.sellerName)}</span><span className="truncate">{listing.sellerName}</span><span className="ml-auto shrink-0">{relativeDate(listing.createdAt)}</span></div>
    </Link>
  </article>;
}

export function ServiceCard({ service, saved, onSave }: { service: ServiceProfile; saved?: boolean; onSave?: () => void }) {
  return <article className="rounded-[22px] border border-border bg-card p-4 shadow-card transition hover:-translate-y-0.5 hover:shadow-float" data-testid={`card-service-${service.id}`}>
    <div className="flex items-start gap-3">
      <div className="grid h-12 w-12 shrink-0 place-items-center rounded-[16px] bg-[#ffe2d3] text-sm font-bold text-[#a94d2f]">{initials(service.name)}</div>
      <div className="min-w-0 flex-1"><div className="flex items-center gap-1.5"><h3 className="truncate font-display text-[15px] font-bold">{service.name}</h3>{service.verified && <ShieldCheck className="h-4 w-4 shrink-0 text-[#4c9b67]" />}</div><p className="mt-0.5 truncate text-xs font-medium text-muted-foreground">{service.title}</p><p className="mt-1.5 flex items-center gap-1 text-[10px] font-bold text-[#aa742c]"><Star className="h-3 w-3 fill-current" /> {service.rating.toFixed(1)} <span className="text-muted-foreground">· {service.district}</span></p></div>
      {onSave && <button type="button" onClick={onSave} aria-label={saved ? 'Saqlangan xizmatni olib tashlash' : 'Xizmatni saqlash'} data-testid={`button-save-service-${service.id}`} className={`grid h-8 w-8 shrink-0 place-items-center rounded-full ${saved ? 'bg-[#fff0e8] text-primary' : 'bg-muted text-muted-foreground'}`}><Bookmark className={`h-4 w-4 ${saved ? 'fill-current' : ''}`} /></button>}
    </div>
    <p className="mt-3 line-clamp-2 text-xs leading-5 text-muted-foreground" data-testid={`text-service-bio-${service.id}`}>{service.bio}</p>
    <div className="mt-3 flex flex-wrap gap-1.5">{service.skills.map((skill) => <span key={skill} className="rounded-md bg-[#eaf4ed] px-2 py-1 text-[10px] font-bold text-[#4c7f5b]">{skill}</span>)}</div>
    <div className="mt-4 flex items-center justify-between border-t border-border pt-3"><span className="flex items-center gap-1.5 text-[10px] font-semibold text-muted-foreground"><MapPin className="h-3.5 w-3.5 text-primary" /> {service.district}</span><a href={`tel:${service.phone}`} data-testid={`link-call-service-${service.id}`} className="rounded-xl bg-secondary px-3 py-2 text-[10px] font-bold text-white transition hover:bg-secondary/90">Bog‘lanish</a></div>
  </article>;
}

export function EmptyState({ title, description, action }: { title: string; description: string; action?: React.ReactNode }) {
  return <div className="rounded-[24px] border border-dashed border-[#c9d9cc] bg-[#f5faf4] px-5 py-10 text-center" data-testid="state-empty"><ImageOff className="mx-auto h-7 w-7 text-[#7ea58a]" /><h3 className="mt-3 font-display text-base font-bold text-secondary">{title}</h3><p className="mx-auto mt-1 max-w-xs text-xs leading-5 text-muted-foreground">{description}</p>{action && <div className="mt-4">{action}</div>}</div>;
}

export function ErrorState({ onRetry }: { onRetry: () => void }) {
  return <div className="rounded-[24px] border border-[#f1c9c0] bg-[#fff5f1] px-5 py-9 text-center" data-testid="state-error"><p className="font-display font-bold text-[#9c4234]">Ma’lumotlarni yuklab bo‘lmadi</p><p className="mt-1 text-xs text-[#a97468]">Internetni tekshirib, yana bir bor urinib ko‘ring.</p><button type="button" onClick={onRetry} data-testid="button-retry" className="mt-4 rounded-full bg-secondary px-4 py-2.5 text-xs font-bold text-white">Qayta urinish</button></div>;
}

export function ListingSkeleton() {
  return <div className="overflow-hidden rounded-[22px] border border-border bg-card p-2.5"><div className="skeleton h-[148px] rounded-[18px]" /><div className="space-y-2 p-2"><div className="skeleton h-4 w-4/5 rounded" /><div className="skeleton h-3 w-2/5 rounded" /><div className="skeleton h-4 w-1/2 rounded" /></div></div>;
}
import type { ReactNode } from 'react';
import { Bell, BriefcaseBusiness, Home, Plus, Search, UserRound } from 'lucide-react';
import { Link, useLocation } from 'wouter';

const nav = [
  { href: '/', label: 'Bosh sahifa', icon: Home },
  { href: '/listings', label: 'E’lonlar', icon: Search },
  { href: '/sell', label: 'E’lon berish', icon: Plus },
  { href: '/services', label: 'Xizmatlar', icon: BriefcaseBusiness },
  { href: '/profile', label: 'Profil', icon: UserRound },
];

export function AppShell({ children, title = 'Bozor Bot', compact = false }: { children: ReactNode; title?: string; compact?: boolean }) {
  const [location] = useLocation();
  return (
    <div className="noise min-h-[100dvh] bg-paper">
      <header className="sticky top-0 z-40 border-b border-border/70 bg-background/90 backdrop-blur-xl">
        <div className="mx-auto flex h-[68px] max-w-6xl items-center justify-between px-4 sm:px-6 lg:h-[76px]">
          <Link href="/" className="flex items-center gap-3" data-testid="link-brand">
            <span className="grid h-10 w-10 place-items-center rounded-[14px] bg-primary font-display text-xl font-bold text-primary-foreground shadow-[0_8px_20px_rgba(255,107,53,.22)]">B</span>
            <span className="hidden sm:block">
              <span className="block font-display text-[17px] font-bold tracking-[-.04em]">Bozor Bot</span>
              <span className="block text-[10px] font-bold uppercase tracking-[.14em] text-muted-foreground">Qoraqalpog‘iston bozori</span>
            </span>
          </Link>
          <div className="hidden items-center gap-1 lg:flex">
            {nav.slice(0, 2).map((item) => (
              <Link key={item.href} href={item.href} data-testid={`link-nav-${item.label}`} className={`rounded-full px-4 py-2 text-sm font-semibold transition hover:bg-muted ${location === item.href ? 'bg-muted text-secondary' : 'text-muted-foreground'}`}>
                {item.label}
              </Link>
            ))}
            <Link href="/services" data-testid="link-nav-services" className={`rounded-full px-4 py-2 text-sm font-semibold transition hover:bg-muted ${location === '/services' ? 'bg-muted text-secondary' : 'text-muted-foreground'}`}>Xizmatlar</Link>
          </div>
          <div className="flex items-center gap-2">
            <span className="hidden items-center gap-2 rounded-full bg-muted px-3 py-2 text-xs font-semibold text-muted-foreground md:flex"><span className="h-2 w-2 rounded-full bg-[#5ca772]" /> Nukus va atrofida</span>
            <button type="button" aria-label="Bildirishnomalar" data-testid="button-notifications" className="grid h-10 w-10 place-items-center rounded-full border border-border bg-card text-secondary transition hover:-translate-y-0.5 hover:border-primary"><Bell className="h-[17px] w-[17px]" /></button>
            <Link href="/sell" data-testid="link-header-sell" className="hidden items-center gap-2 rounded-full bg-secondary px-4 py-2.5 text-sm font-bold text-secondary-foreground transition hover:-translate-y-0.5 hover:bg-secondary/90 sm:flex"><Plus className="h-4 w-4" /> E’lon berish</Link>
          </div>
        </div>
      </header>
      <main className={`mx-auto max-w-6xl px-4 pb-28 pt-5 sm:px-6 lg:pb-12 lg:pt-8 ${compact ? '' : ''}`}>{children}</main>
      <nav className="fixed bottom-0 left-0 right-0 z-40 mx-auto flex h-[74px] max-w-6xl items-center justify-around border-t border-border/80 bg-background/95 px-2 backdrop-blur-xl lg:hidden">
        {nav.map((item) => {
          const active = item.href === '/' ? location === '/' : location.startsWith(item.href);
          const Icon = item.icon;
          return <Link key={item.href} href={item.href} data-testid={`link-mobile-${item.label}`} className={`relative flex min-w-[56px] flex-col items-center gap-1 rounded-2xl px-2 py-1.5 text-[10px] font-bold transition ${active ? 'text-primary' : 'text-muted-foreground'}`}>
            {item.href === '/sell' ? <span className="grid h-9 w-9 place-items-center rounded-[13px] bg-secondary text-white shadow-lg"><Icon className="h-5 w-5" /></span> : <Icon className={`h-5 w-5 ${active ? 'stroke-[2.5]' : ''}`} />}
            <span>{item.label}</span>
            {active && item.href !== '/sell' && <span className="absolute bottom-0 h-1 w-1 rounded-full bg-primary" />}
          </Link>;
        })}
      </nav>
    </div>
  );
}

export function SectionHeading({ eyebrow, title, action }: { eyebrow?: string; title: string; action?: ReactNode }) {
  return <div className="mb-4 flex items-end justify-between gap-3">
    <div>
      {eyebrow && <p className="mb-1 text-[10px] font-bold uppercase tracking-[.17em] text-primary">{eyebrow}</p>}
      <h2 className="font-display text-[22px] font-bold leading-tight tracking-[-.045em] text-foreground sm:text-[26px]">{title}</h2>
    </div>
    {action}
  </div>;
}

export function Notice({ children, tone = 'success' }: { children: ReactNode; tone?: 'success' | 'error' }) {
  return <div role="status" data-testid="status-notice" className={`flex items-center gap-2 rounded-2xl px-3.5 py-3 text-xs font-bold ${tone === 'success' ? 'bg-[#e9f5eb] text-[#39744c]' : 'bg-[#fff0ed] text-[#ae4435]'}`}>{children}</div>;
}
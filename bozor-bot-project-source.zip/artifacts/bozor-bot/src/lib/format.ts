import type { Listing } from '@workspace/api-client-react';

export function money(value?: number | null) {
  if (value === null || value === undefined) return 'Kelishiladi';
  return `${new Intl.NumberFormat('uz-UZ').format(value)} so‘m`;
}

export function initials(name = 'Bozor') {
  return name.split(/\s+/).filter(Boolean).slice(0, 2).map((part) => part[0]).join('').toUpperCase();
}

export function relativeDate(value: string) {
  const diff = Math.max(0, Date.now() - new Date(value).getTime());
  const minutes = Math.floor(diff / 60000);
  if (minutes < 1) return 'hozir';
  if (minutes < 60) return `${minutes} daqiqa oldin`;
  const hours = Math.floor(minutes / 60);
  if (hours < 24) return `${hours} soat oldin`;
  const days = Math.floor(hours / 24);
  return `${days} kun oldin`;
}

export function listingTone(listing: Listing) {
  const tones = ['tone-coral', 'tone-sage', 'tone-sand', 'tone-sky', 'tone-lilac'];
  return tones[listing.id % tones.length];
}
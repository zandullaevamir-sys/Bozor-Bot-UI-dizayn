import { createContext, type ReactNode, useContext, useEffect, useMemo, useRef, useState } from "react";
import { QueryClient, QueryClientProvider, useQueryClient } from "@tanstack/react-query";
import { Link, Route, Switch, useLocation, useRoute } from "wouter";
import {
  ArrowLeft,
  ArrowRight,
  BarChart3,
  Bookmark,
  BriefcaseBusiness,
  Check,
  ChevronDown,
  ChevronRight,
  CirclePlus,
  Megaphone,
  Grid2X2,
  Heart,
  Home,
  Hammer,
  ImagePlus,
  Loader2,
  Menu,
  MessageCircle,
  Package,
  Paintbrush,
  Phone,
  Search,
  Send,
  ShieldCheck,
  SlidersHorizontal,
  Sparkles,
  Star,
  Users,
  Wrench,
  Zap,
  UserRound,
  X,
} from "lucide-react";
import {
  getCurrentUser,
  getGetAdminStatsQueryKey,
  getListAdConversationsQueryKey,
  getListAdMessagesQueryKey,
  getGetMarketplaceSummaryQueryKey,
  setAuthTokenGetter,
  useAuthenticateTelegram,
  useCreateAdConversation,
  useCreateAdMessage,
  useGetAdminStats,
  useGetCurrentUser,
  getGetListingQueryKey,
  getListListingsQueryKey,
  getListServiceProfilesQueryKey,
  useCreateListing,
  useCreateServiceProfile,
  useGetListing,
  useGetMarketplaceSummary,
  useListDistricts,
  useListListings,
  useListServiceProfiles,
  useListAdConversations,
  useListAdMessages,
  type AdConversation,
  type Listing,
  type ServiceProfile,
} from "@workspace/api-client-react";
import { ErrorBoundary } from "@/components/error-boundary";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { useForm } from "react-hook-form";
import { toast } from "@/hooks/use-toast";
import NotFound from "@/pages/not-found";
import bozorBotLogo from "@/assets/bozor-bot-logo.png";
import "./index.css";

const queryClient = new QueryClient();

const SESSION_KEY = "bozor-bot-session";
type Language = "uz" | "ru" | "qr";

const languageNames: Record<Language, string> = {
  uz: "O‘ZB",
  ru: "РУС",
  qr: "QR",
};

const translations: Record<string, Record<Language, string>> = {
  "Bas bet": { uz: "Bosh sahifa", ru: "Главная", qr: "Bas bet" },
  Izlew: { uz: "Qidiruv", ru: "Поиск", qr: "Izlew" },
  Jaylastırıw: { uz: "Joylashtirish", ru: "Разместить", qr: "Jaylastırıw" },
  Xizmetler: { uz: "Xizmatlar", ru: "Услуги", qr: "Xizmetler" },
  "Akkaunt (Profil)": { uz: "Akkaunt (Profil)", ru: "Аккаунт (Профиль)", qr: "Akkaunt (Profil)" },
  "Jariya beriw": { uz: "E’lon berish", ru: "Подать объявление", qr: "Jariya beriw" },
  "Qaraqalpaqstan": { uz: "Qoraqalpog‘iston", ru: "Каракалпакстан", qr: "Qaraqalpaqstan" },
  Reklama: { uz: "Reklama", ru: "Реклама", qr: "Reklama" },
  "Premium jaylastırıw": { uz: "Premium joylashuv", ru: "Премиум-размещение", qr: "Premium jaylastırıw" },
  "Óz ónimińizdi usı jerde reklama qılıń.": { uz: "O‘z mahsulotingizni shu yerda reklama qiling.", ru: "Рекламируйте свой товар здесь.", qr: "Óz ónimińizdi usı jerde reklama qılıń." },
  Sheriklik: { uz: "Hamkorlik", ru: "Партнёрство", qr: "Sheriklik" },
  "Biznesińizdi tanıstırıń": { uz: "Biznesingizni taniting", ru: "Представьте свой бизнес", qr: "Biznesińizdi tanıstırıń" },
  "Qaraqalpaqstan boyınsha top dárejege shıǵıń.": { uz: "Qoraqalpog‘iston bo‘ylab yangi mijozlarga chiqing.", ru: "Привлекайте новых клиентов по всему Каракалпакстану.", qr: "Qaraqalpaqstan boyınsha top dárejege shıǵıń." },
  Usınıs: { uz: "Taklif", ru: "Предложение", qr: "Usınıs" },
  "Haptelik reklama": { uz: "Haftalik reklama", ru: "Еженедельная реклама", qr: "Haptelik reklama" },
  "Brendińiz bas bette turaqlı kórinip tursın.": { uz: "Brendingiz bosh sahifada doimiy ko‘rinib tursin.", ru: "Пусть ваш бренд всегда будет на главной странице.", qr: "Brendińiz bas bette turaqlı kórinip tursın." },
  Batafsil: { uz: "Batafsil", ru: "Подробнее", qr: "Tolıq maǵlıwmat" },
  "Reklama jaylastırıw": { uz: "Reklama joylashtirish", ru: "Разместить рекламу", qr: "Reklama jaylastırıw" },
  "Jańa ónimler": { uz: "Yangi mahsulotlar", ru: "Новые товары", qr: "Jańa ónimler" },
  "Hámmesin kóriw": { uz: "Hammasini ko‘rish", ru: "Смотреть все", qr: "Hámmesin kóriw" },
  "Barlıq ónimler": { uz: "Barcha mahsulotlar", ru: "Все товары", qr: "Barlıq ónimler" },
  "Eń jańa jariyalar": { uz: "Eng yangi e’lonlar", ru: "Новые объявления", qr: "Eń jańa jariyalar" },
  "Jariyalardı júklep bolmadı": { uz: "E’lonlarni yuklab bo‘lmadi", ru: "Не удалось загрузить объявления", qr: "Jariyalardı júklep bolmadı" },
  "Keyinirek qayta urınıp kóriń.": { uz: "Keyinroq qayta urinib ko‘ring.", ru: "Попробуйте ещё раз позже.", qr: "Keyinirek qayta urınıp kóriń." },
  "Ónimler joq": { uz: "Mahsulotlar yo‘q", ru: "Товаров нет", qr: "Ónimler joq" },
  "Házirshe ónim jariyaları jaylastırılmaǵan.": { uz: "Hozircha mahsulot e’lonlari joylanmagan.", ru: "Пока нет объявлений о товарах.", qr: "Házirshe ónim jariyaları jaylastırılmaǵan." },
  "Barlıq xizmetler": { uz: "Barcha xizmatlar", ru: "Все услуги", qr: "Barlıq xizmetler" },
  "Xizmet jariyaları": { uz: "Xizmat e’lonlari", ru: "Объявления об услугах", qr: "Xizmet jariyaları" },
  "Xizmetler joq": { uz: "Xizmatlar yo‘q", ru: "Услуг нет", qr: "Xizmetler joq" },
  "Jańa jaylastırıw": { uz: "Yangi joylashtirish", ru: "Новое размещение", qr: "Jańa jaylastırıw" },
  "Neni jaylastırmaqshısız?": { uz: "Nima joylashtirmoqchisiz?", ru: "Что вы хотите разместить?", qr: "Neni jaylastırmaqshısız?" },
  "Kerekli bólimdi tańlań.": { uz: "Kerakli bo‘limni tanlang.", ru: "Выберите нужный раздел.", qr: "Kerekli bólimdi tańlań." },
  "E’lon joylashtirish": { uz: "E’lon joylashtirish", ru: "Разместить объявление", qr: "Jariya jaylastırıw" },
  "Yangi yoki ishlatilgan mahsulotingizni soting.": { uz: "Yangi yoki ishlatilgan mahsulotingizni soting.", ru: "Продайте новый или бывший в употреблении товар.", qr: "Jańa yamasa paydalanılǵan ónimińizdi satıń." },
  "Xizmat joylashtirish": { uz: "Xizmat joylashtirish", ru: "Разместить услугу", qr: "Xizmet jaylastırıw" },
  "Ko‘nikmalaringiz va xizmatlaringizni taklif qiling.": { uz: "Ko‘nikmalaringiz va xizmatlaringizni taklif qiling.", ru: "Предложите свои навыки и услуги.", qr: "Kónlikpelerińiz hám xizmetlerińizdi usınıń." },
  "Xabar yozing…": { uz: "Xabar yozing…", ru: "Напишите сообщение…", qr: "Xabar jazıń…" },
  "Murojaat yuborildi": { uz: "Murojaat yuborildi", ru: "Обращение отправлено", qr: "Múrájáát jiberildi" },
  "Admin shu suhbatda javob beradi.": { uz: "Admin shu suhbatda javob beradi.", ru: "Администратор ответит в этом чате.", qr: "Admin usı súwbette juwap beredi." },
  "Reklama murojaati": { uz: "Reklama murojaati", ru: "Запрос на рекламу", qr: "Reklama múrájááti" },
  "Yangi murojaat yuboring yoki avvalgi suhbatni davom ettiring.": { uz: "Yangi murojaat yuboring yoki avvalgi suhbatni davom ettiring.", ru: "Отправьте новый запрос или продолжите предыдущий разговор.", qr: "Jańa múrájáát jiberiń yamasa aldıńǵı súwbetti dawam etiń." },
  "Reklama mavzusi": { uz: "Reklama mavzusi", ru: "Тема рекламы", qr: "Reklama teması" },
  "Taklifingizni yozing": { uz: "Taklifingizni yozing", ru: "Напишите ваше предложение", qr: "Usınısıńızdı jazıń" },
  "Murojaat yuborish": { uz: "Murojaat yuborish", ru: "Отправить запрос", qr: "Múrájáát jiberiw" },
  "Suhbat hali yo‘q": { uz: "Suhbat hali yo‘q", ru: "Пока нет чатов", qr: "Súwbet ele joq" },
  "Reklama bo‘yicha birinchi murojaatingizni yuboring.": { uz: "Reklama bo‘yicha birinchi murojaatingizni yuboring.", ru: "Отправьте первый запрос по рекламе.", qr: "Reklama boyınsha birinshi múrájáátińizdi jiberiń." },
  Marketplace: { uz: "Marketplace", ru: "Маркетплейс", qr: "Marketplace" },
  Jariyalar: { uz: "E’lonlar", ru: "Объявления", qr: "Jariyalar" },
  "Ónim yamasa xizmetti izleń.": { uz: "Mahsulot yoki xizmatni qidiring.", ru: "Ищите товары или услуги.", qr: "Ónim yamasa xizmetti izleń." },
  "Neni izlepatırsız?": { uz: "Nima qidiryapsiz?", ru: "Что вы ищете?", qr: "Neni izlepatırsız?" },
  "Barlıq aymaqlar": { uz: "Barcha hududlar", ru: "Все регионы", qr: "Barlıq aymaqlar" },
  Kategoriya: { uz: "Kategoriya", ru: "Категория", qr: "Kategoriya" },
  "Barlıq kategoriyalar": { uz: "Barcha kategoriyalar", ru: "Все категории", qr: "Barlıq kategoriyalar" },
  Holati: { uz: "Holati", ru: "Состояние", qr: "Jaǵdayı" },
  "Tazalaw": { uz: "Tozalash", ru: "Уборка", qr: "Tazalaw" },
  "Mos e’lon topilmadi": { uz: "Mos e’lon topilmadi", ru: "Подходящих объявлений не найдено", qr: "Mos jariya tabılmadı" },
  "Qidiruv yoki filtrlarni o‘zgartirib ko‘ring.": { uz: "Qidiruv yoki filtrlarni o‘zgartirib ko‘ring.", ru: "Измените поиск или фильтры.", qr: "Izlew yamasa filtrlerdi ózgertip kóriń." },
  "Filtrlarni tozalash": { uz: "Filtrlarni tozalash", ru: "Очистить фильтры", qr: "Filtrlerdi tazalaw" },
  "E’lon topilmadi": { uz: "E’lon topilmadi", ru: "Объявление не найдено", qr: "Jariya tabılmadı" },
  "Bu e’lon o‘chirilgan yoki mavjud emas.": { uz: "Bu e’lon o‘chirilgan yoki mavjud emas.", ru: "Это объявление удалено или недоступно.", qr: "Bul jariya óshirilgen yamasa ámelde joq." },
  "E’lonlarga qaytish": { uz: "E’lonlarga qaytish", ru: "Вернуться к объявлениям", qr: "Jariyalarǵa qaytıw" },
  "Barlıq jariyalar": { uz: "Barcha e’lonlar", ru: "Все объявления", qr: "Barlıq jariyalar" },
  "Ishlatilgan": { uz: "Ishlatilgan", ru: "Б/у", qr: "Paydalanılǵan" },
  Yangi: { uz: "Yangi", ru: "Новое", qr: "Jańa" },
  "Holati ko‘rsatilmagan": { uz: "Holati ko‘rsatilmagan", ru: "Состояние не указано", qr: "Jaǵdayı kórsetilmegen" },
  "Jariya avtorı": { uz: "E’lon muallifi", ru: "Автор объявления", qr: "Jariya avtorı" },
  "Qońıraw etiw": { uz: "Qo‘ng‘iroq qilish", ru: "Позвонить", qr: "Qońıraw etiw" },
  Baylanıs: { uz: "Aloqa", ru: "Контакты", qr: "Baylanıs" },
  "Satıwshı menen baylanısıw ushın telefon nomeri kórsetildi.": { uz: "Sotuvchi bilan bog‘lanish uchun telefon raqami ko‘rsatildi.", ru: "Номер продавца показан для связи.", qr: "Satıwshı menen baylanısıw ushın telefon nomeri kórsetildi." },
  Orqaga: { uz: "Orqaga", ru: "Назад", qr: "Artqa" },
  "Sotıw hám bólistiriw": { uz: "Sotish va ulashish", ru: "Продажа и размещение", qr: "Sotıw hám bólistiriw" },
  "Jańa jariya": { uz: "Yangi e’lon", ru: "Новое объявление", qr: "Jańa jariya" },
  "Maǵlıwmatlardı toltırıń hám Qaraqalpaqstan bazarına shıǵarıń.": { uz: "Ma’lumotlarni to‘ldiring va Qoraqalpog‘iston bozoriga chiqing.", ru: "Заполните данные и выходите на рынок Каракалпакстана.", qr: "Maǵlıwmatlardı toltırıń hám Qaraqalpaqstan bazarına shıǵarıń." },
  Ataması: { uz: "Sarlavha", ru: "Название", qr: "Ataması" },
  Súwret: { uz: "Rasm", ru: "Фото", qr: "Súwret" },
  "Súwret tańlaw": { uz: "Rasm tanlash", ru: "Выбрать фото", qr: "Súwret tańlaw" },
  "Boshqa rasm tanlash": { uz: "Boshqa rasm tanlash", ru: "Выбрать другое фото", qr: "Basqa súwret tańlaw" },
  "Olib tashlash": { uz: "Olib tashlash", ru: "Удалить", qr: "Óshiriw" },
  "Bitta rasm tanlang. Rasm avtomatik siqiladi.": { uz: "Bitta rasm tanlang. Rasm avtomatik siqiladi.", ru: "Выберите одно фото. Изображение будет сжато автоматически.", qr: "Bir súwret tańlań. Súwret avtomat túrde qısıladı." },
  "Jariya túri": { uz: "E’lon turi", ru: "Тип объявления", qr: "Jariya túri" },
  Ónim: { uz: "Mahsulot", ru: "Товар", qr: "Ónim" },
  "Baha (swm)": { uz: "Narx (so‘m)", ru: "Цена (сум)", qr: "Baha (swm)" },
  "Kelisilinedi bolsa bos qaldırıń": { uz: "Kelishiladi bo‘lsa bo‘sh qoldiring", ru: "Оставьте пустым, если цена договорная", qr: "Kelisilinedi bolsa bos qaldırıń" },
  "Jaǵdayı": { uz: "Holati", ru: "Состояние", qr: "Jaǵdayı" },
  "Rayon yamasa qala": { uz: "Tuman yoki shahar", ru: "Район или город", qr: "Rayon yamasa qala" },
  "Tańlań": { uz: "Tanlang", ru: "Выберите", qr: "Tańlań" },
  "Atıńız": { uz: "Ismingiz", ru: "Ваше имя", qr: "Atıńız" },
  "Telefon nomeri": { uz: "Telefon raqami", ru: "Номер телефона", qr: "Telefon nomeri" },
  Bayanat: { uz: "Tavsif", ru: "Описание", qr: "Bayanat" },
  Jariyalaw: { uz: "E’lonni joylash", ru: "Разместить объявление", qr: "Jariyalaw" },
  "E’lon joylandi": { uz: "E’lon joylandi", ru: "Объявление размещено", qr: "Jariya jaylastırıldı" },
  "E’loningiz marketplace’da ko‘rinmoqda.": { uz: "E’loningiz marketplace’da ko‘rinmoqda.", ru: "Ваше объявление опубликовано на маркетплейсе.", qr: "Jariyańız marketplace'te kórinip tur." },
  "Xizmatlar katalogi": { uz: "Xizmatlar katalogi", ru: "Каталог услуг", qr: "Xizmetler katalogı" },
  "Kerakli ustani toping": { uz: "Kerakli ustani toping", ru: "Найдите нужного мастера", qr: "Kerekli ustanı tabıń" },
  "Mahsulot emas, mahorat izlayotganlar uchun.": { uz: "Mahsulot emas, mahorat izlayotganlar uchun.", ru: "Для тех, кто ищет не товар, а мастерство.", qr: "Ónim emes, sheberlik izleytuǵınlar ushın." },
  "Xizmat profilini yaratish": { uz: "Xizmat profilini yaratish", ru: "Создать профиль услуги", qr: "Xizmet profilın jaratıw" },
  "Men ham xizmat ko‘rsataman": { uz: "Men ham xizmat ko‘rsataman", ru: "Я тоже оказываю услуги", qr: "Men de xizmet kórsetemen" },
  "Mos usta topilmadi": { uz: "Mos usta topilmadi", ru: "Подходящий мастер не найден", qr: "Mos usta tabılmadı" },
  "Qidiruv so‘zini yoki tuman filtrini o‘zgartirib ko‘ring.": { uz: "Qidiruv so‘zini yoki tuman filtrini o‘zgartirib ko‘ring.", ru: "Измените поисковый запрос или фильтр района.", qr: "Izlew sózin yamasa rayon filtrin ózgertip kóriń." },
  Paydalanıwshılar: { uz: "Foydalanuvchilar", ru: "Пользователи", qr: "Paydalanıwshılar" },
  Jariya: { uz: "E’lonlar", ru: "Объявления", qr: "Jariyalar" },
  Aymaqlar: { uz: "Hududlar", ru: "Регионы", qr: "Aymaqlar" },
  "Búgin": { uz: "Bugun", ru: "Сегодня", qr: "Búgin" },
  "Ruxsat yo‘q": { uz: "Ruxsat yo‘q", ru: "Нет доступа", qr: "Ruxsat joq" },
  "Admin panel": { uz: "Admin panel", ru: "Панель администратора", qr: "Admin panel" },
  "Janli statistika": { uz: "Jonli statistika", ru: "Статистика в реальном времени", qr: "Janli statistika" },
  "Bozor Bot boshqaruvi": { uz: "Bozor Bot boshqaruvi", ru: "Управление Bozor Bot", qr: "Bozor Bot basqarıwı" },
  "Sońǵı jariyalar": { uz: "So‘nggi e’lonlar", ru: "Последние объявления", qr: "Sońǵı jariyalar" },
  "Reklama murojaatlari": { uz: "Reklama murojaatlari", ru: "Запросы на рекламу", qr: "Reklama múrájáátleri" },
  "Hozircha murojaat yo‘q.": { uz: "Hozircha murojaat yo‘q.", ru: "Пока нет запросов.", qr: "Házirge múrájáát joq." },
  "Telegram orqali oching": { uz: "Telegram orqali oching", ru: "Откройте через Telegram", qr: "Telegram arqalı aşıń" },
  "Telefon raqamini yuborish uchun ilovani Telegram bot ichidan oching.": { uz: "Telefon raqamini yuborish uchun ilovani Telegram bot ichidan oching.", ru: "Откройте приложение внутри Telegram-бота, чтобы отправить номер.", qr: "Telefon nomerin jiberiw ushın qosımshanı Telegram bot ishinen aşıń." },
  "Kirish amalga oshmadi": { uz: "Kirish amalga oshmadi", ru: "Не удалось войти", qr: "Kiriw ámelge aspadı" },
  "Telegram ma’lumotlarini tekshirib bo‘lmadi.": { uz: "Telegram ma’lumotlarini tekshirib bo‘lmadi.", ru: "Не удалось проверить данные Telegram.", qr: "Telegram maǵlıwmatların tekseriw múmkin bolmadı." },
  "Telefon hali kelmadi": { uz: "Telefon hali kelmadi", ru: "Номер ещё не получен", qr: "Telefon ele kelmedi" },
  "Bir necha soniyadan keyin qayta urinib ko‘ring.": { uz: "Bir necha soniyadan keyin qayta urinib ko‘ring.", ru: "Попробуйте снова через несколько секунд.", qr: "Birneshe sekundtan keyin qayta urınıp kóriń." },
  "Davom etish uchun Telegram orqali telefon raqamingizni yuboring.": { uz: "Davom etish uchun Telegram orqali telefon raqamingizni yuboring.", ru: "Отправьте номер телефона через Telegram, чтобы продолжить.", qr: "Dawam etiw ushın Telegram arqalı telefon nomerińizdi jiberiń." },
  "Kutilmoqda…": { uz: "Kutilmoqda…", ru: "Ожидание…", qr: "Kútilmekte…" },
  "Raqamni yuborish": { uz: "Raqamni yuborish", ru: "Отправить номер", qr: "Nomerdı jiberiw" },
  "Raqam faqat akkauntni yaratish va e’lonlaringizni bog‘lash uchun ishlatiladi.": { uz: "Raqam faqat akkauntni yaratish va e’lonlaringizni bog‘lash uchun ishlatiladi.", ru: "Номер используется только для создания аккаунта и привязки объявлений.", qr: "Nomerińiz tek akkaunt jaratıw hám jariyalarıńızdı baylaw ushın isletiledi." },
  "Profil yaratildi": { uz: "Profil yaratildi", ru: "Профиль создан", qr: "Profil jaratıldı" },
  "Xizmatingiz katalogda ko‘rinadi.": { uz: "Xizmatingiz katalogda ko‘rinadi.", ru: "Ваша услуга отображается в каталоге.", qr: "Xizmetińiz katalogta kórinedi." },
  "Profilni joylash": { uz: "Profilni joylash", ru: "Разместить профиль", qr: "Profildi jaylastırıw" },
  "Saqlanǵanlar": { uz: "Saqlanganlar", ru: "Сохранённые", qr: "Saqlanǵanlar" },
  "Keyinirek kóriw ushın saqlaǵan jariyalarıńız.": { uz: "Keyinroq ko‘rish uchun saqlagan e’lonlaringiz.", ru: "Объявления, сохранённые для просмотра позже.", qr: "Keyinirek kóriw ushın saqlaǵan jariyalarıńız." },
  "Saqlanǵanlar joq": { uz: "Saqlanganlar yo‘q", ru: "Сохранённых нет", qr: "Saqlanǵanlar joq" },
  "Jaqqan jariyalarıńızdı saqlaw belgisi arqalı usı jerge qosıń.": { uz: "Yoqtirgan e’lonlaringizni saqlash belgisi orqali bu yerga qo‘shing.", ru: "Добавляйте понравившиеся объявления сюда с помощью значка сохранения.", qr: "Jaqqan jariyalarıńızdı saqlaw belgisi arqalı usı jerge qosıń." },
  "Profilge qaytıw": { uz: "Profilga qaytish", ru: "Вернуться в профиль", qr: "Profilge qaytıw" },
  "Something went wrong": { uz: "Xatolik yuz berdi", ru: "Произошла ошибка", qr: "Qátelik júz berdi" },
  "Ónimler": { uz: "Mahsulotlar", ru: "Товары", qr: "Ónimler" },
  "ta natija topildi": { uz: "ta natija topildi", ru: "результатов найдено", qr: "ta nátiyje tabıldı" },
  "API server ishlayotganini tekshirib, qayta urinib ko‘ring.": { uz: "API server ishlayotganini tekshirib, qayta urinib ko‘ring.", ru: "Проверьте работу API-сервера и попробуйте снова.", qr: "API server islep turǵanın tekserip, qayta urınıp kóriń." },
  Admin: { uz: "Admin", ru: "Администратор", qr: "Admin" },
  Xizmet: { uz: "Xizmat", ru: "Услуга", qr: "Xizmet" },
  "Rasm tanlanmadi": { uz: "Rasm tanlanmadi", ru: "Фото не выбрано", qr: "Súwret tańlanbadı" },
  "Faqat rasm faylini tanlang.": { uz: "Faqat rasm faylini tanlang.", ru: "Выберите только файл изображения.", qr: "Tek súwret faylın tańlań." },
  "Ataması kerek": { uz: "Sarlavha kiritish kerak", ru: "Введите название", qr: "Ataması kerek" },
  "Keminde 3 belgi": { uz: "Kamida 3 ta belgi", ru: "Минимум 3 символа", qr: "Keminde 3 belgi" },
  "Atıńızdı kiritiń": { uz: "Ismingizni kiriting", ru: "Введите имя", qr: "Atıńızdı kiritiń" },
  "Atı yamasa atama": { uz: "Ism yoki nom", ru: "Имя или название", qr: "Atı yamasa atama" },
  "Bayanat kerek": { uz: "Tavsif kiritish kerak", ru: "Введите описание", qr: "Bayanat kerek" },
  "Keminde 10 belgi": { uz: "Kamida 10 ta belgi", ru: "Минимум 10 символов", qr: "Keminde 10 belgi" },
  "Ónimińiz yamasa xizmetińiz haqqında jazıń...": { uz: "Mahsulotingiz yoki xizmatingiz haqida yozing...", ru: "Расскажите о товаре или услуге...", qr: "Ónimińiz yamasa xizmetińiz haqqında jazıń..." },
  "E’lon rasmi": { uz: "E’lon rasmi", ru: "Фото объявления", qr: "Jariya súwreti" },
  "E’lonni joylashda xatolik yuz berdi. Qayta urinib ko‘ring.": { uz: "E’lonni joylashda xatolik yuz berdi. Qayta urinib ko‘ring.", ru: "Не удалось разместить объявление. Попробуйте снова.", qr: "Jariyanı jaylastırıwda qátelik júz berdi. Qayta urınıp kóriń." },
  Kelisilinedi: { uz: "Kelishiladi", ru: "Договорная", qr: "Kelisilinedi" },
  Hámmesi: { uz: "Barchasi", ru: "Все", qr: "Hámmesi" },
  "Rasm": { uz: "Rasm", ru: "Фото", qr: "Súwret" },
  "Mening jariyalarım": { uz: "Mening e’lonlarim", ru: "Мои объявления", qr: "Mening jariyalarım" },
  Súwbetler: { uz: "Suhbatlar", ru: "Чаты", qr: "Súwbetler" },
  Pikirler: { uz: "Sharhlar", ru: "Отзывы", qr: "Pikirler" },
  "Bozor Bot paydalanıwshısı": { uz: "Bozor Bot foydalanuvchisi", ru: "Пользователь Bozor Bot", qr: "Bozor Bot paydalanıwshısı" },
  "(0 pikir)": { uz: "(0 sharh)", ru: "(0 отзывов)", qr: "(0 pikir)" },
  "Xizmatlarga qaytish": { uz: "Xizmatlarga qaytish", ru: "Вернуться к услугам", qr: "Xizmetlerge qaytıw" },
  "Ustalar katalogı": { uz: "Ustalar katalogi", ru: "Каталог мастеров", qr: "Ustalar katalogı" },
  "Xizmet profilıńiz": { uz: "Xizmat profilingiz", ru: "Ваш профиль услуги", qr: "Xizmet profilıńiz" },
  "Mijozlar sizni topishi uchun asosiy ma’lumotlarni yozing.": { uz: "Mijozlar sizni topishi uchun asosiy ma’lumotlarni yozing.", ru: "Укажите основные данные, чтобы клиенты могли вас найти.", qr: "Mijozlar sizdi tabıwı ushın tiykarǵı maǵlıwmatlardı jazıń." },
  "Atı kerek": { uz: "Ism kiritish kerak", ru: "Введите имя", qr: "Atı kerek" },
  Atı: { uz: "Ism", ru: "Имя", qr: "Atı" },
  "Atı hám familiyası": { uz: "Ism va familiya", ru: "Имя и фамилия", qr: "Atı hám familiyası" },
  "Xizmet atı kerek": { uz: "Xizmat nomi kerak", ru: "Введите название услуги", qr: "Xizmet atı kerek" },
  "Xizmet atı": { uz: "Xizmat nomi", ru: "Название услуги", qr: "Xizmet atı" },
  "Mısalı: Elektrik usta": { uz: "Masalan: Elektrik usta", ru: "Например: Электрик", qr: "Mısalı: Elektrik usta" },
  Telefon: { uz: "Telefon", ru: "Телефон", qr: "Telefon" },
  "Telefon kerek": { uz: "Telefon kerak", ru: "Введите телефон", qr: "Telefon kerek" },
  Kónlikpeler: { uz: "Ko‘nikmalar", ru: "Навыки", qr: "Kónlikpeler" },
  "Keminde bir kónlikpe kiritiń": { uz: "Kamida bitta ko‘nikma kiriting", ru: "Укажите хотя бы один навык", qr: "Keminde bir kónlikpe kiritiń" },
  "Elektrik, jarıqlıq, mayda ońlaw": { uz: "Elektrik, yoritish, mayda ta’mir", ru: "Электрика, освещение, мелкий ремонт", qr: "Elektrik, jarıqlıq, mayda ońlaw" },
  "Ózińiz haqqında jazıń": { uz: "O‘zingiz haqingizda yozing", ru: "Расскажите о себе", qr: "Ózińiz haqqında jazıń" },
  "Qısqasha maǵlıwmat": { uz: "Qisqacha ma’lumot", ru: "Краткая информация", qr: "Qısqasha maǵlıwmat" },
  "Tájiriybeńiz hám mijozlarǵa qanday járdem beriwińiz haqqında...": { uz: "Tajribangiz va mijozlarga qanday yordam berishingiz haqida...", ru: "Расскажите об опыте и помощи клиентам...", qr: "Tájiriybeńiz hám mijozlarǵa qanday járdem beriwińiz haqqında..." },
  "Profilni saqlashda xatolik yuz berdi.": { uz: "Profilni saqlashda xatolik yuz berdi.", ru: "Не удалось сохранить профиль.", qr: "Profildi saqlawda qátelik júz berdi." },
  "Admin panel faqat ruxsat berilgan Telegram administratorlari uchun.": { uz: "Admin panel faqat ruxsat berilgan Telegram administratorlari uchun.", ru: "Панель доступна только авторизованным администраторам Telegram.", qr: "Admin panel tek ruxsat berilgen Telegram administratorları ushın." },
};

let activeLanguage: Language = (localStorage.getItem("bozor-bot-language") as Language) || "qr";
const LanguageContext = createContext<{ language: Language; setLanguage: (language: Language) => void; t: (text: string) => string } | null>(null);
function translate(text: string) {
  return translations[text]?.[activeLanguage] ?? text;
}
function LanguageProvider({ children }: { children: ReactNode }) {
  const [language, setLanguageState] = useState<Language>(activeLanguage);
  const setLanguage = (next: Language) => {
    activeLanguage = next;
    localStorage.setItem("bozor-bot-language", next);
    setLanguageState(next);
  };
  return <LanguageContext.Provider value={{ language, setLanguage, t: translate }}>{children}</LanguageContext.Provider>;
}
function useLanguage() {
  const context = useContext(LanguageContext);
  if (!context) throw new Error("LanguageProvider is missing");
  return context;
}
function LanguageSwitcher() {
  const { language, setLanguage } = useLanguage();
  return <div className="flex items-center gap-0.5 rounded-full border border-[#e0e7dd] bg-white/80 p-1" aria-label="Language">
    {(Object.keys(languageNames) as Language[]).map((item) => <button key={item} type="button" onClick={() => setLanguage(item)} aria-pressed={language === item} className={`rounded-full px-2 py-1 text-[9px] font-black transition sm:px-2.5 ${language === item ? "bg-[#17211e] text-white" : "text-[#718078] hover:bg-[#eef4eb]"}`}>{languageNames[item]}</button>)}
  </div>;
}

const categories = ["Elektronika", "Uy-ro‘zg‘or", "Transport", "Bolalar", "Kiyim", "Uy ta’miri", "Tozalash", "Go‘zallik"];
const categoryTranslations: Record<string, Record<Language, string>> = {
  Elektronika: { uz: "Elektronika", ru: "Электроника", qr: "Elektronika" },
  "Uy-ro‘zg‘or": { uz: "Uy-ro‘zg‘or", ru: "Быт", qr: "Úy-turmıs" },
  Transport: { uz: "Transport", ru: "Транспорт", qr: "Transport" },
  Bolalar: { uz: "Bolalar", ru: "Детское", qr: "Balalar" },
  Kiyim: { uz: "Kiyim", ru: "Одежда", qr: "Kiyim" },
  "Uy ta’miri": { uz: "Uy ta’miri", ru: "Ремонт дома", qr: "Úy ońlawı" },
  Tozalash: { uz: "Tozalash", ru: "Уборка", qr: "Tazalaw" },
  "Go‘zallik": { uz: "Go‘zallik", ru: "Красота", qr: "Sulıwlıq" },
};
const districtTranslations: Record<string, Record<Language, string>> = {
  "Nukus shahri": { uz: "Nukus shahri", ru: "город Нукус", qr: "Nókis qalası" },
  "Nukus tumani": { uz: "Nukus tumani", ru: "Нукусский район", qr: "Nókis rayonı" },
  "Amudaryo tumani": { uz: "Amudaryo tumani", ru: "Амударьинский район", qr: "Ámiwdárya rayonı" },
  "Beruniy tumani": { uz: "Beruniy tumani", ru: "Берунийский район", qr: "Beruniy rayonı" },
  "Bo‘zatov tumani": { uz: "Bo‘zatov tumani", ru: "Бозатауский район", qr: "Bozataw rayonı" },
  "Chimboy tumani": { uz: "Chimboy tumani", ru: "Чимбайский район", qr: "Shımbay rayonı" },
  "Ellikqal’a tumani": { uz: "Ellikqal’a tumani", ru: "Элликкалинский район", qr: "Ellikqala rayonı" },
  "Kegeyli tumani": { uz: "Kegeyli tumani", ru: "Кегейлийский район", qr: "Kegeyli rayonı" },
  "Mo‘ynoq tumani": { uz: "Mo‘ynoq tumani", ru: "Муйнакский район", qr: "Moynaq rayonı" },
  "Qanliko‘l tumani": { uz: "Qanliko‘l tumani", ru: "Канлыкульский район", qr: "Qanlıkól rayonı" },
  "Qorao‘zak tumani": { uz: "Qorao‘zak tumani", ru: "Караузякский район", qr: "Qaraózek rayonı" },
  "Qo‘ng‘irot tumani": { uz: "Qo‘ng‘irot tumani", ru: "Кунградский район", qr: "Qońırat rayonı" },
  "Shumanay tumani": { uz: "Shumanay tumani", ru: "Шуманайский район", qr: "Shomanay rayonı" },
  "Taxtako‘pir tumani": { uz: "Taxtako‘pir tumani", ru: "Тахтакупырский район", qr: "Taxtakópir rayonı" },
  "Taxiatosh shahri": { uz: "Taxiatosh shahri", ru: "город Тахиаташ", qr: "Taqıyatas qalası" },
  "To‘rtko‘l tumani": { uz: "To‘rtko‘l tumani", ru: "Турткульский район", qr: "Tórtkúl rayonı" },
  "Xo‘jayli tumani": { uz: "Xo‘jayli tumani", ru: "Ходжейлийский район", qr: "Xojeli rayonı" },
};
const categoryLabels: Record<string, string> = {
  Tozalash: "Tazalaw",
};
const districtLabels: Record<string, string> = {
  "Nukus shahri": "Nókis qalası",
  "Nukus tumani": "Nókis rayonı",
  "Amudaryo tumani": "Ámiwdárya rayonı",
  "Beruniy tumani": "Beruniy rayonı",
  "Bo‘zatov tumani": "Bozataw rayonı",
  "Chimboy tumani": "Shımbay rayonı",
  "Ellikqal’a tumani": "Ellikqala rayonı",
  "Kegeyli tumani": "Kegeyli rayonı",
  "Mo‘ynoq tumani": "Moynaq rayonı",
  "Qanliko‘l tumani": "Qanlıkól rayonı",
  "Qorao‘zak tumani": "Qaraózek rayonı",
  "Qo‘ng‘irot tumani": "Qońırat rayonı",
  "Shumanay tumani": "Shomanay rayonı",
  "Taxtako‘pir tumani": "Taxtakópir rayonı",
  "Taxiatosh shahri": "Taqıyatas qalası",
  "To‘rtko‘l tumani": "Tórtkúl rayonı",
  "Xo‘jayli tumani": "Xojeli rayonı",
};
const conditionLabels: Record<string, string> = {
  any: "Hámmesi",
};
function translateCategory(value: string) {
  return categoryTranslations[value]?.[activeLanguage] ?? categoryLabels[value] ?? translate(value);
}
function translateDistrict(value: string) {
  return districtTranslations[value]?.[activeLanguage] ?? districtLabels[value] ?? translate(value);
}
function translateCondition(value: string) {
  if (value === "any" || value === "Hámmesi") return activeLanguage === "uz" ? "Barchasi" : activeLanguage === "ru" ? "Все" : "Hámmesi";
  return activeLanguage === "uz" ? (value === "Yangi" ? "Yangi" : "Ishlatilgan") : activeLanguage === "ru" ? (value === "Yangi" ? "Новое" : "Б/у") : (value === "Yangi" ? "Jańa" : "Paydalanılǵan");
}
const conditions = [
  { value: "any", label: "Hámmesi" },
  { value: "new", label: "Yangi" },
  { value: "used", label: "Ishlatilgan" },
];

function formatPrice(price: number | null | undefined) {
  if (price === null || price === undefined) return translate("Kelisilinedi");
  return `${new Intl.NumberFormat(activeLanguage === "ru" ? "ru-RU" : "uz-UZ").format(price)} ${activeLanguage === "ru" ? "сум" : activeLanguage === "uz" ? "so‘m" : "swm"}`;
}

function formatDate(value: string | Date) {
  return new Intl.DateTimeFormat(activeLanguage === "ru" ? "ru-RU" : activeLanguage === "uz" ? "uz-UZ" : "uz-UZ", { day: "numeric", month: "short" }).format(new Date(value));
}

function Shell({ children }: { children: ReactNode }) {
  const [location, setLocation] = useLocation();
  const { t } = useLanguage();
  const routeHistory = useRef<string[]>([location]);
  const nav = [
    { href: "/", label: t("Bas bet"), icon: Home },
    { href: "/listings", label: t("Izlew"), icon: Search },
    { href: "/create", label: t("Jaylastırıw"), icon: CirclePlus, primary: true },
    { href: "/services", label: t("Xizmetler"), icon: BriefcaseBusiness },
    { href: "/profile", label: t("Akkaunt (Profil)"), icon: UserRound },
  ];
  useEffect(() => {
    const lastRoute = routeHistory.current[routeHistory.current.length - 1];
    if (lastRoute !== location) routeHistory.current.push(location);
  }, [location]);
  useEffect(() => {
    const backButton = window.Telegram?.WebApp?.BackButton;
    if (!backButton) return;
    const goBack = () => {
      if (routeHistory.current.length > 1) {
        routeHistory.current.pop();
        setLocation(routeHistory.current[routeHistory.current.length - 1] ?? "/");
      } else if (location !== "/") {
        setLocation("/");
      }
    };
    if (location === "/") {
      backButton.hide();
    } else {
      backButton.show();
      backButton.onClick(goBack);
    }
    return () => {
      backButton.offClick(goBack);
      backButton.hide();
    };
  }, [location, setLocation]);
  return (
    <div className="flex h-[100dvh] flex-col overflow-hidden bg-[#f6f7f2] text-[#17211e]">
      <header className="shrink-0 sticky top-0 z-30 border-b border-[#e4e9e1]/80 bg-[#f6f7f2]/90 backdrop-blur-xl">
        <div className="mx-auto flex max-w-7xl items-center justify-between gap-5 px-4 py-4 sm:px-8">
          <Link href="/" className="flex items-center gap-3" data-testid="link-logo">
            <img src={bozorBotLogo} alt="Bozor Bot" className="h-11 w-11 object-contain drop-shadow-[0_8px_14px_rgba(255,107,53,0.2)]" />
            <span>
              <span className="block text-[15px] font-black tracking-[-0.03em]">Bozor Bot</span>
            <span className="block text-[10px] font-bold uppercase tracking-[0.18em] text-[#ff6b35]">{t("Qaraqalpaqstan")}</span>
            </span>
          </Link>
          <nav className="hidden items-center gap-1 rounded-full border border-[#e0e7dd] bg-white/70 p-1 md:flex">
            {nav.filter((item) => !item.primary).map((item) => {
              const Icon = item.icon;
              const active = item.href === "/" ? location === "/" : location.startsWith(item.href);
              return (
                <Link key={item.href} href={item.href} data-testid={`link-nav-${item.label.toLowerCase().replaceAll("’", "").replaceAll(" ", "-")}`} className={`flex items-center gap-2 rounded-full px-4 py-2 text-[12px] font-extrabold transition ${active ? "bg-[#17211e] text-white shadow-sm" : "text-[#718078] hover:bg-[#eef4eb]"}`}>
                  <Icon className="h-4 w-4" />
                  {item.label}
                </Link>
              );
            })}
          </nav>
          <div className="flex items-center gap-2">
            <LanguageSwitcher />
            <Link href="/sell" data-testid="link-create-listing" className="hidden items-center gap-2 rounded-full bg-[#ff6b35] px-4 py-2.5 text-[12px] font-black text-white shadow-[0_8px_18px_rgba(255,107,53,0.22)] transition hover:-translate-y-0.5 sm:flex">
              <CirclePlus className="h-4 w-4" /> {t("Jariya beriw")}
            </Link>
          </div>
          <button type="button" data-testid="button-mobile-menu" className="rounded-xl p-2 text-[#52645a] sm:hidden"><Menu className="h-5 w-5" /></button>
        </div>
      </header>
      <main className="mx-auto flex w-full max-w-7xl flex-1 flex-col overflow-y-auto px-4 pb-24 pt-4 sm:px-8 sm:pb-12">{children}</main>
      <nav className="fixed inset-x-3 bottom-3 z-30 flex justify-around rounded-2xl border border-[#e0e7dd] bg-white/95 p-2 shadow-[0_16px_38px_rgba(30,52,38,0.16)] backdrop-blur md:hidden">
        {nav.map((item) => {
          const Icon = item.icon;
          const active = item.href === "/" ? location === "/" : location.startsWith(item.href);
          return <Link key={item.href} href={item.href} data-testid={`mobile-nav-${item.href.slice(1) || "home"}`} className={item.primary
            ? "relative -mt-6 flex h-14 w-14 shrink-0 flex-col items-center justify-center rounded-full border-4 border-[#f6f7f2] bg-[#ff6b35] text-white shadow-[0_10px_24px_rgba(255,107,53,0.35)]"
            : `flex min-w-14 flex-col items-center gap-1 rounded-xl px-2 py-2 text-[9px] font-black ${active ? "bg-[#fff0e8] text-[#ff6b35]" : "text-[#8b9890]"}`}>
            <Icon className={item.primary ? "h-6 w-6" : "h-5 w-5"} /><span className="sr-only">{item.label}</span>
          </Link>;
        })}
      </nav>
    </div>
  );
}

function SectionHeading({ eyebrow, title, description, action }: { eyebrow?: string; title: string; description?: string; action?: ReactNode }) {
  return <div className="flex items-end justify-between gap-4">
    <div>
      {eyebrow && <p className="mb-2 text-[10px] font-black uppercase tracking-[0.2em] text-[#ff6b35]">{eyebrow}</p>}
      <h2 className="text-[26px] font-black tracking-[-0.06em] text-[#17211e] sm:text-[32px]">{title}</h2>
      {description && <p className="mt-2 max-w-xl text-sm leading-6 text-[#78867e]">{description}</p>}
    </div>
    {action}
  </div>;
}

function ListingVisual({ listing, large = false }: { listing: Listing; large?: boolean }) {
  const colors = listing.kind === "service" ? "from-[#d8efff] via-[#e7f6ff] to-[#f4fbff]" : "from-[#dceeff] via-[#edf7ff] to-[#f6fbff]";
  return <div className={`relative overflow-hidden bg-gradient-to-br ${colors} ${large ? "h-72 sm:h-[420px]" : "h-40"}`}>
    <div className="absolute -right-8 -top-8 h-36 w-36 rounded-full bg-white/30 blur-2xl" />
    {listing.imageUrl && <img src={listing.imageUrl} alt={listing.title} className="absolute inset-0 h-full w-full object-cover" data-testid={`img-listing-${listing.id}`} />}
    <Sparkles className="absolute right-5 top-5 h-6 w-6 text-white/80" />
  </div>;
}

function ListingCard({ listing, saved, onToggleSave }: { listing: Listing; saved: boolean; onToggleSave: (id: number) => void }) {
  return <article className="group overflow-hidden rounded-[24px] border border-[#e3e9e1] bg-white shadow-[0_8px_28px_rgba(39,64,47,0.05)] transition hover:-translate-y-1 hover:shadow-[0_18px_36px_rgba(39,64,47,0.12)]" data-testid={`card-listing-${listing.id}`}>
    <Link href={`/listings/${listing.id}`} data-testid={`link-listing-${listing.id}`}><ListingVisual listing={listing} /></Link>
    <div className="p-4">
      <div className="flex items-start justify-between gap-3">
        <Link href={`/listings/${listing.id}`} className="min-w-0" data-testid={`text-title-${listing.id}`}><h3 className="truncate text-[15px] font-black text-[#26372e] group-hover:text-[#ff6b35]">{listing.title}</h3></Link>
        <button type="button" aria-label="Saqlaw" data-testid={`button-save-${listing.id}`} onClick={() => onToggleSave(listing.id)} className={`rounded-xl p-2 transition ${saved ? "bg-[#fff0e8] text-[#ff6b35]" : "bg-[#f6f8f4] text-[#91a097] hover:text-[#ff6b35]"}`}><Bookmark className={`h-4 w-4 ${saved ? "fill-current" : ""}`} /></button>
      </div>
      <p className="mt-2 line-clamp-2 text-[12px] leading-5 text-[#849189]">{listing.description}</p>
      <div className="mt-4 flex items-end justify-between gap-2">
        <div><p className="text-[15px] font-black text-[#17211e]" data-testid={`text-price-${listing.id}`}>{formatPrice(listing.price)}</p><p className="mt-1 text-[10px] font-bold text-[#9aa59f]">{translateDistrict(listing.district)}</p></div>
        <span className="rounded-full bg-[#f0f5ee] px-2.5 py-1 text-[10px] font-black text-[#637269]">{formatDate(listing.createdAt)}</span>
      </div>
    </div>
  </article>;
}

function SmallProductCard({ listing }: { listing: Listing }) {
  return (
    <Link href={`/listings/${listing.id}`} data-testid={`small-card-listing-${listing.id}`} className="group flex h-[190px] w-[140px] shrink-0 snap-center flex-col overflow-hidden rounded-[20px] border border-[#e3e9e1] bg-white shadow-[0_4px_16px_rgba(39,64,47,0.04)] transition hover:-translate-y-0.5 hover:shadow-[0_8px_24px_rgba(39,64,47,0.08)]">
      <div className="relative h-[90px] w-full shrink-0 overflow-hidden bg-gradient-to-br from-[#dceeff] via-[#edf7ff] to-[#f6fbff] p-2">
        {listing.imageUrl && <img src={listing.imageUrl} alt={listing.title} className="absolute inset-0 h-full w-full object-cover" data-testid={`img-small-listing-${listing.id}`} />}
        <div className="absolute right-2 top-2 rounded-full border border-white/40 bg-white/60 px-1.5 py-0.5 text-[8.5px] font-black text-[#26372e] backdrop-blur">{formatDate(listing.createdAt)}</div>
      </div>
      <div className="flex flex-1 flex-col justify-between p-3">
        <h4 className="line-clamp-2 text-[11px] font-black leading-tight text-[#26372e] group-hover:text-[#ff6b35]">{listing.title}</h4>
        <div className="mt-1">
          <p className="text-[12px] font-black text-[#17211e]">{formatPrice(listing.price)}</p>
        </div>
      </div>
    </Link>
  );
}

function SmallServiceCard({ service }: { service: ServiceProfile }) {
  const Icon = getServiceIcon(service.category, service.title);
  return (
    <Link href={`/services`} data-testid={`small-card-service-${service.id}`} className="group flex h-[160px] w-[140px] shrink-0 snap-center flex-col overflow-hidden rounded-[20px] border border-[#e3e9e1] bg-white shadow-[0_4px_16px_rgba(39,64,47,0.04)] transition hover:-translate-y-0.5 hover:shadow-[0_8px_24px_rgba(39,64,47,0.08)]">
      <div className="relative flex h-[70px] w-full shrink-0 items-center justify-center bg-gradient-to-br from-[#d8efff] via-[#e7f6ff] to-[#f4fbff]">
        <div className="flex h-10 w-10 items-center justify-center rounded-[14px] bg-white text-[#52705b] shadow-sm"><Icon className="h-5 w-5" /></div>
      </div>
      <div className="flex flex-1 flex-col justify-between p-3">
        <div>
          <h4 className="truncate text-[11px] font-black text-[#26372e] group-hover:text-[#ff6b35]">{service.name}</h4>
          <p className="mt-0.5 truncate text-[9.5px] font-semibold text-[#7f8e84]">{service.title}</p>
        </div>
        <div className="mt-1 flex items-center justify-between">
          <p className="truncate pr-1 text-[9.5px] text-[#92a098]">{translateDistrict(service.district)}</p>
          <p className="shrink-0 text-[11px] font-black text-[#ff6b35]">{service.rating.toFixed(1)}</p>
        </div>
      </div>
    </Link>
  );
}

function getServiceIcon(category: string, title: string) {
  const value = `${category} ${title}`.toLowerCase();
  if (value.includes("elektr")) return Zap;
  if (value.includes("tozal")) return Paintbrush;
  if (value.includes("mebel") || value.includes("qurilish")) return Hammer;
  return Wrench;
}

function HomePage() {
  useLanguage();
  const { data: latestProducts, isLoading: productsLoading } = useListListings({ kind: "product", limit: 6, sort: "newest" });
  const { data: latestServices, isLoading: servicesLoading } = useListServiceProfiles({ limit: 6 });
  const productsRowRef = useRef<HTMLDivElement>(null);
  const servicesRowRef = useRef<HTMLDivElement>(null);
  const ads = [
    { eyebrow: translate("Reklama"), title: translate("Premium jaylastırıw"), description: translate("Óz ónimińizdi usı jerde reklama qılıń."), accent: "from-[#245b86] to-[#4d9bd2]" },
    { eyebrow: translate("Sheriklik"), title: translate("Biznesińizdi tanıstırıń"), description: translate("Qaraqalpaqstan boyınsha top dárejege shıǵıń."), accent: "from-[#316b9b] to-[#72b9e6]" },
    { eyebrow: translate("Usınıs"), title: translate("Haptelik reklama"), description: translate("Brendińiz bas bette turaqlı kórinip tursın."), accent: "from-[#2d6d98] to-[#6eb4db]" },
  ];
  const [activeAd, setActiveAd] = useState(0);

  useEffect(() => {
    productsRowRef.current?.scrollTo({ left: 0 });
  }, [latestProducts?.items.length]);

  useEffect(() => {
    servicesRowRef.current?.scrollTo({ left: 0 });
  }, [latestServices?.length]);

  useEffect(() => {
    if (ads.length <= 1) return;
    const timer = window.setInterval(() => setActiveAd((current) => (current + 1) % ads.length), 5000);
    return () => window.clearInterval(timer);
  }, [ads.length]);

  const ad = ads[activeAd];

  return (
    <div className="flex flex-col gap-4 pb-4 sm:gap-8">
      <div>
      <div className={`relative flex h-[130px] shrink-0 items-center overflow-hidden rounded-[24px] bg-gradient-to-br ${ad.accent} p-5 text-white transition-colors duration-700 sm:h-[160px] sm:p-8`} data-testid="ad-slot">
        <div className="absolute -right-10 -top-10 h-32 w-32 rounded-full bg-[#ff6b35]/30 blur-2xl" />
        <div className="absolute -bottom-10 right-10 h-24 w-24 rounded-full bg-[#d7e8b5]/20 blur-2xl" />
        <div className="relative z-10 flex w-full items-center justify-between">
          <div key={activeAd} className="animate-in fade-in slide-in-from-right-4 duration-500">
            <span className="mb-1.5 inline-block rounded-md border border-white/20 bg-white/10 px-2 py-0.5 text-[8.5px] font-black uppercase tracking-widest text-[#ff9a73]">{ad.eyebrow}</span>
            <h2 className="max-w-[190px] text-[22px] font-black leading-[1.1] tracking-[-0.04em] sm:text-3xl">{ad.title}</h2>
            <p className="mt-1.5 max-w-[190px] text-[10px] leading-relaxed text-[#d4ded5] sm:text-xs">{ad.description}</p>
          </div>
          <Link href="/advertise" data-testid="link-ad-cta" className="rounded-full bg-[#ff6b35] px-4 py-2.5 text-[10.5px] font-black text-white shadow-[0_8px_16px_rgba(255,107,53,0.3)] transition hover:-translate-y-0.5 sm:px-6 sm:py-3 sm:text-xs">
            Batafsil
          </Link>
        </div>
        {ads.length > 1 && <div className="absolute bottom-2.5 right-5 z-10 flex gap-1">{ads.map((_, index) => <button key={index} type="button" aria-label={`${index + 1}-reklama`} onClick={() => setActiveAd(index)} className={`h-1.5 rounded-full transition-all ${index === activeAd ? "w-4 bg-[#ff6b35]" : "w-1.5 bg-white/45"}`} />)}</div>}
      </div>
      <Link href="/advertise" data-testid="link-place-ad" className="mx-auto mt-1.5 flex w-fit items-center gap-1.5 text-[9.5px] font-black text-[#ff6b35]"><Megaphone className="h-3.5 w-3.5" /> {translate("Reklama jaylastırıw")}</Link>
      </div>

      <div className="flex flex-col gap-3">
        <h3 className="text-[15px] font-black tracking-tight text-[#17211e] sm:text-lg">{translate("Jańa ónimler")}</h3>
        <div ref={productsRowRef} className="hide-scrollbar -mx-4 flex gap-3 overflow-x-auto px-4 pb-2 snap-x snap-mandatory sm:mx-0 sm:px-0">
          {productsLoading ? (
            Array.from({ length: 4 }).map((_, i) => <div key={i} className="h-[190px] w-[140px] shrink-0 animate-pulse rounded-[20px] bg-[#e4e9e1]" />)
          ) : (
            latestProducts?.items.map(p => <SmallProductCard key={p.id} listing={p} />)
          )}
          <Link href="/products" data-testid="link-see-all-products" className="flex h-[190px] w-[110px] shrink-0 snap-center flex-col items-center justify-center gap-3 rounded-[20px] border border-[#e3e9e1] bg-[#f6f8f4] text-[#ff6b35] transition hover:bg-[#fff0e8]">
            <span className="flex h-10 w-10 items-center justify-center rounded-full bg-white shadow-sm">
              <ArrowRight className="h-5 w-5" />
            </span>
            <span className="text-[10px] font-black">{translate("Hámmesin kóriw")}</span>
          </Link>
        </div>
      </div>

      <div className="flex flex-col gap-3">
        <h3 className="text-[15px] font-black tracking-tight text-[#17211e] sm:text-lg">{translate("Xizmetler")}</h3>
        <div ref={servicesRowRef} className="hide-scrollbar -mx-4 flex gap-3 overflow-x-auto px-4 pb-2 snap-x snap-mandatory sm:mx-0 sm:px-0">
          {servicesLoading ? (
            Array.from({ length: 4 }).map((_, i) => <div key={i} className="h-[160px] w-[140px] shrink-0 animate-pulse rounded-[20px] bg-[#e4e9e1]" />)
          ) : (
            latestServices?.map(s => <SmallServiceCard key={s.id} service={s} />)
          )}
          <Link href="/all-services" data-testid="link-see-all-services" className="flex h-[160px] w-[110px] shrink-0 snap-center flex-col items-center justify-center gap-3 rounded-[20px] border border-[#e3e9e1] bg-[#f6f8f4] text-[#ff6b35] transition hover:bg-[#fff0e8]">
            <span className="flex h-10 w-10 items-center justify-center rounded-full bg-white shadow-sm">
              <ArrowRight className="h-5 w-5" />
            </span>
            <span className="text-[10px] font-black">{translate("Hámmesin kóriw")}</span>
          </Link>
        </div>
      </div>
    </div>
  );
}

function ProductsPage() {
  useLanguage();
  const { data, isLoading, isError } = useListListings({ kind: "product", limit: 50, sort: "newest" });
  const [saved, setSaved] = useSaved();
  return <div className="space-y-6"><div><p className="mb-2 text-[10px] font-black uppercase tracking-[0.2em] text-[#ff6b35]">{translate("Barlıq ónimler")}</p><h1 className="text-3xl font-black tracking-[-0.06em]">{translate("Eń jańa jariyalar")}</h1></div>{isError ? <EmptyState title={translate("Jariyalardı júklep bolmadı")} description={translate("Keyinirek qayta urınıp kóriń.")} /> : isLoading ? <LoadingGrid count={8} /> : data?.items.length ? <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">{data.items.map((listing) => <ListingCard key={listing.id} listing={listing} saved={saved.includes(listing.id)} onToggleSave={(id) => setSaved((current) => current.includes(id) ? current.filter((item) => item !== id) : [...current, id])} />)}</div> : <EmptyState title={translate("Ónimler joq")} description={translate("Házirshe ónim jariyaları jaylastırılmaǵan.")} />}</div>;
}

function AllServicesPage() {
  useLanguage();
  const { data, isLoading } = useListServiceProfiles({ limit: 50 });
  return <div className="space-y-6"><div><p className="mb-2 text-[10px] font-black uppercase tracking-[0.2em] text-[#ff6b35]">{translate("Barlıq xizmetler")}</p><h1 className="text-3xl font-black tracking-[-0.06em]">{translate("Xizmet jariyaları")}</h1></div>{isLoading ? <LoadingGrid count={6} /> : data?.length ? <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">{data.map((service) => <ServiceCard key={service.id} service={service} />)}</div> : <EmptyState title={translate("Xizmetler joq")} description={translate("Házirshe xizmet jariyaları jaylastırılmaǵan.")} />}</div>;
}

function CreatePage() {
  useLanguage();
  return <div className="mx-auto w-full max-w-xl space-y-6"><div className="text-center"><p className="mb-2 text-[10px] font-black uppercase tracking-[0.2em] text-[#ff6b35]">{translate("Jańa jaylastırıw")}</p><h1 className="text-3xl font-black tracking-[-0.06em]">{translate("Neni jaylastırmaqshısız?")}</h1><p className="mt-2 text-sm text-[#7b8981]">{translate("Kerekli bólimdi tańlań.")}</p></div><div className="grid gap-4 sm:grid-cols-2"><Link href="/sell" data-testid="link-create-product" className="rounded-[28px] border border-[#e3e9e1] bg-white p-6 shadow-sm transition hover:-translate-y-1"><span className="flex h-12 w-12 items-center justify-center rounded-2xl bg-[#fff0e8] text-[#ff6b35]"><Package className="h-6 w-6" /></span><h2 className="mt-5 text-xl font-black">{translate("E’lon joylashtirish")}</h2><p className="mt-2 text-xs leading-5 text-[#7b8981]">{translate("Yangi yoki ishlatilgan mahsulotingizni soting.")}</p></Link><Link href="/services/new" data-testid="link-create-service" className="rounded-[28px] border border-[#e3e9e1] bg-white p-6 shadow-sm transition hover:-translate-y-1"><span className="flex h-12 w-12 items-center justify-center rounded-2xl bg-[#e7f4e8] text-[#52705b]"><BriefcaseBusiness className="h-6 w-6" /></span><h2 className="mt-5 text-xl font-black">{translate("Xizmat joylashtirish")}</h2><p className="mt-2 text-xs leading-5 text-[#7b8981]">{translate("Ko‘nikmalaringiz va xizmatlaringizni taklif qiling.")}</p></Link></div></div>;
}

function ConversationChat({ conversation }: { conversation: AdConversation }) {
  useLanguage();
  const [body, setBody] = useState("");
  const client = useQueryClient();
  const { data: currentUser } = useGetCurrentUser();
  const { data: messages, isLoading } = useListAdMessages(conversation.id, { query: { queryKey: getListAdMessagesQueryKey(conversation.id), refetchInterval: 4000 } });
  const send = useCreateAdMessage();
  const submit = (event: React.FormEvent) => {
    event.preventDefault();
    const message = body.trim();
    if (!message) return;
    send.mutate({ id: conversation.id, data: { body: message } }, {
      onSuccess: () => {
        setBody("");
        client.invalidateQueries({ queryKey: getListAdMessagesQueryKey(conversation.id) });
        client.invalidateQueries({ queryKey: getListAdConversationsQueryKey() });
      },
    });
  };
  return <div className="flex min-h-[420px] flex-col rounded-[24px] border border-[#e3e9e1] bg-white">
    <div className="border-b border-[#edf1eb] p-4"><p className="text-sm font-black">{conversation.subject}</p><p className="mt-1 text-[10px] text-[#849189]">{conversation.userName}</p></div>
    <div className="flex-1 space-y-3 overflow-y-auto p-4">
      {isLoading ? <LoadingList /> : messages?.map((message) => {
        const mine = message.senderId === currentUser?.id;
        return <div key={message.id} className={`flex ${mine ? "justify-end" : "justify-start"}`}><div className={`max-w-[82%] rounded-2xl px-4 py-3 ${mine ? "bg-[#17211e] text-white" : "bg-[#f0f5ee] text-[#26372e]"}`}><p className="mb-1 text-[9px] font-black opacity-60">{message.senderIsAdmin ? translate("Admin") : message.senderName}</p><p className="text-xs leading-5">{message.body}</p></div></div>;
      })}
    </div>
    <form onSubmit={submit} className="flex gap-2 border-t border-[#edf1eb] p-3"><input value={body} onChange={(event) => setBody(event.target.value)} maxLength={2000} placeholder={translate("Xabar yozing…")} className="field-input flex-1" /><button type="submit" disabled={send.isPending || !body.trim()} className="rounded-xl bg-[#ff6b35] px-4 text-white disabled:opacity-50"><Send className="h-4 w-4" /></button></form>
  </div>;
}
function AdvertisePage() {
  useLanguage();
  const [subject, setSubject] = useState("");
  const [message, setMessage] = useState("");
  const [selectedId, setSelectedId] = useState<number | null>(() => {
    const value = Number(new URLSearchParams(window.location.search).get("conversation"));
    return Number.isSafeInteger(value) && value > 0 ? value : null;
  });
  const client = useQueryClient();
  const { data: conversations, isLoading } = useListAdConversations({ query: { queryKey: getListAdConversationsQueryKey(), refetchInterval: 5000 } });
  const create = useCreateAdConversation();
  const selected = conversations?.find((item) => item.id === selectedId) ?? conversations?.[0];
  const selectConversation = (id: number) => {
    setSelectedId(id);
    const url = new URL(window.location.href);
    url.searchParams.set("conversation", String(id));
    window.history.replaceState(null, "", `${url.pathname}${url.search}${url.hash}`);
  };
  const submit = (event: React.FormEvent) => {
    event.preventDefault();
    create.mutate({ data: { subject, message } }, { onSuccess: (conversation) => {
      setSubject(""); setMessage(""); selectConversation(conversation.id);
      client.invalidateQueries({ queryKey: getListAdConversationsQueryKey() });
       toast({ title: translate("Murojaat yuborildi"), description: translate("Admin shu suhbatda javob beradi.") });
    } });
  };
  return <div className="mx-auto grid w-full max-w-5xl gap-5 lg:grid-cols-[320px_1fr]">
     <section className="rounded-[28px] border border-[#e3e9e1] bg-white p-5 shadow-sm"><span className="flex h-12 w-12 items-center justify-center rounded-2xl bg-[#fff0e8] text-[#ff6b35]"><Megaphone className="h-6 w-6" /></span><h1 className="mt-4 text-2xl font-black">{translate("Reklama murojaati")}</h1><p className="mt-2 text-xs leading-5 text-[#7b8981]">{translate("Yangi murojaat yuboring yoki avvalgi suhbatni davom ettiring.")}</p>
       <form onSubmit={submit} className="mt-5 space-y-3"><input value={subject} onChange={(event) => setSubject(event.target.value)} minLength={3} maxLength={120} required placeholder={translate("Reklama mavzusi")} className="field-input w-full" /><textarea value={message} onChange={(event) => setMessage(event.target.value)} required maxLength={2000} rows={4} placeholder={translate("Taklifingizni yozing")} className="field-input w-full resize-y" /><button type="submit" disabled={create.isPending} className="w-full rounded-xl bg-[#ff6b35] py-3 text-xs font-black text-white disabled:opacity-50">{translate("Murojaat yuborish")}</button></form>
      <div className="mt-6 space-y-2">{isLoading ? <LoadingList /> : conversations?.map((conversation) => <button key={conversation.id} type="button" onClick={() => selectConversation(conversation.id)} className={`w-full rounded-xl border p-3 text-left ${selected?.id === conversation.id ? "border-[#ff6b35] bg-[#fff8f4]" : "border-[#e7ede5]"}`}><p className="truncate text-xs font-black">{conversation.subject}</p><p className="mt-1 text-[9px] text-[#849189]">{formatDate(conversation.updatedAt)}</p></button>)}</div>
    </section>
     {selected ? <ConversationChat conversation={selected} /> : <EmptyState title={translate("Suhbat hali yo‘q")} description={translate("Reklama bo‘yicha birinchi murojaatingizni yuboring.")} />}
  </div>;
}

function ListingsPage() {
  useLanguage();
  const [search, setSearch] = useState("");
  const [query, setQuery] = useState("");
  const [kind, setKind] = useState<"product" | "service" | undefined>();
  const [district, setDistrict] = useState("");
  const [category, setCategory] = useState("");
  const [condition, setCondition] = useState<"any" | "new" | "used">("any");
  const { data: districts } = useListDistricts();
  const params = useMemo(() => ({ q: query || undefined, kind, district: district || undefined, category: category || undefined, condition, limit: 24, sort: "newest" as const }), [query, kind, district, category, condition]);
  const { data, isLoading, isError } = useListListings(params);
  const [saved, setSaved] = useSaved();
  return <div className="space-y-8">
      <div className="flex flex-col justify-between gap-5 sm:flex-row sm:items-end"><div><p className="mb-2 text-[10px] font-black uppercase tracking-[0.2em] text-[#ff6b35]">{translate("Marketplace")}</p><h1 className="text-4xl font-black tracking-[-0.07em]">{translate("Jariyalar")}</h1><p className="mt-2 text-sm text-[#7b8981]">{translate("Ónim yamasa xizmetti izleń.")}</p></div><form onSubmit={(event) => { event.preventDefault(); setQuery(search); }} className="flex w-full max-w-md items-center gap-2 rounded-2xl border border-[#dfe7dc] bg-white p-2 shadow-sm"><Search className="ml-2 h-4 w-4 text-[#91a097]" /><input value={search} onChange={(event) => setSearch(event.target.value)} data-testid="input-search-listings" placeholder={translate("Neni izlepatırsız?")} className="min-w-0 flex-1 bg-transparent px-2 py-2 text-sm font-semibold outline-none placeholder:text-[#a6b0aa]" /><button type="submit" data-testid="button-search-listings" className="rounded-xl bg-[#17211e] px-4 py-2 text-xs font-black text-white">{translate("Izlew")}</button></form></div>
      <div className="flex flex-wrap gap-2"><FilterPill active={!kind} onClick={() => setKind(undefined)} testId="filter-all">{translate("Hámmesi")}</FilterPill><FilterPill active={kind === "product"} onClick={() => setKind("product")} testId="filter-products"><Package className="h-3.5 w-3.5" /> {translate("Ónimler")}</FilterPill><FilterPill active={kind === "service"} onClick={() => setKind("service")} testId="filter-services"><BriefcaseBusiness className="h-3.5 w-3.5" /> {translate("Xizmetler")}</FilterPill></div>
      <div className="grid gap-3 rounded-[22px] border border-[#e4eae1] bg-white p-4 md:grid-cols-[1fr_1fr_1fr_auto]"><SelectField label={translate("Rayon yamasa qala")} value={district} onChange={setDistrict} options={[{ value: "", label: translate("Barlıq aymaqlar") }, ...(districts ?? []).map((item) => ({ value: item.name, label: translateDistrict(item.name) }))]} testId="select-filter-district" /><SelectField label={translate("Kategoriya")} value={category} onChange={setCategory} options={[{ value: "", label: translate("Barlıq kategoriyalar") }, ...categories.map((item) => ({ value: item, label: translateCategory(item) }))]} testId="select-filter-category" /><SelectField label={translate("Holati")} value={condition} onChange={(value) => setCondition(value as "any" | "new" | "used")} options={conditions.map((item) => ({ ...item, label: translateCondition(item.label) }))} testId="select-filter-condition" /><button type="button" data-testid="button-reset-filters" onClick={() => { setDistrict(""); setCategory(""); setCondition("any"); setKind(undefined); setSearch(""); setQuery(""); }} className="self-end rounded-xl border border-[#e0e8df] px-4 py-3 text-xs font-black text-[#738178] hover:bg-[#f5f8f3]"><SlidersHorizontal className="mr-1 inline h-4 w-4" /> {translate("Tazalaw")}</button></div>
      {isError ? <EmptyState title={translate("Jariyalardı júklep bolmadı")} description={translate("API server ishlayotganini tekshirib, qayta urinib ko‘ring.")} /> : isLoading ? <LoadingGrid count={8} /> : data?.items.length ? <><p className="text-xs font-bold text-[#849189]">{data.total} {translate("ta natija topildi")}</p><div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">{data.items.map((listing) => <ListingCard key={listing.id} listing={listing} saved={saved.includes(listing.id)} onToggleSave={(id) => setSaved((current) => current.includes(id) ? current.filter((item) => item !== id) : [...current, id])} />)}</div></> : <EmptyState title={translate("Mos e’lon topilmadi")} description={translate("Qidiruv yoki filtrlarni o‘zgartirib ko‘ring.")} action={<button type="button" data-testid="button-clear-empty-filters" onClick={() => { setDistrict(""); setCategory(""); setCondition("any"); setKind(undefined); setSearch(""); setQuery(""); }} className="rounded-full bg-[#17211e] px-4 py-2 text-xs font-black text-white">{translate("Filtrlarni tozalash")}</button>} />}
  </div>;
}

function ListingDetailPage() {
  useLanguage();
  const [, params] = useRoute("/listings/:id");
  const id = Number(params?.id);
  const { data: listing, isLoading, isError } = useGetListing(id, { query: { enabled: Number.isFinite(id), queryKey: getGetListingQueryKey(id) } });
  const [saved, setSaved] = useSaved();
  if (isLoading) return <LoadingPanel />;
  if (isError || !listing) return <EmptyState title={translate("E’lon topilmadi")} description={translate("Bu e’lon o‘chirilgan yoki mavjud emas.")} action={<Link href="/listings" data-testid="link-back-listings" className="rounded-full bg-[#17211e] px-4 py-2 text-xs font-black text-white">{translate("E’lonlarga qaytish")}</Link>} />;
  const isSaved = saved.includes(listing.id);
  return <div className="mx-auto max-w-5xl space-y-5"><Link href="/listings" data-testid="link-detail-back" className="inline-flex items-center gap-2 text-xs font-black text-[#748279]"><ArrowLeft className="h-4 w-4" /> {translate("Barlıq jariyalar")}</Link><div className="grid overflow-hidden rounded-[28px] border border-[#e3e9e1] bg-white lg:grid-cols-[1fr_0.9fr]"><ListingVisual listing={listing} large /><div className="p-6 sm:p-9"><div className="flex items-start justify-between gap-4"><div><p className="text-[10px] font-black uppercase tracking-[0.18em] text-[#ff6b35]">{translateCategory(listing.category)}</p><h1 className="mt-2 text-3xl font-black leading-tight tracking-[-0.06em]">{listing.title}</h1></div><button type="button" data-testid={`button-detail-save-${listing.id}`} onClick={() => setSaved((current) => isSaved ? current.filter((item) => item !== listing.id) : [...current, listing.id])} className={`rounded-2xl p-3 ${isSaved ? "bg-[#fff0e8] text-[#ff6b35]" : "bg-[#f4f7f3] text-[#85928b]"}`}><Bookmark className={`h-5 w-5 ${isSaved ? "fill-current" : ""}`} /></button></div><p className="mt-6 text-3xl font-black text-[#17211e]">{formatPrice(listing.price)}</p><p className="mt-5 text-sm leading-7 text-[#68776e]">{listing.description}</p><div className="mt-6 flex flex-wrap gap-2"><span className="rounded-full bg-[#f0f5ee] px-3 py-1.5 text-[11px] font-black text-[#637269]">{translateDistrict(listing.district)}</span><span className="rounded-full bg-[#f0f5ee] px-3 py-1.5 text-[11px] font-black text-[#637269]">{translate(listing.condition === "used" ? "Ishlatilgan" : listing.condition === "new" ? "Yangi" : "Holati ko‘rsatilmagan")}</span></div><div className="my-7 h-px bg-[#edf1eb]" /><div className="flex items-center gap-3"><div className="flex h-11 w-11 items-center justify-center rounded-2xl bg-[#dfeee0] font-black text-[#52705b]">{listing.sellerName.slice(0, 1).toUpperCase()}</div><div><p className="text-sm font-black">{listing.sellerName}</p><p className="text-[11px] font-semibold text-[#8d9b92]">{translate("Jariya avtorı")}</p></div></div><div className="mt-6 flex gap-2"><a href={listing.sellerPhone ? `tel:${listing.sellerPhone}` : "#"} data-testid={`link-call-seller-${listing.id}`} className="flex flex-1 items-center justify-center gap-2 rounded-2xl bg-[#ff6b35] px-4 py-3 text-xs font-black text-white"><Phone className="h-4 w-4" /> {translate("Qońıraw etiw")}</a><button type="button" data-testid={`button-message-seller-${listing.id}`} onClick={() => toast({ title: translate("Baylanıs"), description: translate("Satıwshı menen baylanısıw ushın telefon nomeri kórsetildi.") })} className="rounded-2xl border border-[#dfe7dc] px-4 py-3 text-xs font-black text-[#52645a]"><Send className="h-4 w-4" /></button></div></div></div></div>;
}

type ListingFormValues = { title: string; description: string; price: string; category: string; kind: "product" | "service"; condition: "new" | "used" | "any"; district: string; sellerName: string; sellerPhone: string; imageUrl: string | null };
function SellPage() {
  useLanguage();
  const [, setLocation] = useLocation();
  const { data: districts } = useListDistricts();
  const mutation = useCreateListing();
  const client = useQueryClient();
  const form = useForm<ListingFormValues>({ defaultValues: { title: "", description: "", price: "", category: "Elektronika", kind: "product", condition: "used", district: "", sellerName: "", sellerPhone: "", imageUrl: null } });
  const handleImageChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;
     if (!file.type.startsWith("image/")) {
       toast({ title: translate("Rasm tanlanmadi"), description: translate("Faqat rasm faylini tanlang.") });
      return;
    }
    const reader = new FileReader();
    reader.onload = () => {
      const source = new Image();
      source.onload = () => {
        const maxSize = 1280;
        const scale = Math.min(1, maxSize / Math.max(source.width, source.height));
        const canvas = document.createElement("canvas");
        canvas.width = Math.max(1, Math.round(source.width * scale));
        canvas.height = Math.max(1, Math.round(source.height * scale));
        const context = canvas.getContext("2d");
        if (!context) return;
        context.drawImage(source, 0, 0, canvas.width, canvas.height);
        form.setValue("imageUrl", canvas.toDataURL("image/jpeg", 0.82));
      };
      source.src = String(reader.result);
    };
    reader.readAsDataURL(file);
  };
  const imagePreview = form.watch("imageUrl");
  const onSubmit = (values: ListingFormValues) => mutation.mutate({ data: { ...values, price: values.price ? Number(values.price) : null } }, { onSuccess: (listing) => { client.invalidateQueries({ queryKey: getListListingsQueryKey() }); client.invalidateQueries({ queryKey: getGetMarketplaceSummaryQueryKey() }); toast({ title: translate("E’lon joylandi"), description: translate("E’loningiz marketplace’da ko‘rinmoqda.") }); setLocation(`/listings/${listing.id}`); } });
  return <div className="mx-auto max-w-3xl"><Link href="/listings" data-testid="link-sell-back" className="mb-5 inline-flex items-center gap-2 text-xs font-black text-[#748279]"><ArrowLeft className="h-4 w-4" /> {translate("Orqaga")}</Link><div className="mb-8"><p className="mb-2 text-[10px] font-black uppercase tracking-[0.2em] text-[#ff6b35]">{translate("Sotıw hám bólistiriw")}</p><h1 className="text-4xl font-black tracking-[-0.07em]">{translate("Jańa jariya")}</h1><p className="mt-2 text-sm text-[#7b8981]">{translate("Maǵlıwmatlardı toltırıń hám Qaraqalpaqstan bazarına shıǵarıń.")}</p></div><Form {...form}><form onSubmit={form.handleSubmit(onSubmit)} className="space-y-5 rounded-[28px] border border-[#e3e9e1] bg-white p-5 shadow-[0_10px_34px_rgba(39,64,47,0.06)] sm:p-8"><div className="grid gap-5 sm:grid-cols-2"><FormField control={form.control} name="title" rules={{ required: translate("Ataması kerek"), minLength: { value: 3, message: translate("Keminde 3 belgi") } }} render={({ field }) => <FormItem className="sm:col-span-2"><FormLabel>{translate("Ataması")}</FormLabel><FormControl><input {...field} data-testid="input-listing-title" placeholder="Mısalı: Samsung Galaxy A54" className="field-input" /></FormControl><FormMessage /></FormItem>} /><div className="sm:col-span-2"><span className="mb-2 block text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70">{translate("Súwret")}</span><div className="flex flex-col gap-3 sm:flex-row sm:items-center"><label className="flex min-h-28 cursor-pointer items-center justify-center gap-2 rounded-2xl border-2 border-dashed border-[#d9e4d7] bg-[#f8faf7] px-5 py-4 text-xs font-black text-[#718078] transition hover:border-[#ffb99d] hover:bg-[#fff8f4] sm:w-56"><ImagePlus className="h-5 w-5 text-[#ff6b35]" /><span>{imagePreview ? translate("Boshqa rasm tanlash") : translate("Súwret tańlaw")}</span><input type="file" accept="image/*" onChange={handleImageChange} data-testid="input-listing-image" className="sr-only" /></label>{imagePreview ? <div className="relative h-28 w-40 overflow-hidden rounded-2xl border border-[#e3e9e1]"><img src={imagePreview} alt={translate("E’lon rasmi")} className="h-full w-full object-cover" /><button type="button" onClick={() => form.setValue("imageUrl", null)} className="absolute right-2 top-2 rounded-full bg-[#17211e]/80 px-2 py-1 text-[10px] font-black text-white">{translate("Olib tashlash")}</button></div> : <p className="text-xs leading-5 text-[#849189]">{translate("Bitta rasm tanlang. Rasm avtomatik siqiladi.")}</p>}</div></div><FormField control={form.control} name="kind" render={({ field }) => <FormItem><FormLabel>{translate("Jariya túri")}</FormLabel><FormControl><select {...field} data-testid="select-listing-kind" className="field-input"><option value="product">{translate("Ónim")}</option><option value="service">{translate("Xizmet")}</option></select></FormControl></FormItem>} /><FormField control={form.control} name="category" render={({ field }) => <FormItem><FormLabel>{translate("Kategoriya")}</FormLabel><FormControl><select {...field} data-testid="select-listing-category" className="field-input">{categories.map((item) => <option key={item}>{translateCategory(item)}</option>)}</select></FormControl></FormItem>} /><FormField control={form.control} name="price" render={({ field }) => <FormItem><FormLabel>{translate("Baha (swm)")}</FormLabel><FormControl><input {...field} inputMode="numeric" data-testid="input-listing-price" placeholder={translate("Kelisilinedi bolsa bos qaldırıń")} className="field-input" /></FormControl><FormMessage /></FormItem>} /><FormField control={form.control} name="condition" render={({ field }) => <FormItem><FormLabel>{translate("Jaǵdayı")}</FormLabel><FormControl><select {...field} data-testid="select-listing-condition" className="field-input">{conditions.map((item) => <option key={item.value} value={item.value}>{translateCondition(item.label)}</option>)}</select></FormControl></FormItem>} /><FormField control={form.control} name="district" rules={{ required: translate("Rayon yamasa qala tańlań") }} render={({ field }) => <FormItem><FormLabel>{translate("Rayon yamasa qala")}</FormLabel><FormControl><select {...field} data-testid="select-listing-district" className="field-input"><option value="">{translate("Tańlań")}</option>{districts?.map((item) => <option key={item.id} value={item.name}>{translateDistrict(item.name)}</option>)}</select></FormControl><FormMessage /></FormItem>} /><FormField control={form.control} name="sellerName" rules={{ required: translate("Atıńızdı kiritiń") }} render={({ field }) => <FormItem><FormLabel>{translate("Atıńız")}</FormLabel><FormControl><input {...field} data-testid="input-seller-name" placeholder={translate("Atı yamasa atama")} className="field-input" /></FormControl><FormMessage /></FormItem>} /><FormField control={form.control} name="sellerPhone" render={({ field }) => <FormItem><FormLabel>{translate("Telefon nomeri")}</FormLabel><FormControl><input {...field} data-testid="input-seller-phone" placeholder="+998 90 000 00 00" className="field-input" /></FormControl></FormItem>} /><FormField control={form.control} name="description" rules={{ required: translate("Bayanat kerek"), minLength: { value: 10, message: translate("Keminde 10 belgi") } }} render={({ field }) => <FormItem className="sm:col-span-2"><FormLabel>{translate("Bayanat")}</FormLabel><FormControl><textarea {...field} data-testid="textarea-listing-description" rows={5} placeholder={translate("Ónimińiz yamasa xizmetińiz haqqında jazıń...")} className="field-input min-h-32 resize-y" /></FormControl><FormMessage /></FormItem>} /></div><button type="submit" disabled={mutation.isPending} data-testid="button-submit-listing" className="flex w-full items-center justify-center gap-2 rounded-2xl bg-[#ff6b35] px-5 py-3.5 text-xs font-black text-white transition hover:bg-[#f45e29] disabled:opacity-60">{mutation.isPending ? <Loader2 className="h-4 w-4 animate-spin" /> : <CirclePlus className="h-4 w-4" />} {translate("Jariyalaw")}</button>{mutation.isError && <p className="text-center text-xs font-bold text-red-600">{translate("E’lonni joylashda xatolik yuz berdi. Qayta urinib ko‘ring.")}</p>}</form></Form></div>;
}

function ServicesPage() {
  useLanguage();
  const [search, setSearch] = useState("");
  const [query, setQuery] = useState("");
  const [district, setDistrict] = useState("");
  const { data: districts } = useListDistricts();
  const { data, isLoading } = useListServiceProfiles({ q: query || undefined, district: district || undefined, limit: 30 });
  return <div className="space-y-8"><div className="flex flex-col justify-between gap-5 sm:flex-row sm:items-end"><div><p className="mb-2 text-[10px] font-black uppercase tracking-[0.2em] text-[#ff6b35]">{translate("Xizmatlar katalogi")}</p><h1 className="text-4xl font-black tracking-[-0.07em]">{translate("Kerakli ustani toping")}</h1><p className="mt-2 text-sm text-[#7b8981]">{translate("Mahsulot emas, mahorat izlayotganlar uchun.")}</p></div><Link href="/services/new" data-testid="link-services-new" className="inline-flex w-fit items-center gap-2 rounded-full bg-[#ff6b35] px-4 py-3 text-xs font-black text-white"><CirclePlus className="h-4 w-4" /> {translate("Xizmat profilini yaratish")}</Link></div><div className="grid gap-3 rounded-[22px] border border-[#e4eae1] bg-white p-4 md:grid-cols-[1fr_260px_auto]"><form onSubmit={(event) => { event.preventDefault(); setQuery(search); }} className="flex items-center gap-2 rounded-xl border border-[#e0e8df] px-3"><Search className="h-4 w-4 text-[#91a097]" /><input value={search} onChange={(event) => setSearch(event.target.value)} data-testid="input-search-services" placeholder="Santexnik, elektrik, tozalash..." className="min-w-0 flex-1 bg-transparent py-3 text-xs font-semibold outline-none" /><button type="submit" data-testid="button-search-services" className="text-xs font-black text-[#ff6b35]">{translate("Izlew")}</button></form><SelectField label={translate("Rayon yamasa qala")} value={district} onChange={setDistrict} options={[{ value: "", label: translate("Barlıq aymaqlar") }, ...(districts ?? []).map((item) => ({ value: item.name, label: translateDistrict(item.name) }))]} testId="select-services-district" /><Link href="/services/new" data-testid="link-services-cta" className="hidden items-center justify-center gap-2 rounded-xl bg-[#17211e] px-4 text-xs font-black text-white md:flex"><Sparkles className="h-4 w-4" /> {translate("Men ham xizmat ko‘rsataman")}</Link></div>{isLoading ? <LoadingList /> : data?.length ? <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">{data.map((service) => <ServiceCard key={service.id} service={service} />)}</div> : <EmptyState title={translate("Mos usta topilmadi")} description={translate("Qidiruv so‘zini yoki tuman filtrini o‘zgartirib ko‘ring.")} />}</div>;
}

function ServiceRow({ service }: { service: ServiceProfile }) {
  return <Link href="/services" data-testid={`row-service-${service.id}`} className="flex items-center gap-3 rounded-2xl border border-[#e7ede5] p-3 transition hover:border-[#ffb99d] hover:bg-[#fffaf7]"><div className="flex h-11 w-11 items-center justify-center rounded-2xl bg-[#dfeee0] text-sm font-black text-[#52705b]">{service.name.slice(0, 1)}</div><div className="min-w-0 flex-1"><div className="flex items-center gap-1.5"><p className="truncate text-xs font-black">{service.name}</p>{service.verified && <ShieldCheck className="h-3.5 w-3.5 text-[#4f9a67]" />}</div><p className="truncate text-[11px] font-semibold text-[#7f8e84]">{service.title}</p></div><div className="text-right"><p className="text-xs font-black text-[#ff6b35]">{service.rating.toFixed(1)}</p><p className="text-[10px] text-[#92a098]">{translateDistrict(service.district)}</p></div></Link>;
}

function ServiceCard({ service }: { service: ServiceProfile }) {
  const Icon = getServiceIcon(service.category, service.title);
  return <article className="rounded-[24px] border border-[#e3e9e1] bg-white p-5 shadow-[0_8px_28px_rgba(39,64,47,0.05)] transition hover:-translate-y-1 hover:shadow-[0_18px_36px_rgba(39,64,47,0.1)]" data-testid={`card-service-${service.id}`}><div className="flex items-start justify-between gap-3"><div className="flex items-center gap-3"><div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-[#dfeee0] text-[#52705b]"><Icon className="h-6 w-6" /></div><div><div className="flex items-center gap-1.5"><p className="text-sm font-black">{service.name}</p>{service.verified && <ShieldCheck className="h-4 w-4 text-[#4f9a67]" />}</div><p className="mt-1 text-[11px] font-semibold text-[#839087]">{translateDistrict(service.district)}</p></div></div><span className="rounded-full bg-[#fff4cf] px-2.5 py-1 text-[10px] font-black text-[#8c6c1d]">{service.rating.toFixed(1)} ★</span></div><h3 className="mt-5 text-lg font-black tracking-[-0.03em]">{service.title}</h3><p className="mt-2 line-clamp-3 text-xs leading-5 text-[#7f8e84]">{service.bio}</p><div className="mt-4 flex flex-wrap gap-1.5">{service.skills.map((skill) => <span key={skill} className="rounded-full bg-[#f2f6ef] px-2.5 py-1 text-[10px] font-bold text-[#738178]">{skill}</span>)}</div><a href={`tel:${service.phone}`} data-testid={`link-call-service-${service.id}`} className="mt-5 flex w-full items-center justify-center gap-2 rounded-xl bg-[#17211e] py-3 text-xs font-black text-white"><Phone className="h-4 w-4" /> {translate("Baylanıs")}</a></article>;
}

function AdminPage() {
  useLanguage();
  const { data: currentUser, isLoading: userLoading } = useGetCurrentUser();
  const { data: adminStats, isError: statsError } = useGetAdminStats({ query: { queryKey: getGetAdminStatsQueryKey(), enabled: currentUser?.isAdmin === true } });
  const { data: summary, isLoading } = useGetMarketplaceSummary();
  const { data: listings } = useListListings({ limit: 50, sort: "newest" });
  const { data: services } = useListServiceProfiles({ limit: 50 });
  const today = new Date().toDateString();
  const todayListings = listings?.items.filter((item) => new Date(item.createdAt).toDateString() === today).length ?? 0;
  const todayServices = services?.filter((item) => new Date(item.createdAt).toDateString() === today).length ?? 0;
  const stats = [
    { label: "Paydalanıwshılar", value: adminStats?.totalUsers ?? 0, today: `Búgin +${adminStats?.todayUsers ?? 0}`, icon: Users },
    { label: translate("Jariya"), value: summary?.listingCount ?? 0, today: `${translate("Búgin")} +${todayListings}`, icon: Package },
    { label: translate("Xizmetler"), value: summary?.serviceCount ?? 0, today: `${translate("Búgin")} +${todayServices}`, icon: BriefcaseBusiness },
    { label: translate("Aymaqlar"), value: summary?.districtCount ?? 0, today: translate("Qaraqalpaqstan"), icon: BarChart3 },
  ];
  if (userLoading) return <LoadingPanel />;
  if (!currentUser?.isAdmin || statsError) return <EmptyState title={translate("Ruxsat yo‘q")} description={translate("Admin panel faqat ruxsat berilgan Telegram administratorlari uchun.")} />;
  return <div className="space-y-8"><div className="flex flex-wrap items-end justify-between gap-4"><div><p className="text-[10px] font-black uppercase tracking-[0.2em] text-[#ff6b35]">{translate("Bozor Bot boshqaruvi")}</p><h1 className="mt-2 text-3xl font-black">{translate("Admin panel")}</h1></div><span className="rounded-full bg-[#17211e] px-4 py-2 text-xs font-black text-white">{translate("Janli statistika")}</span></div><div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">{stats.map(({ label, value, today: daily, icon: Icon }) => <div key={label} className="rounded-[24px] border border-[#e3e9e1] bg-white p-5 shadow-sm"><div className="flex items-center justify-between"><span className="flex h-10 w-10 items-center justify-center rounded-2xl bg-[#fff0e8] text-[#ff6b35]"><Icon className="h-5 w-5" /></span><span className="text-[10px] font-bold text-[#849189]">{daily}</span></div><p className="mt-5 text-3xl font-black">{isLoading ? "…" : value}</p><p className="mt-1 text-xs font-bold text-[#7b8981]">{label}</p></div>)}</div><AdminConversations /><section className="rounded-[28px] border border-[#e3e9e1] bg-white p-6"><h2 className="text-lg font-black">{translate("Sońǵı jariyalar")}</h2><div className="mt-4 space-y-3">{listings?.items.slice(0, 5).map((item) => <div key={item.id} className="flex items-center justify-between rounded-2xl border border-[#edf1eb] p-3"><div><p className="text-xs font-black">{item.title}</p><p className="mt-1 text-[10px] text-[#8b9890]">{translateDistrict(item.district)}</p></div><span className="text-[10px] font-black text-[#ff6b35]">{formatDate(item.createdAt)}</span></div>)}</div></section></div>;
}

function AdminConversations() {
  useLanguage();
  const [selectedId, setSelectedId] = useState<number | null>(null);
  const { data: conversations } = useListAdConversations({ query: { queryKey: getListAdConversationsQueryKey(), refetchInterval: 5000 } });
  const selected = conversations?.find((item) => item.id === selectedId) ?? conversations?.[0];
  return <section className="grid gap-4 lg:grid-cols-[280px_1fr]"><div className="rounded-[28px] border border-[#e3e9e1] bg-white p-5"><h2 className="text-lg font-black">{translate("Reklama murojaatlari")}</h2><div className="mt-4 space-y-2">{conversations?.length ? conversations.map((conversation) => <button key={conversation.id} type="button" onClick={() => setSelectedId(conversation.id)} className={`w-full rounded-xl border p-3 text-left ${selected?.id === conversation.id ? "border-[#ff6b35] bg-[#fff8f4]" : "border-[#edf1eb]"}`}><p className="truncate text-xs font-black">{conversation.subject}</p><p className="mt-1 text-[9px] text-[#849189]">{conversation.userName}</p></button>) : <p className="text-xs text-[#849189]">{translate("Hozircha murojaat yo‘q.")}</p>}</div></div>{selected && <ConversationChat conversation={selected} />}</section>;
}

declare global {
  interface Window {
    Telegram?: {
      WebApp?: {
        ready: () => void;
        expand: () => void;
        initData: string;
        requestContact: (callback: (accepted: boolean) => void) => void;
        BackButton?: {
          show: () => void;
          hide: () => void;
          onClick: (callback: () => void) => void;
          offClick: (callback: () => void) => void;
        };
        initDataUnsafe?: { user?: { id: number; first_name?: string } };
      };
    };
  }
}

function TelegramLogin({ onComplete }: { onComplete: () => void }) {
  const { t } = useLanguage();
  const [pending, setPending] = useState(false);
  const authenticate = useAuthenticateTelegram();
  const telegram = window.Telegram?.WebApp;
  useEffect(() => { telegram?.ready(); telegram?.expand(); }, [telegram]);
  const requestPhone = async () => {
    if (!telegram?.requestContact || !telegram.initData) {
      toast({ title: t("Telegram orqali oching"), description: t("Telefon raqamini yuborish uchun ilovani Telegram bot ichidan oching.") });
      return;
    }
    setPending(true);
    try {
      const session = await authenticate.mutateAsync({ data: { initData: telegram.initData } });
      localStorage.setItem(SESSION_KEY, session.token);
    } catch {
      setPending(false);
      toast({ title: t("Kirish amalga oshmadi"), description: t("Telegram ma’lumotlarini tekshirib bo‘lmadi.") });
      return;
    }
    telegram.requestContact((accepted) => {
      if (!accepted) { setPending(false); return; }
      let attempts = 0;
      const poll = window.setInterval(async () => {
        attempts += 1;
        try {
          const user = await getCurrentUser();
          if (user.phone) { window.clearInterval(poll); setPending(false); onComplete(); }
        } catch { /* Retry while the webhook is being delivered. */ }
        if (attempts >= 15) {
          window.clearInterval(poll); setPending(false);
          toast({ title: t("Telefon hali kelmadi"), description: t("Bir necha soniyadan keyin qayta urinib ko‘ring.") });
        }
      }, 1000);
    });
  };
  return <div className="flex min-h-[100dvh] items-center justify-center bg-[#f6f7f2] p-6"><div className="w-full max-w-sm text-center"><div className="mb-5 flex justify-end"><LanguageSwitcher /></div><img src={bozorBotLogo} alt="Bozor Bot" className="mx-auto h-28 w-28 object-contain" /><h1 className="mt-5 text-3xl font-black tracking-[-0.06em]">Bozor Bot</h1><p className="mt-3 text-sm leading-6 text-[#7b8981]">{t("Davom etish uchun Telegram orqali telefon raqamingizni yuboring.")}</p><button type="button" onClick={requestPhone} disabled={pending} className="mt-8 flex w-full items-center justify-center gap-2 rounded-2xl bg-[#ff6b35] px-5 py-4 text-sm font-black text-white disabled:opacity-60"><Phone className="h-5 w-5" />{pending ? t("Kutilmoqda…") : t("Raqamni yuborish")}</button><p className="mt-4 text-[10px] leading-5 text-[#9aa59f]">{t("Raqam faqat akkauntni yaratish va e’lonlaringizni bog‘lash uchun ishlatiladi.")}</p></div></div>;
}

type ServiceFormValues = { name: string; title: string; bio: string; skills: string; category: string; district: string; phone: string };
function ServiceCreatePage() {
  useLanguage();
  const [, setLocation] = useLocation();
  const { data: districts } = useListDistricts();
  const mutation = useCreateServiceProfile();
  const form = useForm<ServiceFormValues>({ defaultValues: { name: "", title: "", bio: "", skills: "", category: "Uy ta’miri", district: "", phone: "" } });
  const onSubmit = (values: ServiceFormValues) => mutation.mutate({ data: { ...values, skills: values.skills.split(",").map((skill) => skill.trim()).filter(Boolean) } }, { onSuccess: () => { queryClient.invalidateQueries({ queryKey: getListServiceProfilesQueryKey() }); toast({ title: translate("Profil yaratildi"), description: translate("Xizmatingiz katalogda ko‘rinadi.") }); setLocation("/services"); } });
  return <div className="mx-auto max-w-3xl"><Link href="/services" data-testid="link-service-form-back" className="mb-5 inline-flex items-center gap-2 text-xs font-black text-[#748279]"><ArrowLeft className="h-4 w-4" /> {translate("Xizmatlarga qaytish")}</Link><div className="mb-8"><p className="mb-2 text-[10px] font-black uppercase tracking-[0.2em] text-[#ff6b35]">{translate("Ustalar katalogı")}</p><h1 className="text-4xl font-black tracking-[-0.07em]">{translate("Xizmet profilıńiz")}</h1><p className="mt-2 text-sm text-[#7b8981]">{translate("Mijozlar sizni topishi uchun asosiy ma’lumotlarni yozing.")}</p></div><Form {...form}><form onSubmit={form.handleSubmit(onSubmit)} className="grid gap-5 rounded-[28px] border border-[#e3e9e1] bg-white p-5 shadow-[0_10px_34px_rgba(39,64,47,0.06)] sm:grid-cols-2 sm:p-8"><FormField control={form.control} name="name" rules={{ required: translate("Atı kerek") }} render={({ field }) => <FormItem><FormLabel>{translate("Atı")}</FormLabel><FormControl><input {...field} data-testid="input-service-name" className="field-input" placeholder={translate("Atı hám familiyası")} /></FormControl><FormMessage /></FormItem>} /><FormField control={form.control} name="title" rules={{ required: translate("Xizmet atı kerek") }} render={({ field }) => <FormItem><FormLabel>{translate("Xizmet atı")}</FormLabel><FormControl><input {...field} data-testid="input-service-title" className="field-input" placeholder={translate("Mısalı: Elektrik usta")} /></FormControl><FormMessage /></FormItem>} /><FormField control={form.control} name="category" render={({ field }) => <FormItem><FormLabel>{translate("Kategoriya")}</FormLabel><FormControl><select {...field} data-testid="select-service-category" className="field-input">{categories.slice(5).map((item) => <option key={item}>{translateCategory(item)}</option>)}</select></FormControl></FormItem>} /><FormField control={form.control} name="district" rules={{ required: translate("Rayon yamasa qala tańlań") }} render={({ field }) => <FormItem><FormLabel>{translate("Rayon yamasa qala")}</FormLabel><FormControl><select {...field} data-testid="select-service-district" className="field-input"><option value="">{translate("Tańlań")}</option>{districts?.map((item) => <option key={item.id} value={item.name}>{translateDistrict(item.name)}</option>)}</select></FormControl><FormMessage /></FormItem>} /><FormField control={form.control} name="phone" rules={{ required: translate("Telefon kerek") }} render={({ field }) => <FormItem><FormLabel>{translate("Telefon")}</FormLabel><FormControl><input {...field} data-testid="input-service-phone" className="field-input" placeholder="+998 90 000 00 00" /></FormControl><FormMessage /></FormItem>} /><FormField control={form.control} name="skills" rules={{ required: translate("Keminde bir kónlikpe kiritiń") }} render={({ field }) => <FormItem><FormLabel>{translate("Kónlikpeler")}</FormLabel><FormControl><input {...field} data-testid="input-service-skills" className="field-input" placeholder={translate("Elektrik, jarıqlıq, mayda ońlaw")} /></FormControl><FormMessage /></FormItem>} /><FormField control={form.control} name="bio" rules={{ required: translate("Ózińiz haqqında jazıń"), minLength: { value: 10, message: translate("Keminde 10 belgi") } }} render={({ field }) => <FormItem className="sm:col-span-2"><FormLabel>{translate("Qısqasha maǵlıwmat")}</FormLabel><FormControl><textarea {...field} data-testid="textarea-service-bio" rows={5} className="field-input min-h-32 resize-y" placeholder={translate("Tájiriybeńiz hám mijozlarǵa qanday járdem beriwińiz haqqında...")} /></FormControl><FormMessage /></FormItem>} /><button type="submit" disabled={mutation.isPending} data-testid="button-submit-service" className="sm:col-span-2 flex items-center justify-center gap-2 rounded-2xl bg-[#ff6b35] py-3.5 text-xs font-black text-white disabled:opacity-60">{mutation.isPending ? <Loader2 className="h-4 w-4 animate-spin" /> : <Check className="h-4 w-4" />} {translate("Profilni joylash")}</button>{mutation.isError && <p className="sm:col-span-2 text-center text-xs font-bold text-red-600">{translate("Profilni saqlashda xatolik yuz berdi.")}</p>}</form></Form></div>;
}

function ProfilePage() {
  useLanguage();
  const [saved] = useSaved();
  const { data: currentUser } = useGetCurrentUser();
  const menu = [
    { href: "/my-listings", label: translate("Mening jariyalarım"), icon: Package, color: "text-[#ffb36b]" },
    { href: "/saved", label: translate("Saqlanǵanlar"), icon: Heart, color: "text-[#ff5e6c]", count: saved.length },
    { href: "/chats", label: translate("Súwbetler"), icon: MessageCircle, color: "text-white" },
    { href: "/reviews", label: translate("Pikirler"), icon: Star, color: "text-[#ffe052]" },
    ...(currentUser?.isAdmin ? [{ href: "/admin", label: translate("Admin panel"), icon: ShieldCheck, color: "text-[#59e4d1]" }] : []),
  ];
  return <div className="-mx-4 -mt-4 min-h-[calc(100dvh-73px)] bg-[#e4f2ff] px-4 pb-28 pt-10 text-[#1f4b6b] sm:mx-0 sm:mt-0 sm:min-h-0 sm:rounded-[32px] sm:p-10"><div className="mx-auto max-w-md"><div className="text-center"><div className="mx-auto flex h-24 w-24 items-center justify-center rounded-full bg-gradient-to-br from-[#bfe7ff] to-[#5baee0] text-4xl font-black text-white shadow-[0_16px_40px_rgba(65,159,231,0.25)]">B</div><h1 className="mt-5 text-2xl font-black">{translate("Bozor Bot paydalanıwshısı")}</h1><p className="mt-1 text-xs text-[#75839a]">{translate("Qaraqalpaqstan")}</p><div className="mt-3 flex items-center justify-center gap-1 text-[#4f9a67]"><Star className="h-4 w-4" /><Star className="h-4 w-4" /><Star className="h-4 w-4" /><Star className="h-4 w-4" /><Star className="h-4 w-4" /><span className="ml-1 text-xs text-[#75839a]">{translate("(0 pikir)")}</span></div></div><div className="mt-8 space-y-3">{menu.map((item) => { const Icon = item.icon; return <Link key={item.href} href={item.href} className="flex items-center gap-4 rounded-2xl border border-[#c9e0f1] bg-[#f4faff] px-5 py-4 transition hover:bg-[#e9f5ff]"><Icon className={`h-5 w-5 ${item.color}`} /><span className="flex-1 text-sm font-black">{item.label}</span>{item.count !== undefined && item.count > 0 && <span className="rounded-full bg-[#419fe7] px-2 py-0.5 text-[10px] font-black text-white">{item.count}</span>}<ChevronRight className="h-5 w-5 text-[#7391aa]" /></Link>; })}</div></div></div>;
}

function SavedPage() {
  useLanguage();
  const [saved, setSaved] = useSaved();
  const { data, isLoading } = useListListings({ limit: 50 });
  const items = data?.items.filter((listing) => saved.includes(listing.id)) ?? [];
  return <div className="space-y-6"><SectionHeading title={translate("Saqlanǵanlar")} description={translate("Keyinirek kóriw ushın saqlaǵan jariyalarıńız.")} />{isLoading ? <LoadingGrid count={4} /> : items.length ? <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">{items.map((listing) => <ListingCard key={listing.id} listing={listing} saved onToggleSave={(id) => setSaved((current) => current.filter((item) => item !== id))} />)}</div> : <EmptyState title={translate("Saqlanǵanlar joq")} description={translate("Jaqqan jariyalarıńızdı saqlaw belgisi arqalı usı jerge qosıń.")} />}</div>;
}

function SimpleAccountPage({ title, description }: { title: string; description: string }) {
  useLanguage();
  return <div className="mx-auto max-w-xl"><Link href="/profile" className="mb-5 inline-flex items-center gap-2 text-xs font-black text-[#748279]"><ArrowLeft className="h-4 w-4" /> {translate("Profilge qaytıw")}</Link><EmptyState title={title} description={description} /></div>;
}

function SelectField({ label, value, onChange, options, testId }: { label: string; value: string; onChange: (value: string) => void; options: { value: string; label: string }[]; testId: string }) {
  useLanguage();
  return <label className="block"><span className="mb-2 block text-[10px] font-black uppercase tracking-[0.15em] text-[#91a098]">{label}</span><span className="relative block"><select value={value} onChange={(event) => onChange(event.target.value)} data-testid={testId} className="field-input w-full appearance-none pr-9"><option value="">{translate("Tańlań")}</option>{options.filter((option) => option.value !== "").map((option) => <option key={option.value} value={option.value}>{option.label}</option>)}</select><ChevronDown className="pointer-events-none absolute right-3 top-1/2 h-4 w-4 -translate-y-1/2 text-[#849189]" /></span></label>;
}

function FilterPill({ children, active, onClick, testId }: { children: ReactNode; active: boolean; onClick: () => void; testId: string }) {
  return <button type="button" data-testid={testId} onClick={onClick} className={`inline-flex items-center gap-2 rounded-full px-4 py-2.5 text-xs font-black transition ${active ? "bg-[#17211e] text-white" : "border border-[#e0e8df] bg-white text-[#738178] hover:border-[#ffb99d]"}`}>{children}</button>;
}

function EmptyState({ title, description, action }: { title: string; description: string; action?: ReactNode }) {
  return <div className="rounded-[28px] border border-dashed border-[#ccd8cc] bg-white/70 px-6 py-16 text-center"><div className="mx-auto flex h-12 w-12 items-center justify-center rounded-2xl bg-[#eef4eb] text-[#78907e]"><Search className="h-5 w-5" /></div><h3 className="mt-4 text-lg font-black">{title}</h3><p className="mx-auto mt-2 max-w-sm text-sm leading-6 text-[#849189]">{description}</p>{action && <div className="mt-5">{action}</div>}</div>;
}

function LoadingGrid({ count }: { count: number }) {
  return <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">{Array.from({ length: count }).map((_, index) => <div key={index} className="h-80 animate-pulse rounded-[24px] bg-[#e8eee6]" />)}</div>;
}
function LoadingList() { return <div className="space-y-3">{[1, 2, 3].map((item) => <div key={item} className="h-16 animate-pulse rounded-2xl bg-[#edf2eb]" />)}</div>; }
function LoadingPanel() { return <div className="mx-auto max-w-5xl"><div className="h-[520px] animate-pulse rounded-[28px] bg-[#e7ede5]" /></div>; }

function useSaved() {
  const [saved, setSavedState] = useState<number[]>(() => {
    try { return JSON.parse(localStorage.getItem("bozor-bot-saved") ?? "[]") as number[]; } catch { return []; }
  });
  const setSaved = (updater: number[] | ((current: number[]) => number[])) => {
    setSavedState((current) => { const next = typeof updater === "function" ? updater(current) : updater; localStorage.setItem("bozor-bot-saved", JSON.stringify(next)); return next; });
  };
  return [saved, setSaved] as const;
}

function Router() {
  useLanguage();
  return <ErrorBoundary><Shell><Switch><Route path="/" component={HomePage} /><Route path="/products" component={ProductsPage} /><Route path="/all-services" component={AllServicesPage} /><Route path="/listings" component={ListingsPage} /><Route path="/listings/:id" component={ListingDetailPage} /><Route path="/create" component={CreatePage} /><Route path="/sell" component={SellPage} /><Route path="/advertise" component={AdvertisePage} /><Route path="/services" component={ServicesPage} /><Route path="/services/new" component={ServiceCreatePage} /><Route path="/profile" component={ProfilePage} /><Route path="/saved" component={SavedPage} /><Route path="/admin" component={AdminPage} /><Route path="/my-listings">{() => <SimpleAccountPage title="Mening jariyalarım" description="Akaunt tizimi qo‘shilgach, joylashtirgan e’lonlaringiz shu yerda ko‘rinadi." />}</Route><Route path="/chats">{() => <SimpleAccountPage title="Súwbetler" description="Sotuvchi va mijozlar bilan yozishmalar shu yerda ko‘rinadi." />}</Route><Route path="/reviews">{() => <SimpleAccountPage title="Pikirler" description="Siz haqingizda qoldirilgan sharhlar shu yerda ko‘rinadi." />}</Route><Route component={NotFound} /></Switch></Shell></ErrorBoundary>;
}

function App() {
  const [authenticated, setAuthenticated] = useState(() => Boolean(localStorage.getItem(SESSION_KEY)));
  useEffect(() => {
    setAuthTokenGetter(() => localStorage.getItem(SESSION_KEY));
    return () => setAuthTokenGetter(null);
  }, []);
  useEffect(() => {
    const token = localStorage.getItem(SESSION_KEY);
    if (!token) { setAuthenticated(false); return; }
    void getCurrentUser()
      .then((user) => setAuthenticated(Boolean(user.phone)))
      .catch((error: unknown) => {
        const status = error && typeof error === "object" && "status" in error
          ? (error as { status?: unknown }).status
          : undefined;
        if (status === 401) {
          localStorage.removeItem(SESSION_KEY);
          setAuthenticated(false);
        }
      });
  }, []);
  return <QueryClientProvider client={queryClient}><LanguageProvider><TooltipProvider>{authenticated ? <Router /> : <TelegramLogin onComplete={() => setAuthenticated(true)} />}<Toaster /></TooltipProvider></LanguageProvider></QueryClientProvider>;
}

export default App;

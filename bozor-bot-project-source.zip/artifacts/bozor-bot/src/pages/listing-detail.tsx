import { ArrowLeft, Bookmark, CalendarDays, Check, MapPin, Phone, ShieldCheck, UserRound } from 'lucide-react';
import { Link, useLocation, useParams } from 'wouter';
import { useGetListing, getGetListingQueryKey } from '@workspace/api-client-react';
import { useQueryClient } from '@tanstack/react-query';
import { AppShell } from '@/components/layout';
import { ErrorState, ListingVisual } from '@/components/marketplace-ui';
import { initials, money, relativeDate } from '@/lib/format';
import { useSaved } from '@/hooks/use-saved';

export default function ListingDetail() {
  const params = useParams<{ id: string }>();
  const [, setLocation] = useLocation();
  const queryClient = useQueryClient();
  const id = Number(params.id);
  const result = useGetListing(id, { query: { queryKey: getGetListingQueryKey(id), enabled: Number.isFinite(id) } });
  const listing = result.data;
  const { savedListings, toggleListing } = useSaved();
  if (result.isLoading) return <AppShell title="E’lon"><div className="space-y-4"><div className="skeleton h-72 rounded-[28px]" /><div className="skeleton h-32 rounded-[24px]" /></div></AppShell>;
  if (result.isError || !listing) return <AppShell title="E’lon"><ErrorState onRetry={() => void queryClient.invalidateQueries({ queryKey: getGetListingQueryKey(id) })} /></AppShell>;
  const saved = savedListings.includes(String(listing.id));
  return <AppShell title="E’lon">
    <div className="animate-rise mx-auto max-w-3xl">
      <div className="mb-4 flex items-center justify-between"><button type="button" onClick={() => setLocation('/listings')} data-testid="button-back-listings" className="flex items-center gap-2 text-xs font-bold text-muted-foreground hover:text-secondary"><ArrowLeft className="h-4 w-4" /> E’lonlarga qaytish</button><button type="button" onClick={() => toggleListing(String(listing.id))} data-testid="button-save-listing-detail" aria-label={saved ? 'Saqlanganlardan olib tashlash' : 'Saqlash'} className={`grid h-10 w-10 place-items-center rounded-full border transition ${saved ? 'border-primary bg-[#fff0e8] text-primary' : 'border-border bg-card text-secondary'}`}><Bookmark className={`h-4 w-4 ${saved ? 'fill-current' : ''}`} /></button></div>
      <ListingVisual listing={listing} large />
      <section className="mt-4 rounded-[24px] border border-border bg-card p-5 shadow-card sm:p-7"><div className="flex flex-wrap items-center gap-2"><span className="rounded-full bg-[#eaf4ed] px-2.5 py-1.5 text-[10px] font-bold uppercase tracking-[.12em] text-[#4c8059]">{listing.status === 'published' ? 'Faol e’lon' : 'Ko‘rib chiqilmoqda'}</span><span className="text-xs text-muted-foreground">{listing.kind === 'service' ? 'Xizmat' : 'Mahsulot'} · {listing.category}</span></div><h1 className="mt-4 font-display text-[28px] font-bold leading-tight tracking-[-.055em] sm:text-[36px]" data-testid={`text-listing-title-${listing.id}`}>{listing.title}</h1><p className="mt-3 font-display text-2xl font-bold text-primary" data-testid={`text-listing-detail-price-${listing.id}`}>{money(listing.price)}</p><div className="mt-5 flex flex-wrap gap-3 text-xs font-semibold text-muted-foreground"><span className="flex items-center gap-1.5"><MapPin className="h-4 w-4 text-primary" /> {listing.district}</span><span className="flex items-center gap-1.5"><CalendarDays className="h-4 w-4 text-primary" /> {relativeDate(listing.createdAt)}</span>{listing.condition && <span className="rounded-full bg-muted px-2.5 py-1">{listing.condition === 'used' ? 'Ishlatilgan' : listing.condition === 'new' ? 'Yangi' : 'Holati turlicha'}</span>}</div><div className="mt-7 border-t border-border pt-5"><p className="text-[10px] font-bold uppercase tracking-[.16em] text-primary">Tavsif</p><p className="mt-2 whitespace-pre-wrap text-sm leading-6 text-muted-foreground" data-testid={`text-listing-description-${listing.id}`}>{listing.description}</p></div></section>
      <section className="mt-4 rounded-[24px] border border-border bg-card p-5 shadow-card"><div className="flex items-center gap-3"><span className="grid h-11 w-11 place-items-center rounded-full bg-[#d9ebe0] text-sm font-bold text-secondary">{initials(listing.sellerName)}</span><div className="min-w-0 flex-1"><p className="font-display text-sm font-bold" data-testid={`text-seller-${listing.id}`}>{listing.sellerName}</p><p className="mt-1 text-xs text-muted-foreground">Bozor hamjamiyati a’zosi</p></div><ShieldCheck className="h-5 w-5 text-[#4c9b67]" /></div>{listing.sellerPhone && <a href={`tel:${listing.sellerPhone}`} data-testid={`link-call-listing-${listing.id}`} className="mt-4 flex h-12 items-center justify-center gap-2 rounded-2xl bg-primary text-sm font-bold text-white transition hover:bg-primary/90"><Phone className="h-4 w-4" /> Bog‘lanish</a>}{!listing.sellerPhone && <div className="mt-4 flex items-center gap-2 rounded-2xl bg-muted px-4 py-3 text-xs font-semibold text-muted-foreground"><UserRound className="h-4 w-4" /> Sotuvchi bilan aloqa ma’lumotini e’lon egasidan so‘rang.</div>}</section>
      <div className="mt-4 flex items-center gap-2 rounded-2xl border border-[#d5e6d8] bg-[#f1f8f1] px-4 py-3 text-xs font-semibold text-[#4d7658]"><Check className="h-4 w-4 shrink-0" /> Kelishuvdan oldin buyumni ko‘rib, joyida tekshiring.</div>
    </div>
  </AppShell>;
}
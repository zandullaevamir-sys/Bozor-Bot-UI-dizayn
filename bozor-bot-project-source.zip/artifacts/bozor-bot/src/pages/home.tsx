import { ArrowRight, BriefcaseBusiness, ChevronRight, Search, ShieldCheck, Sparkles } from 'lucide-react';
import { Link } from 'wouter';
import { useGetMarketplaceSummary, useListListings, getListListingsQueryKey } from '@workspace/api-client-react';
import { useQueryClient } from '@tanstack/react-query';
import { AppShell, SectionHeading } from '@/components/layout';
import { EmptyState, ErrorState, ListingCard, ListingSkeleton } from '@/components/marketplace-ui';
import { useSaved } from '@/hooks/use-saved';

export default function Home() {
  const queryClient = useQueryClient();
  const summaryQuery = useGetMarketplaceSummary();
  const listingsQuery = useListListings({ limit: 6, sort: 'newest' });
  const { savedListings, toggleListing } = useSaved();
  const summary = summaryQuery.data;
  const items = summary?.featuredListings?.length ? summary.featuredListings : listingsQuery.data?.items ?? [];
  const loading = summaryQuery.isLoading || listingsQuery.isLoading;
  return <AppShell title="Bosh sahifa">
    <section className="grid gap-5 lg:grid-cols-[1.1fr_.9fr] lg:items-stretch">
      <div className="animate-rise relative overflow-hidden rounded-[28px] bg-secondary p-6 text-white shadow-float sm:p-9">
        <span className="absolute -right-14 -top-14 h-44 w-44 rounded-full border-[20px] border-primary/30" /><span className="absolute -bottom-20 right-20 h-44 w-44 rounded-full bg-primary/20" />
        <div className="relative max-w-xl">
          <p className="mb-3 flex items-center gap-2 text-[10px] font-bold uppercase tracking-[.2em] text-[#ffc1a6]"><Sparkles className="h-3.5 w-3.5" /> Yaqin bozor, yaxshi tanlov</p>
          <h1 className="max-w-[620px] font-display text-[34px] font-bold leading-[.98] tracking-[-.065em] sm:text-[50px]">Kerakli narsa<br /><span className="text-[#ffac88]">shu atrofda.</span></h1>
          <p className="mt-4 max-w-[440px] text-sm leading-6 text-[#c8d9d0]">Qoraqalpog‘iston bo‘ylab yangi va ishlatilgan buyumlar, ishonchli ustalar va qo‘shnilar tavsiyasi bir joyda.</p>
          <div className="mt-6 flex flex-wrap gap-2.5"><Link href="/listings" data-testid="link-hero-listings" className="inline-flex items-center gap-2 rounded-full bg-primary px-4 py-3 text-xs font-bold text-white transition hover:-translate-y-0.5 hover:bg-primary/90">E’lonlarni ko‘rish <ArrowRight className="h-4 w-4" /></Link><Link href="/services" data-testid="link-hero-services" className="inline-flex items-center gap-2 rounded-full border border-white/20 bg-white/10 px-4 py-3 text-xs font-bold text-white transition hover:bg-white/15">Ustalarni topish</Link></div>
        </div>
      </div>
      <div className="animate-rise animate-rise-1 rounded-[28px] border border-border bg-card p-5 shadow-card sm:p-7">
        <div className="flex items-center justify-between"><div><p className="text-[10px] font-bold uppercase tracking-[.18em] text-primary">Bozor bugun</p><h2 className="mt-1 font-display text-2xl font-bold tracking-[-.05em]">Mahalliy harakat</h2></div><span className="grid h-11 w-11 place-items-center rounded-2xl bg-[#fff0e8] text-primary"><BriefcaseBusiness className="h-5 w-5" /></span></div>
        <div className="mt-6 grid grid-cols-3 gap-2 divide-x divide-border"><Stat value={summary?.listingCount} label="e’lon" loading={summaryQuery.isLoading} /><Stat value={summary?.serviceCount} label="xizmatkor" loading={summaryQuery.isLoading} /><Stat value={summary?.districtCount} label="hudud" loading={summaryQuery.isLoading} /></div>
        <Link href="/sell" data-testid="link-home-sell" className="mt-6 flex items-center justify-between rounded-2xl bg-muted px-4 py-3 transition hover:bg-[#ffe8dc]"><span><span className="block text-xs font-bold text-secondary">Sizda sotiladigan narsa bormi?</span><span className="mt-1 block text-[10px] text-muted-foreground">E’lon berish bepul.</span></span><span className="grid h-8 w-8 place-items-center rounded-full bg-secondary text-white"><ArrowRight className="h-4 w-4" /></span></Link>
      </div>
    </section>
    <section className="mt-9"><div className="mb-4 flex h-12 items-center gap-3 rounded-2xl border border-border bg-card px-4 shadow-card focus-within:border-primary focus-within:ring-4 focus-within:ring-primary/10"><Search className="h-4 w-4 text-primary" /><input aria-label="E’lon qidirish" data-testid="input-home-search" placeholder="Nima izlayapsiz?" className="min-w-0 flex-1 bg-transparent text-sm outline-none placeholder:text-muted-foreground" onKeyDown={(event) => { if (event.key === 'Enter') window.location.href = `/listings?q=${encodeURIComponent(event.currentTarget.value)}`; }} /><Link href="/listings" data-testid="link-home-search" className="text-xs font-bold text-primary">Qidirish</Link></div></section>
    <section className="mt-9"><SectionHeading eyebrow="Bugun tanlangan" title="Yaxshi topilmalar" action={<Link href="/listings" data-testid="link-home-all-listings" className="flex items-center gap-1 text-xs font-bold text-primary">Barchasi <ChevronRight className="h-4 w-4" /></Link>} />
      {summaryQuery.isError && listingsQuery.isError ? <ErrorState onRetry={() => { void queryClient.invalidateQueries({ queryKey: getListListingsQueryKey({ limit: 6, sort: 'newest' }) }); void queryClient.invalidateQueries({ queryKey: summaryQuery.queryKey }); }} /> : loading ? <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">{[1, 2, 3].map((id) => <ListingSkeleton key={id} />)}</div> : items.length ? <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">{items.slice(0, 6).map((listing) => <ListingCard key={listing.id} listing={listing} saved={savedListings.includes(String(listing.id))} onSave={() => toggleListing(String(listing.id))} />)}</div> : <EmptyState title="Hali e’lonlar yo‘q" description="Birinchi bo‘lib o‘zingizning taklifingizni joylang." action={<Link href="/sell" data-testid="link-empty-sell" className="rounded-full bg-primary px-4 py-2.5 text-xs font-bold text-white">E’lon berish</Link>} />}
    </section>
    <section className="mt-9 grid gap-4 md:grid-cols-2"><Link href="/services" data-testid="link-home-service-banner" className="group flex items-center gap-4 rounded-[24px] border border-[#d4e6d7] bg-[#edf7ee] p-5 transition hover:-translate-y-0.5"><span className="grid h-12 w-12 shrink-0 place-items-center rounded-2xl bg-secondary text-white"><BriefcaseBusiness className="h-5 w-5" /></span><span className="min-w-0 flex-1"><span className="block text-[10px] font-bold uppercase tracking-[.15em] text-[#4d8a5c]">Xizmat kerakmi?</span><span className="mt-1 block font-display text-base font-bold text-secondary">Ishonchli ustani toping</span><span className="mt-1 block text-xs text-muted-foreground">Ta’mirlash, tozalash va boshqa ko‘nikmalar.</span></span><ChevronRight className="h-5 w-5 text-secondary transition group-hover:translate-x-1" /></Link><div className="flex items-center gap-4 rounded-[24px] border border-[#f1dec4] bg-[#fff8ec] p-5"><span className="grid h-12 w-12 shrink-0 place-items-center rounded-2xl bg-[#ffe0b0] text-[#9b6a25]"><ShieldCheck className="h-5 w-5" /></span><div><span className="block font-display text-base font-bold text-secondary">Ochiq va ishonchli</span><span className="mt-1 block text-xs leading-5 text-muted-foreground">Mahalliy bozor, aniq hudud va to‘g‘ridan-to‘g‘ri aloqa.</span></div></div></section>
  </AppShell>;
}

function Stat({ value, label, loading }: { value?: number; label: string; loading: boolean }) {
  return <div className="px-2 text-center" data-testid={`stat-${label}`}>{loading ? <span className="skeleton mx-auto block h-6 w-12 rounded" /> : <strong className="font-display text-2xl font-bold text-secondary">{value ?? '—'}</strong>}<span className="mt-1 block text-[10px] font-semibold text-muted-foreground">{label}</span></div>;
}
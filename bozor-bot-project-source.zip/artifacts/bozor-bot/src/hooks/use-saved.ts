import { useCallback, useEffect, useState } from 'react';

const KEY = 'bozor-bot-saved';
export function useSaved() {
  const [savedListings, setSavedListings] = useState<string[]>([]);
  const [savedServices, setSavedServices] = useState<string[]>([]);
  useEffect(() => {
    try {
      const value = JSON.parse(localStorage.getItem(KEY) ?? '{}') as { listings?: string[]; services?: string[] };
      setSavedListings(value.listings ?? []);
      setSavedServices(value.services ?? []);
    } catch { setSavedListings([]); setSavedServices([]); }
  }, []);
  const persist = useCallback((listings: string[], services: string[]) => localStorage.setItem(KEY, JSON.stringify({ listings, services })), []);
  const toggleListing = useCallback((id: string) => setSavedListings((current) => { const next = current.includes(id) ? current.filter((item) => item !== id) : [...current, id]; persist(next, savedServices); return next; }), [persist, savedServices]);
  const toggleService = useCallback((id: string) => setSavedServices((current) => { const next = current.includes(id) ? current.filter((item) => item !== id) : [...current, id]; persist(savedListings, next); return next; }), [persist, savedListings]);
  return { savedListings, savedServices, toggleListing, toggleService };
}
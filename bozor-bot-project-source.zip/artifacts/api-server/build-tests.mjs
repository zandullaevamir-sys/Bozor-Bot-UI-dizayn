import { build } from "esbuild";
import { createRequire } from "node:module";
import esbuildPluginPino from "esbuild-plugin-pino";

globalThis.require = createRequire(import.meta.url);

await build({
  entryPoints: ["src/security.test.ts"],
  outdir: "dist-tests",
  outExtension: { ".js": ".mjs" },
  bundle: true,
  platform: "node",
  format: "esm",
  external: ["pg-native"],
  sourcemap: "linked",
  plugins: [esbuildPluginPino({ transports: ["pino-pretty"] })],
  banner: {
    js: `import { createRequire as __testCreateRequire } from "node:module";
globalThis.require = __testCreateRequire(import.meta.url);`,
  },
});
import { Router, type IRouter } from "express";
import { and, asc, count, desc, eq, gte, ilike, lte, or } from "drizzle-orm";
import { db, listingsTable, serviceProfilesTable } from "@workspace/db";
import {
  CreateListingBody,
  CreateListingResponse,
  CreateServiceProfileBody,
  CreateServiceProfileResponse,
  GetListingParams,
  GetListingResponse,
  GetMarketplaceSummaryResponse,
  ListDistrictsResponse,
  ListListingsQueryParams,
  ListListingsResponse,
  ListServiceProfilesQueryParams,
  ListServiceProfilesResponse,
} from "@workspace/api-zod";

const router: IRouter = Router();

const districts = [
  { id: "nukus-shahri", name: "Nukus shahri", kind: "city" as const },
  { id: "nukus-tumani", name: "Nukus tumani", kind: "district" as const },
  { id: "amudaryo", name: "Amudaryo tumani", kind: "district" as const },
  { id: "beruniy", name: "Beruniy tumani", kind: "district" as const },
  { id: "bozatov", name: "Bo‘zatov tumani", kind: "district" as const },
  { id: "chimboy", name: "Chimboy tumani", kind: "district" as const },
  { id: "ellikqala", name: "Ellikqal’a tumani", kind: "district" as const },
  { id: "kegeyli", name: "Kegeyli tumani", kind: "district" as const },
  { id: "moynoq", name: "Mo‘ynoq tumani", kind: "district" as const },
  { id: "qanlikol", name: "Qanliko‘l tumani", kind: "district" as const },
  { id: "qoraozak", name: "Qorao‘zak tumani", kind: "district" as const },
  { id: "qongirot", name: "Qo‘ng‘irot tumani", kind: "district" as const },
  { id: "shumanay", name: "Shumanay tumani", kind: "district" as const },
  { id: "taxtakopir", name: "Taxtako‘pir tumani", kind: "district" as const },
  { id: "taxiatosh", name: "Taxiatosh shahri", kind: "city" as const },
  { id: "tortkol", name: "To‘rtko‘l tumani", kind: "district" as const },
  { id: "xojayli", name: "Xo‘jayli tumani", kind: "district" as const },
];

const districtNames = new Set(districts.map((district) => district.name));

router.get("/districts", (_req, res): void => {
  res.json(ListDistrictsResponse.parse(districts));
});

router.get("/marketplace/summary", async (_req, res): Promise<void> => {
  const [listingCountResult, serviceCountResult, featuredListings] = await Promise.all([
    db.select({ count: count() }).from(listingsTable).where(eq(listingsTable.status, "published")),
    db.select({ count: count() }).from(serviceProfilesTable),
    db
      .select()
      .from(listingsTable)
      .where(eq(listingsTable.status, "published"))
      .orderBy(desc(listingsTable.createdAt))
      .limit(6),
  ]);

  res.json(
    GetMarketplaceSummaryResponse.parse({
      listingCount: listingCountResult[0]?.count ?? 0,
      serviceCount: serviceCountResult[0]?.count ?? 0,
      districtCount: districts.length,
      featuredListings,
    }),
  );
});

router.get("/listings", async (req, res): Promise<void> => {
  const parsed = ListListingsQueryParams.safeParse(req.query);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const { q, kind, category, district, condition, minPrice, maxPrice, limit, offset, sort } = parsed.data;
  const filters = [eq(listingsTable.status, "published")];

  if (q) {
    const search = `%${q}%`;
    filters.push(or(ilike(listingsTable.title, search), ilike(listingsTable.description, search), ilike(listingsTable.category, search))!);
  }
  if (kind) filters.push(eq(listingsTable.kind, kind));
  if (category) filters.push(eq(listingsTable.category, category));
  if (district) filters.push(eq(listingsTable.district, district));
  if (condition && condition !== "any") filters.push(eq(listingsTable.condition, condition));
  if (minPrice !== undefined) filters.push(gte(listingsTable.price, minPrice));
  if (maxPrice !== undefined) filters.push(lte(listingsTable.price, maxPrice));

  const where = and(...filters);
  const orderBy =
    sort === "price_asc"
      ? asc(listingsTable.price)
      : sort === "price_desc"
        ? desc(listingsTable.price)
        : desc(listingsTable.createdAt);

  const [items, totalResult] = await Promise.all([
    db.select().from(listingsTable).where(where).orderBy(orderBy).limit(limit).offset(offset),
    db.select({ count: count() }).from(listingsTable).where(where),
  ]);

  res.json(
    ListListingsResponse.parse({
      items,
      total: totalResult[0]?.count ?? 0,
      limit,
      offset,
    }),
  );
});

router.post("/listings", async (req, res): Promise<void> => {
  const parsed = CreateListingBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  if (!districtNames.has(parsed.data.district)) {
    res.status(400).json({ error: "Tuman yoki shahar Qoraqalpog‘iston ro‘yxatidan tanlanishi kerak." });
    return;
  }

  const [listing] = await db
    .insert(listingsTable)
    .values({ ...parsed.data, status: "published" })
    .returning();

  res.status(201).json(CreateListingResponse.parse(listing));
});

router.get("/listings/:id", async (req, res): Promise<void> => {
  const params = GetListingParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const [listing] = await db
    .select()
    .from(listingsTable)
    .where(and(eq(listingsTable.id, params.data.id), eq(listingsTable.status, "published")));

  if (!listing) {
    res.status(404).json({ error: "E’lon topilmadi." });
    return;
  }

  res.json(GetListingResponse.parse(listing));
});

router.get("/service-profiles", async (req, res): Promise<void> => {
  const parsed = ListServiceProfilesQueryParams.safeParse(req.query);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const { q, category, district, onlyVerified, limit } = parsed.data;
  const filters = [];

  if (q) {
    const search = `%${q}%`;
    filters.push(or(ilike(serviceProfilesTable.name, search), ilike(serviceProfilesTable.title, search), ilike(serviceProfilesTable.bio, search))!);
  }
  if (category) filters.push(eq(serviceProfilesTable.category, category));
  if (district) filters.push(eq(serviceProfilesTable.district, district));
  if (onlyVerified) filters.push(eq(serviceProfilesTable.verified, true));

  const profiles = await db
    .select()
    .from(serviceProfilesTable)
    .where(filters.length ? and(...filters) : undefined)
    .orderBy(desc(serviceProfilesTable.verified), desc(serviceProfilesTable.rating), desc(serviceProfilesTable.createdAt))
    .limit(limit);

  res.json(ListServiceProfilesResponse.parse(profiles));
});

router.post("/service-profiles", async (req, res): Promise<void> => {
  const parsed = CreateServiceProfileBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  if (!districtNames.has(parsed.data.district)) {
    res.status(400).json({ error: "Tuman yoki shahar Qoraqalpog‘iston ro‘yxatidan tanlanishi kerak." });
    return;
  }

  const [profile] = await db
    .insert(serviceProfilesTable)
    .values({ ...parsed.data, rating: 5, verified: false })
    .returning();

  res.status(201).json(CreateServiceProfileResponse.parse(profile));
});

export default router;
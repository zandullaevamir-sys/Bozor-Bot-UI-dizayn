import { Router, type IRouter } from "express";
import { and, asc, count, desc, eq, gte, isNotNull } from "drizzle-orm";
import { db, adConversationsTable, adMessagesTable, usersTable } from "@workspace/db";
import {
  CreateAdConversationBody,
  CreateAdConversationResponse,
  CreateAdMessageBody,
  CreateAdMessageParams,
  CreateAdMessageResponse,
  GetAdminStatsResponse,
  ListAdConversationsResponse,
  ListAdMessagesParams,
  ListAdMessagesResponse,
} from "@workspace/api-zod";
import {
  getSessionUser,
  sendTelegramMiniAppNotification,
  TelegramApiError,
} from "../lib/telegram-auth";

const router: IRouter = Router();

export function canAccessConversation(
  conversation: { userId: number } | undefined,
  user: { id: number; isAdmin: boolean },
): boolean {
  return Boolean(conversation && (user.isAdmin || conversation.userId === user.id));
}

export function tashkentStartOfToday(now: Date): Date {
  const tashkentDate = new Intl.DateTimeFormat("en-CA", {
    timeZone: "Asia/Tashkent",
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
  }).format(now);
  return new Date(`${tashkentDate}T00:00:00+05:00`);
}

const conversationSelection = {
  id: adConversationsTable.id,
  userId: adConversationsTable.userId,
  subject: adConversationsTable.subject,
  status: adConversationsTable.status,
  userName: usersTable.firstName,
  createdAt: adConversationsTable.createdAt,
  updatedAt: adConversationsTable.updatedAt,
};

router.get("/advertising/conversations", async (req, res): Promise<void> => {
  const user = await getSessionUser(req);
  if (!user) {
    res.status(401).json({ error: "Kirish talab qilinadi." });
    return;
  }
  const rows = await db
    .select(conversationSelection)
    .from(adConversationsTable)
    .innerJoin(usersTable, eq(adConversationsTable.userId, usersTable.id))
    .where(user.isAdmin ? undefined : eq(adConversationsTable.userId, user.id))
    .orderBy(desc(adConversationsTable.updatedAt));
  res.json(ListAdConversationsResponse.parse(rows));
});

router.post("/advertising/conversations", async (req, res): Promise<void> => {
  const user = await getSessionUser(req);
  if (!user) {
    res.status(401).json({ error: "Kirish talab qilinadi." });
    return;
  }
  const parsed = CreateAdConversationBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const result = await db.transaction(async (tx) => {
    const [conversation] = await tx.insert(adConversationsTable).values({ userId: user.id, subject: parsed.data.subject }).returning();
    await tx.insert(adMessagesTable).values({ conversationId: conversation.id, senderId: user.id, body: parsed.data.message });
    return { ...conversation, userName: user.firstName };
  });
  res.status(201).json(CreateAdConversationResponse.parse(result));
});

async function accessibleConversation(id: number, user: { id: number; isAdmin: boolean }) {
  const [conversation] = await db.select().from(adConversationsTable).where(eq(adConversationsTable.id, id));
  return canAccessConversation(conversation, user) ? conversation : undefined;
}

function miniAppConversationUrl(conversationId: number): string | null {
  const domain = process.env.REPLIT_DOMAINS?.split(",")[0]?.trim();
  return domain ? `https://${domain}/advertise?conversation=${conversationId}` : null;
}

router.get("/advertising/conversations/:id/messages", async (req, res): Promise<void> => {
  const user = await getSessionUser(req);
  const params = ListAdMessagesParams.safeParse(req.params);
  if (!user) {
    res.status(401).json({ error: "Kirish talab qilinadi." });
    return;
  }
  if (!params.success || !(await accessibleConversation(params.data.id, user))) {
    res.status(403).json({ error: "Bu suhbatga ruxsat yo‘q." });
    return;
  }
  const messages = await db
    .select({
      id: adMessagesTable.id,
      conversationId: adMessagesTable.conversationId,
      senderId: adMessagesTable.senderId,
      senderName: usersTable.firstName,
      senderIsAdmin: usersTable.isAdmin,
      body: adMessagesTable.body,
      createdAt: adMessagesTable.createdAt,
    })
    .from(adMessagesTable)
    .innerJoin(usersTable, eq(adMessagesTable.senderId, usersTable.id))
    .where(eq(adMessagesTable.conversationId, params.data.id))
    .orderBy(asc(adMessagesTable.createdAt));
  res.json(ListAdMessagesResponse.parse(messages));
});

router.post("/advertising/conversations/:id/messages", async (req, res): Promise<void> => {
  const user = await getSessionUser(req);
  const params = CreateAdMessageParams.safeParse(req.params);
  const body = CreateAdMessageBody.safeParse(req.body);
  if (!user) {
    res.status(401).json({ error: "Kirish talab qilinadi." });
    return;
  }
  const conversation = params.success ? await accessibleConversation(params.data.id, user) : undefined;
  if (!params.success || !body.success || !conversation) {
    res.status(403).json({ error: "Xabar yuborishga ruxsat yo‘q." });
    return;
  }
  const [message] = await db.insert(adMessagesTable).values({ conversationId: params.data.id, senderId: user.id, body: body.data.body }).returning();
  await db.update(adConversationsTable).set({ updatedAt: new Date() }).where(eq(adConversationsTable.id, params.data.id));
  if (user.isAdmin) {
    const [recipient] = await db
      .select({ telegramId: usersTable.telegramId })
      .from(usersTable)
      .where(eq(usersTable.id, conversation.userId));
    const miniAppUrl = miniAppConversationUrl(conversation.id);
    if (recipient && miniAppUrl) {
      try {
        await sendTelegramMiniAppNotification({
          telegramId: recipient.telegramId,
          text: "Reklama murojaatingizga admin javob berdi.",
          buttonText: "Suhbatni ochish",
          miniAppUrl,
        });
      } catch (error) {
        req.log.warn({
          telegramOperation: error instanceof TelegramApiError ? error.operation : "sendMessage",
          telegramStatusCode: error instanceof TelegramApiError ? error.statusCode : undefined,
          conversationId: conversation.id,
          errorType: error instanceof Error ? error.name : "UnknownError",
        }, "Telegram notification delivery failed");
      }
    }
  }
  res.status(201).json(CreateAdMessageResponse.parse({ ...message, senderName: user.firstName, senderIsAdmin: user.isAdmin }));
});

router.get("/admin/stats", async (req, res): Promise<void> => {
  const user = await getSessionUser(req);
  if (!user?.isAdmin) {
    res.status(403).json({ error: "Admin ruxsati talab qilinadi." });
    return;
  }
  const today = tashkentStartOfToday(new Date());
  const [total, daily] = await Promise.all([
    db.select({ count: count() }).from(usersTable).where(isNotNull(usersTable.phone)),
    db.select({ count: count() }).from(usersTable).where(and(isNotNull(usersTable.phoneVerifiedAt), gte(usersTable.phoneVerifiedAt, today))),
  ]);
  res.json(GetAdminStatsResponse.parse({ totalUsers: total[0]?.count ?? 0, todayUsers: daily[0]?.count ?? 0 }));
});

export default router;
import { Router, type IRouter } from "express";
import healthRouter from "./health";
import marketplaceRouter from "./marketplace";
import telegramRouter from "./telegram";
import advertisingRouter from "./advertising";

const router: IRouter = Router();

router.use(healthRouter);
router.use(marketplaceRouter);
router.use(telegramRouter);
router.use(advertisingRouter);

export default router;

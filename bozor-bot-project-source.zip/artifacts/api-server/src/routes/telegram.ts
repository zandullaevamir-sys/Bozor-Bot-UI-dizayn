import { Router, type IRouter } from "express";
import { eq, sql } from "drizzle-orm";
import { db, usersTable } from "@workspace/db";
import {
  AuthenticateTelegramBody,
  AuthenticateTelegramResponse,
  GetCurrentUserResponse,
} from "@workspace/api-zod";
import {
  configuredAdminIds,
  createSessionToken,
  getSessionUser,
  isOwnTelegramContact,
  isWebhookRequestAuthorized,
  publicUser,
  sendTelegramMiniAppNotification,
  verifyTelegramInitData,
} from "../lib/telegram-auth";

const router: IRouter = Router();

router.post("/telegram/auth", async (req, res): Promise<void> => {
  const parsed = AuthenticateTelegramBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  try {
    const telegramUser = verifyTelegramInitData(parsed.data.initData);
    const isAdmin = configuredAdminIds().has(telegramUser.id);
    const [user] = await db
      .insert(usersTable)
      .values({
        telegramId: telegramUser.id,
        firstName: telegramUser.first_name,
        lastName: telegramUser.last_name ?? null,
        username: telegramUser.username ?? null,
        isAdmin,
      })
      .onConflictDoUpdate({
        target: usersTable.telegramId,
        set: {
          firstName: telegramUser.first_name,
          lastName: telegramUser.last_name ?? null,
          username: telegramUser.username ?? null,
          isAdmin,
          updatedAt: new Date(),
        },
      })
      .returning();
    res.json(AuthenticateTelegramResponse.parse({ token: createSessionToken(user.id), user: publicUser(user) }));
  } catch (error) {
    req.log.warn({ err: error }, "Telegram authentication rejected");
    res.status(401).json({ error: "Telegram ma’lumotlarini tekshirib bo‘lmadi." });
  }
});

router.get("/telegram/me", async (req, res): Promise<void> => {
  const user = await getSessionUser(req, { allowUnverified: true });
  if (!user) {
    res.status(401).json({ error: "Kirish talab qilinadi." });
    return;
  }
  res.json(GetCurrentUserResponse.parse(publicUser(user)));
});

router.post("/telegram/webhook", async (req, res): Promise<void> => {
  const received = req.get("x-telegram-bot-api-secret-token");
  if (!process.env.TELEGRAM_BOT_TOKEN || !isWebhookRequestAuthorized(received)) {
    res.status(401).json({ error: "Webhook ruxsati yo‘q." });
    return;
  }

  const message = req.body?.message;
  if (message?.text === "/start" && Number.isSafeInteger(message?.from?.id)) {
    const domain = process.env.REPLIT_DOMAINS?.split(",")[0]?.trim();
    if (domain) {
      try {
        await sendTelegramMiniAppNotification({
          telegramId: message.from.id,
          text: "Bozor Botga xush kelibsiz! Qoraqalpog‘istondagi e’lonlar va xizmatlarni ko‘rish uchun ilovani oching.",
          buttonText: "Bozor Botni ochish",
          miniAppUrl: `https://${domain}/`,
        });
      } catch (error) {
        req.log.error({ err: error }, "Telegram start message failed");
      }
    }
    res.sendStatus(204);
    return;
  }
  if (isOwnTelegramContact(message)) {
    const contact = message.contact;
    const senderId = message.from.id;
    await db
      .update(usersTable)
      .set({
        phone: String(contact.phone_number),
        phoneVerifiedAt: sql`coalesce(${usersTable.phoneVerifiedAt}, now())`,
        updatedAt: new Date(),
      })
      .where(eq(usersTable.telegramId, senderId));
  }
  res.sendStatus(204);
});

export default router;
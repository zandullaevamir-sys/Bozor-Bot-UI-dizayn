import app from "./app";
import { logger } from "./lib/logger";
import { webhookSecretToken } from "./lib/telegram-auth";

async function registerTelegramWebhook(): Promise<void> {
  const token = process.env.TELEGRAM_BOT_TOKEN;
  const secret = webhookSecretToken();
  const domain = process.env.REPLIT_DOMAINS?.split(",")[0]?.trim();
  if (!token || !secret || !domain) {
    logger.warn("Telegram webhook was not registered because its configuration is incomplete");
    return;
  }
  try {
    const response = await fetch(`https://api.telegram.org/bot${token}/setWebhook`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({
        url: `https://${domain}/api/telegram/webhook`,
        secret_token: secret,
        allowed_updates: ["message"],
      }),
    });
    if (!response.ok) throw new Error(`Telegram returned HTTP ${response.status}`);
    const menuResponse = await fetch(`https://api.telegram.org/bot${token}/setChatMenuButton`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({
        menu_button: {
          type: "web_app",
          text: "Bozor Botni ochish",
          web_app: { url: `https://${domain}/` },
        },
      }),
    });
    if (!menuResponse.ok) throw new Error(`Telegram menu button returned HTTP ${menuResponse.status}`);
    logger.info("Telegram webhook registered");
  } catch (error) {
    logger.error({ err: error }, "Telegram webhook registration failed");
  }
}

const rawPort = process.env["PORT"];

if (!rawPort) {
  throw new Error(
    "PORT environment variable is required but was not provided.",
  );
}

const port = Number(rawPort);

if (Number.isNaN(port) || port <= 0) {
  throw new Error(`Invalid PORT value: "${rawPort}"`);
}

app.listen(port, (err) => {
  if (err) {
    logger.error({ err }, "Error listening on port");
    process.exit(1);
  }

  logger.info({ port }, "Server listening");
  void registerTelegramWebhook();
});

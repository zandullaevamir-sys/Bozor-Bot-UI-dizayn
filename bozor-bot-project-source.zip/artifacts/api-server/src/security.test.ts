import assert from "node:assert/strict";
import crypto from "node:crypto";
import type { Server } from "node:http";
import { after, before, test } from "node:test";
import type { db as Db, pool as Pool, usersTable as UsersTable } from "@workspace/db";

const telegramIds = [8_900_001, 8_900_002, 8_900_003];
const schemaName = `security_test_${process.pid}`;
let db: typeof Db;
let pool: typeof Pool;
let usersTable: typeof UsersTable;
let server: Server;
let baseUrl: string;
let webhookSecretToken: () => string | null;
const telegramRequests: Array<{ chat_id: number; text: string; reply_markup: unknown }> = [];
let telegramSendStatus = 200;
const originalFetch = globalThis.fetch;

function signedInitData(
  user: { id: number; first_name: string; last_name?: string; username?: string },
  authDate = Math.floor(Date.now() / 1000),
): string {
  return signedRawInitData(JSON.stringify(user), authDate);
}

function signedRawInitData(rawUser: string, authDate = Math.floor(Date.now() / 1000)): string {
  const params = new URLSearchParams({
    auth_date: String(authDate),
    query_id: "security-regression-test",
    user: rawUser,
  });
  const dataCheckString = [...params.entries()]
    .sort(([left], [right]) => left.localeCompare(right))
    .map(([key, value]) => `${key}=${value}`)
    .join("\n");
  const secretKey = crypto.createHmac("sha256", "WebAppData").update(process.env.TELEGRAM_BOT_TOKEN!).digest();
  params.set("hash", crypto.createHmac("sha256", secretKey).update(dataCheckString).digest("hex"));
  return params.toString();
}

async function request(path: string, init: RequestInit = {}) {
  const response = await fetch(`${baseUrl}/api${path}`, {
    ...init,
    headers: { "content-type": "application/json", ...init.headers },
  });
  const body: unknown = response.status === 204 ? null : await response.json();
  return { response, body };
}

async function authenticate(telegramId: number, firstName: string) {
  const result = await request("/telegram/auth", {
    method: "POST",
    body: JSON.stringify({ initData: signedInitData({ id: telegramId, first_name: firstName }) }),
  });
  assert.equal(result.response.status, 200);
  const body = result.body as { token: string; user: { id: number; telegramId: number } };
  assert.equal(body.user.telegramId, telegramId);
  assert.match(body.token, /^[^.]+\.[^.]+$/);
  return body;
}

before(async () => {
  process.env.TELEGRAM_BOT_TOKEN = "security-test-bot-token";
  process.env.SESSION_SECRET = "security-test-session-secret";
  process.env.TELEGRAM_WEBHOOK_SECRET = "security-test-webhook-secret";
  process.env.ADMIN_TELEGRAM_IDS = "";
  process.env.REPLIT_DOMAINS = "bozor-bot.example.com";
  globalThis.fetch = async (input, init) => {
    if (String(input).startsWith("https://api.telegram.org/") && String(input).endsWith("/sendMessage")) {
      telegramRequests.push(JSON.parse(String(init?.body)));
      return new Response(JSON.stringify({ ok: telegramSendStatus === 200 }), {
        status: telegramSendStatus,
        headers: { "content-type": "application/json" },
      });
    }
    return originalFetch(input, init);
  };

  const dbModule = await import("@workspace/db");
  db = dbModule.db;
  pool = dbModule.pool;
  usersTable = dbModule.usersTable;
  pool.options.max = 1;
  const client = await pool.connect();
  try {
    await client.query(`create schema "${schemaName}"`);
    await client.query(`set search_path to "${schemaName}"`);
    await client.query(`
      create table users (
        id serial primary key,
        telegram_id bigint not null unique,
        first_name text not null,
        last_name text,
        username text,
        phone text,
        phone_verified_at timestamptz,
        is_admin boolean not null default false,
        created_at timestamptz not null default now(),
        updated_at timestamptz not null default now()
      );
      create table ad_conversations (
        id serial primary key,
        user_id integer not null references users(id) on delete cascade,
        subject text not null,
        status text not null default 'open',
        created_at timestamptz not null default now(),
        updated_at timestamptz not null default now()
      );
      create table ad_messages (
        id serial primary key,
        conversation_id integer not null references ad_conversations(id) on delete cascade,
        sender_id integer not null references users(id) on delete cascade,
        body text not null,
        created_at timestamptz not null default now()
      );
    `);
  } finally {
    client.release();
  }

  const [{ default: app }, authModule] = await Promise.all([
    import("./app"),
    import("./lib/telegram-auth"),
  ]);
  webhookSecretToken = authModule.webhookSecretToken;
  await new Promise<void>((resolve) => {
    server = app.listen(0, "127.0.0.1", () => {
      const address = server.address();
      assert(address && typeof address === "object");
      baseUrl = `http://127.0.0.1:${address.port}`;
      resolve();
    });
  });
});

after(async () => {
  globalThis.fetch = originalFetch;
  if (server) {
    await new Promise<void>((resolve, reject) => server.close((error) => (error ? reject(error) : resolve())));
  }
  await pool.query(`drop schema "${schemaName}" cascade`);
  await pool.end();
});

test("Telegram auth accepts valid initData and rejects invalid or expired data", async () => {
  await authenticate(telegramIds[0], "Valid");

  const invalidParams = new URLSearchParams(signedInitData({ id: telegramIds[1], first_name: "Invalid" }));
  invalidParams.set("hash", "00".repeat(32));
  const invalid = await request("/telegram/auth", {
    method: "POST",
    body: JSON.stringify({ initData: invalidParams.toString() }),
  });
  assert.equal(invalid.response.status, 401);

  const expired = await request("/telegram/auth", {
    method: "POST",
    body: JSON.stringify({
      initData: signedInitData({ id: telegramIds[1], first_name: "Expired" }, Math.floor(Date.now() / 1000) - 86_401),
    }),
  });
  assert.equal(expired.response.status, 401);
});

test("Telegram auth persists valid optional profile names and still accepts profiles without them", async () => {
  const profile = {
    id: 8_900_102,
    first_name: "Profile",
    last_name: "Family",
    username: "profile_user",
  };
  const named = await request("/telegram/auth", {
    method: "POST",
    body: JSON.stringify({ initData: signedInitData(profile) }),
  });
  assert.equal(named.response.status, 200);
  const namedUser = (named.body as {
    user: { lastName: string | null; username: string | null };
  }).user;
  assert.equal(namedUser.lastName, profile.last_name);
  assert.equal(namedUser.username, profile.username);

  const storedNamedUser = await db.query.usersTable.findFirst({
    where: (users, { eq }) => eq(users.telegramId, profile.id),
  });
  assert.equal(storedNamedUser?.lastName, profile.last_name);
  assert.equal(storedNamedUser?.username, profile.username);

  const minimalProfile = { id: 8_900_103, first_name: "Minimal" };
  const minimal = await request("/telegram/auth", {
    method: "POST",
    body: JSON.stringify({ initData: signedInitData(minimalProfile) }),
  });
  assert.equal(minimal.response.status, 200);
  const minimalUser = (minimal.body as {
    user: { lastName: string | null; username: string | null };
  }).user;
  assert.equal(minimalUser.lastName, null);
  assert.equal(minimalUser.username, null);

  const storedMinimalUser = await db.query.usersTable.findFirst({
    where: (users, { eq }) => eq(users.telegramId, minimalProfile.id),
  });
  assert.equal(storedMinimalUser?.lastName, null);
  assert.equal(storedMinimalUser?.username, null);
});

test("Telegram auth rejects signed malformed user data without stopping the server", async () => {
  const invalidUsers = [
    '{"id":8900100,"first_name":',
    JSON.stringify({ id: Number.MAX_SAFE_INTEGER + 1, first_name: "Unsafe ID" }),
    JSON.stringify({ id: 8_900_100, first_name: "   " }),
    JSON.stringify({ id: 8_900_100, first_name: "Invalid last name", last_name: 123 }),
    JSON.stringify({ id: 8_900_100, first_name: "Invalid username", username: false }),
  ];

  for (const rawUser of invalidUsers) {
    const rejected = await request("/telegram/auth", {
      method: "POST",
      body: JSON.stringify({ initData: signedRawInitData(rawUser) }),
    });
    assert.equal(rejected.response.status, 401);
    assert.deepEqual(rejected.body, { error: "Telegram ma’lumotlarini tekshirib bo‘lmadi." });
  }

  await authenticate(8_900_101, "Still running");
});

test("webhook rejects a wrong secret, ignores foreign contacts, and persists an owned contact", async () => {
  const wrongSecret = await request("/telegram/webhook", {
    method: "POST",
    headers: { "x-telegram-bot-api-secret-token": "wrong" },
    body: JSON.stringify({ message: {} }),
  });
  assert.equal(wrongSecret.response.status, 401);

  const foreignContact = await request("/telegram/webhook", {
    method: "POST",
    headers: { "x-telegram-bot-api-secret-token": webhookSecretToken()! },
    body: JSON.stringify({
      message: {
        from: { id: telegramIds[0] },
        contact: { user_id: telegramIds[1], phone_number: "+998900000001" },
      },
    }),
  });
  assert.equal(foreignContact.response.status, 204);
  let user = await db.query.usersTable.findFirst({
    where: (users, { eq }) => eq(users.telegramId, telegramIds[0]),
  });
  assert.equal(user?.phone, null);

  const ownedContact = await request("/telegram/webhook", {
    method: "POST",
    headers: { "x-telegram-bot-api-secret-token": webhookSecretToken()! },
    body: JSON.stringify({
      message: {
        from: { id: telegramIds[0] },
        contact: { user_id: telegramIds[0], phone_number: "+998900000001" },
      },
    }),
  });
  assert.equal(ownedContact.response.status, 204);
  user = await db.query.usersTable.findFirst({
    where: (users, { eq }) => eq(users.telegramId, telegramIds[0]),
  });
  assert.equal(user?.phone, "+998900000001");
  assert(user?.phoneVerifiedAt);
});

test("an unverified user cannot access advertising APIs", async () => {
  const { token } = await authenticate(telegramIds[1], "Unverified");
  const result = await request("/advertising/conversations", {
    headers: { authorization: `Bearer ${token}` },
  });
  assert.equal(result.response.status, 401);
});

test("foreign message reads and writes are blocked, while admin revocation applies immediately", async () => {
  const ownerAuth = await authenticate(telegramIds[0], "Owner");
  const adminAuth = await authenticate(telegramIds[1], "Admin");
  await db
    .update(usersTable)
    .set({ phone: "+998900000002", phoneVerifiedAt: new Date() })
    .where((await import("drizzle-orm")).eq(usersTable.telegramId, telegramIds[1]));

  const created = await request("/advertising/conversations", {
    method: "POST",
    headers: { authorization: `Bearer ${ownerAuth.token}` },
    body: JSON.stringify({ subject: "Private", message: "Owner message" }),
  });
  assert.equal(created.response.status, 201);
  const conversationId = (created.body as { id: number }).id;

  for (const method of ["GET", "POST"]) {
    const foreign = await request(`/advertising/conversations/${conversationId}/messages`, {
      method,
      headers: { authorization: `Bearer ${adminAuth.token}` },
      body: method === "POST" ? JSON.stringify({ body: "Forbidden message" }) : undefined,
    });
    assert.equal(foreign.response.status, 403);
  }

  process.env.ADMIN_TELEGRAM_IDS = String(telegramIds[1]);
  const adminRead = await request(`/advertising/conversations/${conversationId}/messages`, {
    headers: { authorization: `Bearer ${adminAuth.token}` },
  });
  assert.equal(adminRead.response.status, 200);
  assert.equal((adminRead.body as unknown[]).length, 1);
  const adminWrite = await request(`/advertising/conversations/${conversationId}/messages`, {
    method: "POST",
    headers: { authorization: `Bearer ${adminAuth.token}` },
    body: JSON.stringify({ body: "Admin message" }),
  });
  assert.equal(adminWrite.response.status, 201);

  process.env.ADMIN_TELEGRAM_IDS = "";
  const revokedRead = await request(`/advertising/conversations/${conversationId}/messages`, {
    headers: { authorization: `Bearer ${adminAuth.token}` },
  });
  assert.equal(revokedRead.response.status, 403);
  const revokedWrite = await request(`/advertising/conversations/${conversationId}/messages`, {
    method: "POST",
    headers: { authorization: `Bearer ${adminAuth.token}` },
    body: JSON.stringify({ body: "Revoked message" }),
  });
  assert.equal(revokedWrite.response.status, 403);
});

test("admin replies notify the owner with a conversation link and delivery failure does not undo the message", async () => {
  const ownerAuth = await authenticate(telegramIds[0], "Notification owner");
  const adminAuth = await authenticate(telegramIds[1], "Notification admin");
  await db
    .update(usersTable)
    .set({ phone: "+998900000002", phoneVerifiedAt: new Date() })
    .where((await import("drizzle-orm")).eq(usersTable.telegramId, telegramIds[1]));
  process.env.ADMIN_TELEGRAM_IDS = String(telegramIds[1]);

  const created = await request("/advertising/conversations", {
    method: "POST",
    headers: { authorization: `Bearer ${ownerAuth.token}` },
    body: JSON.stringify({ subject: "Notify me", message: "Owner message" }),
  });
  const conversationId = (created.body as { id: number }).id;

  telegramSendStatus = 200;
  const delivered = await request(`/advertising/conversations/${conversationId}/messages`, {
    method: "POST",
    headers: { authorization: `Bearer ${adminAuth.token}` },
    body: JSON.stringify({ body: "First admin reply" }),
  });
  assert.equal(delivered.response.status, 201);
  const notification = telegramRequests.at(-1);
  assert.equal(notification?.chat_id, telegramIds[0]);
  assert.match(notification?.text ?? "", /admin javob berdi/);
  assert.deepEqual(notification?.reply_markup, {
    inline_keyboard: [[{
      text: "Suhbatni ochish",
      web_app: { url: `https://bozor-bot.example.com/advertise?conversation=${conversationId}` },
    }]],
  });

  telegramSendStatus = 500;
  const failedDelivery = await request(`/advertising/conversations/${conversationId}/messages`, {
    method: "POST",
    headers: { authorization: `Bearer ${adminAuth.token}` },
    body: JSON.stringify({ body: "Saved despite Telegram failure" }),
  });
  assert.equal(failedDelivery.response.status, 201);
  const messages = await request(`/advertising/conversations/${conversationId}/messages`, {
    headers: { authorization: `Bearer ${ownerAuth.token}` },
  });
  assert.equal(messages.response.status, 200);
  assert.equal((messages.body as Array<{ body: string }>).at(-1)?.body, "Saved despite Telegram failure");
  telegramSendStatus = 200;
});

test("today statistics include the Asia/Tashkent midnight boundary and exclude one millisecond before it", async () => {
  process.env.ADMIN_TELEGRAM_IDS = String(telegramIds[0]);
  const adminAuth = await authenticate(telegramIds[0], "Stats admin");
  const tashkentDate = new Intl.DateTimeFormat("en-CA", {
    timeZone: "Asia/Tashkent",
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
  }).format(new Date());
  const boundary = new Date(`${tashkentDate}T00:00:00+05:00`);

  await db.insert(usersTable).values([
    {
      telegramId: telegramIds[2],
      firstName: "Before boundary",
      phone: "+998900000003",
      phoneVerifiedAt: new Date(boundary.getTime() - 1),
    },
  ]);
  await db
    .update(usersTable)
    .set({ phoneVerifiedAt: boundary })
    .where((await import("drizzle-orm")).eq(usersTable.telegramId, telegramIds[1]));

  const stats = await request("/admin/stats", {
    headers: { authorization: `Bearer ${adminAuth.token}` },
  });
  assert.equal(stats.response.status, 200);
  assert.equal((stats.body as { todayUsers: number }).todayUsers, 2);
});
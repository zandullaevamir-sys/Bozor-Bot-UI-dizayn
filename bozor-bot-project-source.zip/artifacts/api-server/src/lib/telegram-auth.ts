import crypto from "node:crypto";
import type { Request } from "express";
import { eq } from "drizzle-orm";
import { db, usersTable, type User } from "@workspace/db";

type TelegramUserData = {
  id: number;
  first_name: string;
  last_name?: string;
  username?: string;
};

function requiredSecret(name: "TELEGRAM_BOT_TOKEN" | "SESSION_SECRET"): string {
  const value = process.env[name];
  if (!value) throw new Error(`${name} must be configured.`);
  return value;
}

export class TelegramApiError extends Error {
  constructor(
    public readonly operation: string,
    public readonly statusCode: number,
  ) {
    super(`Telegram API request failed with HTTP ${statusCode}.`);
    this.name = "TelegramApiError";
  }
}

export async function sendTelegramMiniAppNotification(options: {
  telegramId: number;
  text: string;
  buttonText: string;
  miniAppUrl: string;
}): Promise<void> {
  const response = await fetch(`https://api.telegram.org/bot${requiredSecret("TELEGRAM_BOT_TOKEN")}/sendMessage`, {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({
      chat_id: options.telegramId,
      text: options.text,
      reply_markup: {
        inline_keyboard: [[{
          text: options.buttonText,
          web_app: { url: options.miniAppUrl },
        }]],
      },
    }),
  });
  if (!response.ok) {
    throw new TelegramApiError("sendMessage", response.status);
  }
}

export function verifyTelegramInitData(initData: string): TelegramUserData {
  const params = new URLSearchParams(initData);
  const receivedHash = params.get("hash");
  if (!receivedHash) throw new Error("Telegram hash is missing.");
  params.delete("hash");

  const authDate = Number(params.get("auth_date"));
  if (!Number.isFinite(authDate) || Math.abs(Date.now() / 1000 - authDate) > 86400) {
    throw new Error("Telegram authentication data has expired.");
  }

  const dataCheckString = [...params.entries()]
    .sort(([left], [right]) => left.localeCompare(right))
    .map(([key, value]) => `${key}=${value}`)
    .join("\n");
  const secretKey = crypto.createHmac("sha256", "WebAppData").update(requiredSecret("TELEGRAM_BOT_TOKEN")).digest();
  const expectedHash = crypto.createHmac("sha256", secretKey).update(dataCheckString).digest("hex");
  const expected = Buffer.from(expectedHash, "hex");
  const received = Buffer.from(receivedHash, "hex");
  if (expected.length !== received.length || !crypto.timingSafeEqual(expected, received)) {
    throw new Error("Telegram signature is invalid.");
  }

  const rawUser = params.get("user");
  if (!rawUser) throw new Error("Telegram user is missing.");
  const user = JSON.parse(rawUser) as Partial<TelegramUserData> | null;
  if (
    !user
    || typeof user.id !== "number"
    || !Number.isSafeInteger(user.id)
    || typeof user.first_name !== "string"
    || user.first_name.trim().length === 0
    || (user.last_name !== undefined && typeof user.last_name !== "string")
    || (user.username !== undefined && typeof user.username !== "string")
  ) {
    throw new Error("Telegram user is invalid.");
  }
  return {
    id: user.id,
    first_name: user.first_name,
    last_name: user.last_name,
    username: user.username,
  };
}

export function isPhoneVerified(user: Pick<User, "phone">): boolean {
  return Boolean(user.phone);
}

export function isCurrentAdmin(telegramId: number): boolean {
  return configuredAdminIds().has(telegramId);
}

export function createSessionToken(userId: number): string {
  const payload = Buffer.from(JSON.stringify({ userId, expiresAt: Date.now() + 30 * 24 * 60 * 60 * 1000 })).toString("base64url");
  const signature = crypto.createHmac("sha256", requiredSecret("SESSION_SECRET")).update(payload).digest("base64url");
  return `${payload}.${signature}`;
}

export async function getSessionUser(req: Request, options: { allowUnverified?: boolean } = {}): Promise<User | null> {
  const authorization = req.get("authorization");
  if (!authorization?.startsWith("Bearer ")) return null;
  const [payload, signature] = authorization.slice(7).split(".");
  if (!payload || !signature) return null;
  const expected = crypto.createHmac("sha256", requiredSecret("SESSION_SECRET")).update(payload).digest();
  const received = Buffer.from(signature, "base64url");
  if (expected.length !== received.length || !crypto.timingSafeEqual(expected, received)) return null;
  try {
    const session = JSON.parse(Buffer.from(payload, "base64url").toString()) as { userId: number; expiresAt: number };
    if (session.expiresAt < Date.now()) return null;
    const [user] = await db.select().from(usersTable).where(eq(usersTable.id, session.userId));
    if (!user || (!options.allowUnverified && !isPhoneVerified(user))) return null;
    return { ...user, isAdmin: isCurrentAdmin(user.telegramId) };
  } catch {
    return null;
  }
}

export function configuredAdminIds(): Set<number> {
  return new Set(
    (process.env.ADMIN_TELEGRAM_IDS ?? "")
      .split(",")
      .map((value) => Number(value.trim()))
      .filter(Number.isSafeInteger),
  );
}

export function webhookSecretToken(): string | null {
  const secret = process.env.TELEGRAM_WEBHOOK_SECRET;
  return secret ? crypto.createHash("sha256").update(secret).digest("hex") : null;
}

export function isWebhookRequestAuthorized(received: string | undefined): boolean {
  const expected = webhookSecretToken();
  if (!expected || !received) return false;
  const expectedBuffer = Buffer.from(expected);
  const receivedBuffer = Buffer.from(received);
  return expectedBuffer.length === receivedBuffer.length && crypto.timingSafeEqual(expectedBuffer, receivedBuffer);
}

export function isOwnTelegramContact(message: unknown): message is {
  contact: { phone_number: string | number; user_id: number };
  from: { id: number };
} {
  const candidate = message as {
    contact?: { phone_number?: unknown; user_id?: unknown };
    from?: { id?: unknown };
  } | null;
  return Boolean(
    candidate?.contact?.phone_number
      && Number.isSafeInteger(candidate.from?.id)
      && candidate.contact.user_id === candidate.from?.id,
  );
}

export function publicUser(user: User) {
  return {
    id: user.id,
    telegramId: user.telegramId,
    firstName: user.firstName,
    lastName: user.lastName,
    username: user.username,
    phone: user.phone,
    isAdmin: user.isAdmin,
    createdAt: user.createdAt,
  };
}
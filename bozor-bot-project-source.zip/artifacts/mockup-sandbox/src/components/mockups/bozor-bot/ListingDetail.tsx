import { useState } from "react";
import {
  ArrowLeft,
  BadgeCheck,
  Bookmark,
  Check,
  ChevronRight,
  Clock3,
  Copy,
  Heart,
  MessageCircle,
  Phone,
  ShieldCheck,
  Share2,
  Star,
  Tag,
} from "lucide-react";
import {
  AppShell,
  Pill,
  ProductImage,
  SellerAvatar,
} from "./_shared/AppShell";

const galleryTones = ["blue", "purple", "green"] as const;

function PhoneGlyph({ variant = 0 }: { variant?: number }) {
  const accent = variant === 1 ? "bg-[#d7c7f0]" : variant === 2 ? "bg-[#c9e4d1]" : "bg-[#b9dce5]";
  return (
    <div className="relative h-[146px] w-[78px] rotate-[7deg] rounded-[19px] border-[3px] border-[#273734] bg-[#344a47] shadow-[10px_12px_0_rgba(23,33,30,0.10)]">
      <div className={`absolute inset-[5px] overflow-hidden rounded-[14px] ${accent}`}>
        <span className="absolute -left-3 top-8 h-20 w-20 rounded-full bg-white/35" />
        <span className="absolute -bottom-5 -right-5 h-20 w-20 rounded-full bg-[#ffffff]/30" />
        <span className="absolute left-1/2 top-1/2 h-9 w-9 -translate-x-1/2 -translate-y-1/2 rounded-full border border-white/60 bg-white/30" />
      </div>
      <span className="absolute left-1/2 top-1.5 h-1.5 w-7 -translate-x-1/2 rounded-full bg-[#1e2c2a]" />
      <span className="absolute -left-[5px] top-8 h-9 w-1 rounded-l-full bg-[#273734]" />
      <span className="absolute -right-[5px] top-12 h-6 w-1 rounded-r-full bg-[#273734]" />
    </div>
  );
}

export function ListingDetail() {
  const [saved, setSaved] = useState(false);
  const [activeGallery, setActiveGallery] = useState(0);
  const [notice, setNotice] = useState("");
  const [contactMode, setContactMode] = useState<"phone" | "message" | null>(null);

  const showNotice = (message: string) => {
    setNotice(message);
    window.setTimeout(() => setNotice(""), 2400);
  };

  const handleShare = async () => {
    const shareText = "Bozor Botdagi e’lon: Apple iPhone 13 128GB";
    try {
      if (navigator.share) {
        await navigator.share({ title: shareText, text: shareText, url: window.location.href });
      } else if (navigator.clipboard) {
        await navigator.clipboard.writeText(window.location.href);
        showNotice("E’lon havolasi nusxalandi");
      } else {
        showNotice("Havola tayyor");
      }
    } catch {
      showNotice("Ulashish bekor qilindi");
    }
  };

  return (
    <AppShell
      active="search"
      title="E’lon tafsilotlari"
      showBack
      onBack={() => window.history.back()}
      rightAction={
        <button
          onClick={handleShare}
          className="flex h-9 w-9 items-center justify-center rounded-full border border-[#dfe6df] bg-white text-[#34443d] transition hover:border-[#ffb294] hover:text-[#ff6b35]"
          aria-label="E’lonni ulashish"
        >
          <Share2 className="h-4 w-4" />
        </button>
      }
    >
      <div className="relative">
        {notice && (
          <div
            role="status"
            className="fixed left-1/2 top-[82px] z-40 flex -translate-x-1/2 items-center gap-2 rounded-full bg-[#17211e] px-4 py-2.5 text-[12px] font-bold text-white shadow-[0_10px_28px_rgba(23,33,30,0.22)]"
          >
            <Check className="h-3.5 w-3.5 text-[#ff9b75]" />
            {notice}
          </div>
        )}

        <section className="px-5 pb-5 pt-4">
          <div className="relative">
            <ProductImage
              tone={galleryTones[activeGallery]}
              label={`${activeGallery + 1} / 3`}
              className="h-[292px] rounded-[26px]"
              visual={<PhoneGlyph variant={activeGallery} />}
            />
            <div className="absolute right-3 top-3 flex items-center gap-2">
              <button
                onClick={() => {
                  setSaved((value) => !value);
                  showNotice(saved ? "Saqlanganlardan olib tashlandi" : "E’lon saqlandi");
                }}
                className={`flex h-10 w-10 items-center justify-center rounded-full border border-white/70 shadow-sm backdrop-blur-md transition ${
                  saved ? "bg-[#fff0e9] text-[#ff6b35]" : "bg-white/80 text-[#34443d]"
                }`}
                aria-label={saved ? "Saqlanganlardan olib tashlash" : "E’lonni saqlash"}
              >
                <Bookmark className={`h-[18px] w-[18px] ${saved ? "fill-current" : ""}`} />
              </button>
              <button
                onClick={handleShare}
                className="flex h-10 w-10 items-center justify-center rounded-full border border-white/70 bg-white/80 text-[#34443d] shadow-sm backdrop-blur-md transition hover:text-[#ff6b35]"
                aria-label="Ulashish"
              >
                <Share2 className="h-[17px] w-[17px]" />
              </button>
            </div>
            <div className="absolute bottom-3 left-1/2 flex -translate-x-1/2 gap-1.5 rounded-full bg-white/65 px-2 py-1.5 backdrop-blur-md">
              {[0, 1, 2].map((item) => (
                <button
                  key={item}
                  onClick={() => setActiveGallery(item)}
                  className={`h-1.5 rounded-full transition-all ${
                    activeGallery === item ? "w-5 bg-[#ff6b35]" : "w-1.5 bg-[#99a9a0]"
                  }`}
                  aria-label={`${item + 1}-rasmni ko‘rish`}
                />
              ))}
            </div>
          </div>
          <div className="mt-3 flex gap-2">
            {[0, 1, 2].map((item) => (
              <button
                key={item}
                onClick={() => setActiveGallery(item)}
                className={`h-14 w-14 overflow-hidden rounded-[13px] border-2 p-1 transition ${
                  activeGallery === item ? "border-[#ff6b35] bg-white" : "border-transparent bg-white/70"
                }`}
                aria-label={`${item + 1}-rasm`}
              >
                <ProductImage
                  tone={galleryTones[item]}
                  className="h-full w-full rounded-[9px]"
                  visual={<PhoneGlyph variant={item} />}
                />
              </button>
            ))}
            <span className="ml-auto flex items-center gap-1 self-center text-[11px] font-semibold text-[#84928a]">
              <Clock3 className="h-3.5 w-3.5" /> 12 daqiqa oldin
            </span>
          </div>
        </section>

        <section className="border-b border-[#e6ebe5] bg-white px-5 pb-5 pt-1">
          <div className="flex items-start justify-between gap-3">
            <div>
              <div className="mb-2 flex items-center gap-2">
                <Pill active icon={<Tag className="h-3 w-3" />}>
                  Elektronika
                </Pill>
                <span className="text-[11px] font-semibold text-[#91a098]">Yangi kabi</span>
              </div>
              <h2 className="max-w-[280px] text-[25px] font-extrabold leading-[1.08] tracking-[-0.055em] text-[#17211e]">
                Apple iPhone 13
                <span className="block text-[#617168]">128GB, Midnight</span>
              </h2>
            </div>
            <button
              onClick={() => showNotice("Qiziqish bildirildi")}
              className="mt-1 text-[#bdc8c1] transition hover:text-[#ff6b35]"
              aria-label="Qiziq deb belgilash"
            >
              <Heart className="h-5 w-5" />
            </button>
          </div>
          <div className="mt-4 flex items-end justify-between">
            <div>
              <p className="text-[28px] font-black tracking-[-0.06em] text-[#ff6b35]">5 850 000 so’m</p>
              <p className="mt-0.5 text-[11px] text-[#91a098]">Kelishiladi · yetkazib berish bor</p>
            </div>
            <div className="flex items-center gap-1 rounded-full bg-[#fff4df] px-2.5 py-1.5 text-[11px] font-bold text-[#9c6a18]">
              <ShieldCheck className="h-3.5 w-3.5" /> Tekshirilgan
            </div>
          </div>
        </section>

        <section className="space-y-4 border-b border-[#e6ebe5] px-5 py-5">
          <div className="flex items-center justify-between">
            <h3 className="text-[16px] font-extrabold tracking-[-0.03em] text-[#17211e]">Sotuvchi haqida</h3>
            <button
              onClick={() => showNotice("Profil ochilishi mumkin")}
              className="flex items-center gap-1 text-[11px] font-bold text-[#ff6b35]"
            >
              Profilni ko‘rish <ChevronRight className="h-3.5 w-3.5" />
            </button>
          </div>
          <div className="flex items-center gap-3">
            <SellerAvatar initials="SA" tone="bg-[#f6d4c7] text-[#9c5036]" />
            <div className="min-w-0 flex-1">
              <div className="flex items-center gap-1.5">
                <p className="text-[14px] font-extrabold text-[#24332e]">Sardor Akmalov</p>
                <BadgeCheck className="h-4 w-4 fill-[#ff6b35] text-white" />
              </div>
              <p className="mt-0.5 text-[11px] text-[#84928a]">Bozor Bot’da 2022-yildan beri</p>
            </div>
            <div className="text-right">
              <div className="flex items-center justify-end gap-1 text-[13px] font-extrabold text-[#24332e]">
                <Star className="h-3.5 w-3.5 fill-[#f2ae45] text-[#f2ae45]" /> 4.9
              </div>
              <p className="mt-0.5 text-[10px] text-[#91a098]">47 ta baho</p>
            </div>
          </div>
          <div className="grid grid-cols-3 gap-2">
            {[
              ["98%", "javob beradi"],
              ["26 ta", "savdo"],
              ["10 daq.", "o‘rtacha javob"],
            ].map(([value, label]) => (
              <div key={label} className="rounded-[14px] bg-[#f5f8f4] px-2 py-2.5 text-center">
                <p className="text-[13px] font-extrabold text-[#2e6950]">{value}</p>
                <p className="mt-0.5 text-[10px] text-[#84928a]">{label}</p>
              </div>
            ))}
          </div>
        </section>

        <section className="border-b border-[#e6ebe5] bg-[#fffdf8] px-5 py-5">
          <h3 className="text-[16px] font-extrabold tracking-[-0.03em] text-[#17211e]">E’lon haqida</h3>
          <p className="mt-3 text-[13px] leading-[1.65] text-[#63736a]">
            Telefon juda yaxshi saqlangan, barcha funksiyasi ishlaydi. Qutisi, kabeli va hujjatlari bor.
            Batareya holati 89%. Xariddan oldin mahsulotni ko‘rib, holatini tekshirib oling.
          </p>
          <div className="mt-4 flex flex-wrap gap-2">
            <Pill icon={<Check className="h-3 w-3 text-[#4b8f64]" />}>Face ID ishlaydi</Pill>
            <Pill icon={<Check className="h-3 w-3 text-[#4b8f64]" />}>Quti bor</Pill>
            <Pill icon={<Check className="h-3 w-3 text-[#4b8f64]" />}>IMEI toza</Pill>
          </div>
        </section>

        <section className="px-5 pb-6 pt-5">
          <div className="mb-3 flex items-center gap-2">
            <ShieldCheck className="h-[18px] w-[18px] text-[#4b8f64]" />
            <h3 className="text-[15px] font-extrabold text-[#17211e]">Xavfsiz kelishuv</h3>
          </div>
          <p className="text-[12px] leading-5 text-[#718078]">
             Kelishuvni Bozor Bot chatida olib boring. Mahsulotni tekshirmasdan turib oldindan pul yubormang.
          </p>
          <button
            onClick={() => showNotice("Xavfsiz xarid bo‘yicha qo‘llanma ochiladi")}
            className="mt-3 flex items-center gap-1 text-[11px] font-bold text-[#ff6b35]"
          >
            Batafsil qo‘llanma <ChevronRight className="h-3.5 w-3.5" />
          </button>
        </section>
      </div>

      <div className="fixed bottom-[78px] left-1/2 z-20 flex w-full max-w-[440px] -translate-x-1/2 gap-2 border-t border-[#e6ebe5] bg-[#f6f7f4]/95 px-5 py-3 backdrop-blur-xl">
        <button
          onClick={() => setContactMode("message")}
          className="flex h-12 flex-1 items-center justify-center gap-2 rounded-[16px] border border-[#d9e3da] bg-white text-[13px] font-extrabold text-[#2e6950] shadow-sm transition hover:border-[#9cc5aa]"
        >
          <MessageCircle className="h-[18px] w-[18px]" /> Xabar yozish
        </button>
        <button
          onClick={() => setContactMode("phone")}
          className="flex h-12 flex-1 items-center justify-center gap-2 rounded-[16px] bg-[#ff6b35] text-[13px] font-extrabold text-white shadow-[0_8px_20px_rgba(255,107,53,0.25)] transition hover:bg-[#ee5b27]"
        >
          <Phone className="h-[17px] w-[17px]" /> Qo‘ng‘iroq qilish
        </button>
      </div>

      {contactMode && (
        <div className="fixed inset-0 z-50 flex items-end justify-center bg-[#17211e]/35 px-4 pb-[90px] backdrop-blur-[2px]">
          <div className="w-full max-w-[400px] rounded-[24px] bg-white p-5 shadow-[0_20px_60px_rgba(23,33,30,0.2)]">
            <div className="mb-4 flex items-center justify-between">
              <div>
                <p className="text-[11px] font-bold uppercase tracking-[0.16em] text-[#ff6b35]">Sardor Akmalov</p>
                <h3 className="mt-1 text-[20px] font-extrabold tracking-[-0.04em] text-[#17211e]">
                  {contactMode === "phone" ? "Sotuvchiga qo‘ng‘iroq" : "Sotuvchiga xabar"}
                </h3>
              </div>
              <button
                onClick={() => setContactMode(null)}
                className="flex h-9 w-9 items-center justify-center rounded-full bg-[#f4f7f3] text-[#63736a]"
                aria-label="Yopish"
              >
                <ArrowLeft className="h-4 w-4 rotate-[-45deg]" />
              </button>
            </div>
            {contactMode === "phone" ? (
              <div>
                <div className="flex items-center gap-3 rounded-[16px] bg-[#f5f8f4] p-3">
                  <span className="flex h-10 w-10 items-center justify-center rounded-full bg-[#eaf4ed] text-[#4b8f64]">
                    <Phone className="h-[18px] w-[18px]" />
                  </span>
                  <div>
                    <p className="text-[12px] text-[#84928a]">Telefon raqami</p>
                    <p className="text-[16px] font-extrabold text-[#17211e]">+998 90 734 18 26</p>
                  </div>
                  <button
                    onClick={() => {
                      navigator.clipboard?.writeText("+998 90 734 18 26");
                      showNotice("Raqam nusxalandi");
                    }}
                    className="ml-auto text-[#ff6b35]"
                    aria-label="Raqamni nusxalash"
                  >
                    <Copy className="h-4 w-4" />
                  </button>
                </div>
                <button
                  onClick={() => {
                    window.location.href = "tel:+998907341826";
                  }}
                  className="mt-3 flex h-12 w-full items-center justify-center gap-2 rounded-[15px] bg-[#ff6b35] text-[13px] font-extrabold text-white"
                >
                  <Phone className="h-4 w-4" /> Raqamga qo‘ng‘iroq qilish
                </button>
              </div>
            ) : (
              <div>
                <textarea
                  autoFocus
                  rows={3}
                  placeholder="Salom, telefon hali sotilmaganmi?"
                  className="w-full resize-none rounded-[16px] border border-[#dfe7df] bg-[#fbfcfa] p-3 text-[13px] text-[#17211e] outline-none ring-[#ffb294] placeholder:text-[#aab5ad] focus:ring-2"
                />
                <button
                  onClick={() => {
                    setContactMode(null);
                    showNotice("Xabaringiz yuborildi");
                  }}
                  className="mt-3 flex h-12 w-full items-center justify-center gap-2 rounded-[15px] bg-[#17211e] text-[13px] font-extrabold text-white"
                >
                  <MessageCircle className="h-4 w-4" /> Xabarni yuborish
                </button>
              </div>
            )}
          </div>
        </div>
      )}
    </AppShell>
  );
}
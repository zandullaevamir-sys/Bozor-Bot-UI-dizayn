import type { ReactNode } from "react";
import {
  Bell,
  Bookmark,
  BriefcaseBusiness,
  Home,
  MessageCircle,
  PackageOpen,
  Plus,
  Search,
  SlidersHorizontal,
  UserRound,
  X,
} from "lucide-react";

export type NavKey = "home" | "search" | "sell" | "messages" | "profile";

const navItems: Array<{ key: NavKey; label: string; icon: typeof Home }> = [
  { key: "home", label: "Bosh sahifa", icon: Home },
  { key: "search", label: "Qidiruv", icon: Search },
  { key: "sell", label: "E’lon berish", icon: Plus },
  { key: "messages", label: "Xabarlar", icon: MessageCircle },
  { key: "profile", label: "Profil", icon: UserRound },
];

export function AppShell({
  children,
  active = "home",
  title = "Bozor",
  showBack = false,
  onBack,
  rightAction,
  className = "",
}: {
  children: ReactNode;
  active?: NavKey;
  title?: string;
  showBack?: boolean;
  onBack?: () => void;
  rightAction?: ReactNode;
  className?: string;
}) {
  return (
    <div
      className={`min-h-full w-full bg-[#f6f7f4] text-[#17211e] ${className}`}
      style={{ fontFamily: "'DM Sans', sans-serif" }}
    >
      <div className="mx-auto flex min-h-full max-w-[440px] flex-col">
        <header className="sticky top-0 z-20 flex h-[72px] items-center justify-between border-b border-[#e6ebe5] bg-[#f6f7f4]/95 px-5 backdrop-blur-xl">
          <div className="flex items-center gap-3">
            {showBack ? (
              <button
                onClick={onBack}
                className="flex h-9 w-9 items-center justify-center rounded-full border border-[#dfe6df] bg-white text-[#34443d] transition hover:bg-[#edf2ec]"
                aria-label="Orqaga"
              >
                <X className="h-4 w-4 rotate-45" />
              </button>
            ) : (
              <div className="flex h-10 w-10 items-center justify-center rounded-[14px] bg-[#ff6b35] text-lg font-black text-white shadow-[0_8px_20px_rgba(255,107,53,0.24)]">
                B
              </div>
            )}
            <div>
              <p className="text-[10px] font-bold uppercase tracking-[0.2em] text-[#ff6b35]">
                Qoraqalpog‘iston bozori
              </p>
              <h1 className="text-[20px] font-extrabold tracking-[-0.04em] text-[#17211e]">
                {title}
              </h1>
            </div>
          </div>
          <div className="flex items-center gap-2">
            {rightAction}
            {!showBack && (
              <button
                className="relative flex h-10 w-10 items-center justify-center rounded-full bg-white text-[#34443d] shadow-sm ring-1 ring-[#e6ebe5]"
                aria-label="Bildirishnomalar"
              >
                <Bell className="h-[18px] w-[18px]" />
                <span className="absolute right-[9px] top-[8px] h-1.5 w-1.5 rounded-full bg-[#ff6b35] ring-2 ring-white" />
              </button>
            )}
          </div>
        </header>

        <main className="flex-1 pb-[92px]">{children}</main>

        <nav className="fixed bottom-0 left-1/2 z-30 flex h-[78px] w-full max-w-[440px] -translate-x-1/2 items-center justify-around border-t border-[#e6ebe5] bg-white/95 px-3 backdrop-blur-xl">
          {navItems.map(({ key, label, icon: Icon }) => {
            const isActive = active === key;
            return (
              <button
                key={key}
                className={`relative flex min-w-[62px] flex-col items-center gap-1 rounded-2xl px-2 py-2 text-[10px] font-semibold transition ${
                  isActive ? "text-[#ff6b35]" : "text-[#91a098]"
                }`}
              >
                {key === "sell" ? (
                  <span className="flex h-10 w-10 items-center justify-center rounded-[15px] bg-[#17211e] text-white shadow-[0_8px_18px_rgba(23,33,30,0.2)]">
                    <Icon className="h-5 w-5" />
                  </span>
                ) : (
                  <Icon className={`h-5 w-5 ${isActive ? "stroke-[2.5]" : ""}`} />
                )}
                <span>{label}</span>
                {isActive && key !== "sell" && (
                  <span className="absolute -bottom-1 h-1 w-1 rounded-full bg-[#ff6b35]" />
                )}
              </button>
            );
          })}
        </nav>
      </div>
    </div>
  );
}

export function PageIntro({
  eyebrow,
  title,
  description,
  action,
}: {
  eyebrow?: string;
  title: string;
  description?: string;
  action?: ReactNode;
}) {
  return (
    <div className="flex items-end justify-between gap-4 px-5 pb-4 pt-6">
      <div>
        {eyebrow && (
          <p className="mb-1 text-[11px] font-bold uppercase tracking-[0.16em] text-[#ff6b35]">
            {eyebrow}
          </p>
        )}
        <h2 className="text-[25px] font-extrabold leading-[1.08] tracking-[-0.05em] text-[#17211e]">
          {title}
        </h2>
        {description && (
          <p className="mt-2 max-w-[280px] text-[13px] leading-5 text-[#718078]">
            {description}
          </p>
        )}
      </div>
      {action}
    </div>
  );
}

export function SearchBar({ value = "Nima izlayapsiz?" }: { value?: string }) {
  return (
    <div className="mx-5 flex h-12 items-center gap-3 rounded-2xl border border-[#e3e9e2] bg-white px-4 shadow-sm">
      <Search className="h-[18px] w-[18px] text-[#91a098]" />
      <span className="flex-1 text-[13px] text-[#91a098]">{value}</span>
      <SlidersHorizontal className="h-[17px] w-[17px] text-[#ff6b35]" />
    </div>
  );
}

export function ProductImage({
  tone = "orange",
  visual,
  label,
  className = "",
}: {
  tone?: "orange" | "blue" | "green" | "purple" | "yellow";
  visual?: ReactNode;
  label?: string;
  className?: string;
}) {
  const tones = {
    orange: "from-[#ffd6bd] via-[#ffeadc] to-[#fff6ef]",
    blue: "from-[#c9e8ed] via-[#e5f5f6] to-[#f5fbfb]",
    green: "from-[#cde8c7] via-[#e9f5e3] to-[#f7fbf3]",
    purple: "from-[#dfd3ef] via-[#f0e9f8] to-[#faf8fd]",
    yellow: "from-[#f8e7ad] via-[#fbf3d9] to-[#fffdf3]",
  };
  return (
    <div
      className={`relative flex items-center justify-center overflow-hidden rounded-[18px] bg-gradient-to-br ${tones[tone]} ${className}`}
    >
      <span className="absolute -right-4 -top-5 h-20 w-20 rounded-full bg-white/30" />
      <span className="absolute -bottom-7 -left-5 h-24 w-24 rounded-full bg-white/25" />
      <span className="relative flex h-16 w-16 items-center justify-center rounded-[22px] bg-white/55 text-[#486058] shadow-sm backdrop-blur">
        {visual ?? <PackageOpen className="h-8 w-8" />}
      </span>
      {label && (
        <span className="absolute bottom-2 left-2 rounded-md bg-white/75 px-1.5 py-0.5 text-[9px] font-bold uppercase tracking-[0.12em] text-[#5c6e64] backdrop-blur">
          {label}
        </span>
      )}
    </div>
  );
}

export function Pill({
  children,
  active = false,
  icon,
}: {
  children: ReactNode;
  active?: boolean;
  icon?: ReactNode;
}) {
  return (
    <span
      className={`inline-flex items-center gap-1.5 whitespace-nowrap rounded-full px-3 py-2 text-[11px] font-bold ${
        active
          ? "bg-[#17211e] text-white"
          : "border border-[#e1e8e0] bg-white text-[#63736a]"
      }`}
    >
      {icon}
      {children}
    </span>
  );
}

export function SaveButton({ saved = false }: { saved?: boolean }) {
  return (
    <button
      className={`flex h-9 w-9 items-center justify-center rounded-full ${
        saved ? "bg-[#fff0e9] text-[#ff6b35]" : "bg-white/90 text-[#34443d]"
      }`}
      aria-label="Saqlash"
    >
      <Bookmark className={`h-4 w-4 ${saved ? "fill-current" : ""}`} />
    </button>
  );
}

export function SellerAvatar({
  initials,
  tone = "bg-[#d6ece2] text-[#2e6950]",
}: {
  initials: string;
  tone?: string;
}) {
  return (
    <span
      className={`flex h-9 w-9 items-center justify-center rounded-full text-[11px] font-extrabold ${tone}`}
    >
      {initials}
    </span>
  );
}

export function ServiceIcon({ icon = <BriefcaseBusiness className="h-5 w-5" /> }) {
  return (
    <span className="flex h-11 w-11 items-center justify-center rounded-[14px] bg-[#eaf4ed] text-[#4b8f64]">
      {icon}
    </span>
  );
}
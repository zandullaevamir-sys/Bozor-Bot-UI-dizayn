import { useState } from "react";
import {
  BadgeCheck,
  Bell,
  Check,
  ChevronRight,
  CircleHelp,
  CreditCard,
  Heart,
  Home,
  MessageCircle,
  MoreHorizontal,
  Pencil,
  Settings2,
  ShieldCheck,
  Sparkles,
  Store,
  Tag,
  X,
} from "lucide-react";
import {
  AppShell,
  ProductImage,
  SellerAvatar,
  ServiceIcon,
} from "./_shared/AppShell";

type ProfileTab = "E’lonlarim" | "Saqlangan" | "Xizmatlarim";

const products = [
  {
    id: "iphone",
    title: "iPhone 13, 128 GB",
    price: "5 950 000 so‘m",
    meta: "Bugun, 09:42",
    tone: "blue" as const,
    icon: <CreditCard className="h-8 w-8" />,
    status: "Faol",
  },
  {
    id: "chair",
    title: "Yog‘och ish stoli",
    price: "780 000 so‘m",
    meta: "Kecha, 18:16",
    tone: "yellow" as const,
    icon: <Home className="h-8 w-8" />,
    status: "Faol",
  },
];

const services = [
  {
    id: "repair",
    title: "Maishiy texnika ta’miri",
    detail: "4.9 baho · faol",
    icon: <Settings2 className="h-5 w-5" />,
    tone: "bg-[#eaf4ed] text-[#4b8f64]",
  },
  {
    id: "delivery",
    title: "Yuk tashish xizmati",
    detail: "4.8 baho · faol",
    icon: <Store className="h-5 w-5" />,
    tone: "bg-[#fff0e9] text-[#dd5e2d]",
  },
];

export function Profile() {
  const [tab, setTab] = useState<ProfileTab>("E’lonlarim");
  const [isEditing, setIsEditing] = useState(false);
  const [isAvailable, setIsAvailable] = useState(true);
  const [saved, setSaved] = useState<Record<string, boolean>>({
    chair: true,
  });
  const [notice, setNotice] = useState("");

  const showNotice = (message: string) => {
    setNotice(message);
    window.setTimeout(() => setNotice(""), 2200);
  };

  const tabs: ProfileTab[] = ["E’lonlarim", "Saqlangan", "Xizmatlarim"];
  const visibleProducts =
    tab === "Saqlangan" ? products.filter((item) => saved[item.id]) : products;

  return (
    <AppShell
      active="profile"
      title="Profil"
      rightAction={
        <button
          onClick={() => setIsEditing(true)}
          className="flex h-10 w-10 items-center justify-center rounded-full bg-white text-[#34443d] shadow-sm ring-1 ring-[#e6ebe5] transition hover:bg-[#edf2ec] active:scale-95"
          aria-label="Profilni tahrirlash"
        >
          <Pencil className="h-[17px] w-[17px]" />
        </button>
      }
    >
      <section className="px-5 pb-5 pt-5">
        <div className="relative overflow-hidden rounded-[26px] bg-[#17211e] px-5 pb-5 pt-5 text-white shadow-[0_16px_35px_rgba(23,33,30,0.16)]">
          <div className="pointer-events-none absolute -right-12 -top-16 h-40 w-40 rounded-full border-[22px] border-[#ff6b35]/25" />
          <div className="pointer-events-none absolute -bottom-16 right-16 h-32 w-32 rounded-full bg-[#ff6b35]/10" />
          <div className="relative flex items-start justify-between">
            <div className="flex items-center gap-3.5">
              <div className="relative">
                <SellerAvatar
                  initials="MS"
                  tone="bg-[#ffd4bd] text-[#9a4827]"
                />
                <span className="absolute -bottom-0.5 -right-0.5 flex h-4 w-4 items-center justify-center rounded-full border-2 border-[#17211e] bg-[#ff6b35] text-white">
                  <Check className="h-2.5 w-2.5 stroke-[3]" />
                </span>
              </div>
              <div>
                <div className="flex items-center gap-1.5">
                  <h2 className="text-[18px] font-extrabold tracking-[-0.04em]">
                    Mohira Sattorova
                  </h2>
                  <BadgeCheck className="h-4 w-4 text-[#ff9a73]" />
                </div>
                <p className="mt-0.5 text-[12px] text-[#b4c2ba]">
                  Ishonchli sotuvchi va xizmat ko‘rsatuvchi
                </p>
              </div>
            </div>
            <button
              onClick={() => setIsEditing(true)}
              className="rounded-full p-1.5 text-[#c7d0ca] transition hover:bg-white/10 hover:text-white"
              aria-label="Profil sozlamalari"
            >
              <MoreHorizontal className="h-5 w-5" />
            </button>
          </div>

          <div className="mt-5 flex items-center gap-2.5 rounded-2xl border border-white/10 bg-white/[0.07] px-3 py-2.5">
            <ShieldCheck className="h-[19px] w-[19px] shrink-0 text-[#ff966d]" />
            <div className="min-w-0 flex-1">
              <p className="text-[12px] font-bold text-white">Ishonchli a’zo</p>
              <p className="mt-0.5 truncate text-[10px] text-[#aab9b0]">
                Telefon va shaxs tasdiqlangan
              </p>
            </div>
            <span className="rounded-full bg-[#285346] px-2 py-1 text-[9px] font-bold uppercase tracking-[0.08em] text-[#b7e2c7]">
              4.9 / 5
            </span>
          </div>

          <div className="mt-5 grid grid-cols-3 divide-x divide-white/10">
            <div className="text-center">
              <p className="text-[19px] font-extrabold tracking-[-0.04em]">12</p>
              <p className="mt-0.5 text-[10px] text-[#aab9b0]">e’lon</p>
            </div>
            <div className="text-center">
              <p className="text-[19px] font-extrabold tracking-[-0.04em]">38</p>
              <p className="mt-0.5 text-[10px] text-[#aab9b0]">savdo</p>
            </div>
            <div className="text-center">
              <p className="text-[19px] font-extrabold tracking-[-0.04em]">2 yil</p>
              <p className="mt-0.5 text-[10px] text-[#aab9b0]">Bozorda</p>
            </div>
          </div>
        </div>
      </section>

      <section className="px-5">
        <div className="grid grid-cols-2 gap-2.5">
          <button
            onClick={() => showNotice("Yangi e’lon oynasi tez orada ochiladi")}
            className="flex h-[52px] items-center justify-center gap-2 rounded-2xl bg-[#ff6b35] text-[12px] font-extrabold text-white shadow-[0_8px_18px_rgba(255,107,53,0.2)] transition hover:bg-[#ed5e2b] active:scale-[0.98]"
          >
            <Tag className="h-4 w-4" />
            E’lon berish
          </button>
          <button
            onClick={() => showNotice("Sizda 3 ta yangi xabar bor")}
            className="flex h-[52px] items-center justify-center gap-2 rounded-2xl border border-[#e1e8e0] bg-white text-[12px] font-extrabold text-[#34443d] shadow-sm transition hover:bg-[#f8faf7] active:scale-[0.98]"
          >
            <MessageCircle className="h-4 w-4 text-[#ff6b35]" />
            Xabarlar
            <span className="flex h-5 min-w-5 items-center justify-center rounded-full bg-[#fff0e9] px-1 text-[10px] text-[#dd5e2d]">
              3
            </span>
          </button>
        </div>
      </section>

      <section className="mt-6">
        <div className="flex items-center justify-between px-5">
          <div>
            <p className="text-[10px] font-bold uppercase tracking-[0.18em] text-[#ff6b35]">
              Sizning bozoringiz
            </p>
            <h3 className="mt-1 text-[19px] font-extrabold tracking-[-0.04em] text-[#17211e]">
              Faol narsalar
            </h3>
          </div>
          <button
            onClick={() => showNotice("Barcha e’lonlar ko‘rsatilmoqda")}
            className="flex items-center gap-1 text-[11px] font-bold text-[#718078] transition hover:text-[#ff6b35]"
          >
            Barchasi
            <ChevronRight className="h-3.5 w-3.5" />
          </button>
        </div>

        <div className="mt-4 flex gap-2 overflow-x-auto px-5 pb-1 [scrollbar-width:none] [&::-webkit-scrollbar]:hidden">
          {tabs.map((item) => (
            <button
              key={item}
              onClick={() => setTab(item)}
              className={`whitespace-nowrap rounded-full px-3.5 py-2 text-[11px] font-bold transition ${
                tab === item
                  ? "bg-[#17211e] text-white shadow-sm"
                  : "border border-[#e1e8e0] bg-white text-[#718078] hover:border-[#cbd8cd]"
              }`}
            >
              {item}
              {item === "Saqlangan" && (
                <span className="ml-1.5 opacity-60">1</span>
              )}
            </button>
          ))}
        </div>

        {tab === "Xizmatlarim" ? (
          <div className="mt-3 space-y-2.5 px-5">
            {services.map((service) => (
              <button
                key={service.id}
                onClick={() => showNotice(`${service.title} tahrirlashga tayyor`)}
                className="flex w-full items-center gap-3 rounded-[20px] border border-[#e6ebe5] bg-white p-3 text-left shadow-sm transition hover:border-[#ffd1bd] active:scale-[0.99]"
              >
                <ServiceIcon icon={service.icon} />
                <span className="min-w-0 flex-1">
                  <span className="block truncate text-[13px] font-extrabold text-[#34443d]">
                    {service.title}
                  </span>
                  <span className="mt-1 block text-[11px] text-[#84928a]">
                    {service.detail}
                  </span>
                </span>
                <ChevronRight className="h-4 w-4 text-[#a5b1aa]" />
              </button>
            ))}
            <button
              onClick={() => showNotice("Xizmat profilini yaratish boshlandi")}
              className="flex w-full items-center justify-center gap-2 rounded-[18px] border border-dashed border-[#cad8cc] py-3 text-[11px] font-bold text-[#568167] transition hover:bg-[#f3f8f2]"
            >
              <Sparkles className="h-4 w-4" />
              Yangi xizmat qo‘shish
            </button>
          </div>
        ) : visibleProducts.length > 0 ? (
          <div className="mt-3 space-y-2.5 px-5">
            {visibleProducts.map((product) => (
              <div
                key={product.id}
                className="flex gap-3 rounded-[20px] border border-[#e6ebe5] bg-white p-2.5 shadow-sm transition hover:border-[#ffd1bd]"
              >
                <ProductImage
                  tone={product.tone}
                  visual={product.icon}
                  className="h-[78px] w-[78px] shrink-0"
                />
                <div className="min-w-0 flex-1 py-1">
                  <div className="flex items-start justify-between gap-2">
                    <p className="truncate text-[13px] font-extrabold text-[#34443d]">
                      {product.title}
                    </p>
                    <button
                      onClick={() => {
                        setSaved((current) => ({
                          ...current,
                          [product.id]: !current[product.id],
                        }));
                        showNotice(
                          saved[product.id]
                            ? "Saqlanganlardan olib tashlandi"
                            : "Saqlanganlarga qo‘shildi",
                        );
                      }}
                      className={`flex h-7 w-7 shrink-0 items-center justify-center rounded-full transition ${
                        saved[product.id]
                          ? "bg-[#fff0e9] text-[#ff6b35]"
                          : "bg-[#f5f7f4] text-[#91a098]"
                      }`}
                      aria-label={
                        saved[product.id]
                          ? "Saqlanganlardan olib tashlash"
                          : "Saqlash"
                      }
                    >
                      <Heart
                        className={`h-3.5 w-3.5 ${
                          saved[product.id] ? "fill-current" : ""
                        }`}
                      />
                    </button>
                  </div>
                  <p className="mt-1 text-[13px] font-extrabold text-[#ff6b35]">
                    {product.price}
                  </p>
                  <div className="mt-2 flex items-center gap-2 text-[10px] text-[#8a988f]">
                    <span className="rounded-md bg-[#eaf4ed] px-1.5 py-1 font-bold text-[#4b8f64]">
                      {product.status}
                    </span>
                    <span>{product.meta}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="mx-5 mt-3 rounded-[20px] border border-dashed border-[#cad8cc] bg-[#f8fbf7] px-5 py-7 text-center">
            <Heart className="mx-auto h-6 w-6 text-[#9db0a2]" />
            <p className="mt-2 text-[13px] font-extrabold text-[#34443d]">
              Hali saqlangan e’lonlar yo‘q
            </p>
            <p className="mt-1 text-[11px] leading-4 text-[#84928a]">
              Yoqtirgan e’lonlaringiz shu yerda turadi.
            </p>
          </div>
        )}
      </section>

      <section className="mt-6 px-5">
        <div className="flex items-center justify-between rounded-[20px] border border-[#e6ebe5] bg-white p-3.5 shadow-sm">
          <div className="flex items-center gap-3">
            <span className="flex h-10 w-10 items-center justify-center rounded-[14px] bg-[#fff2e9] text-[#ff6b35]">
              <Bell className="h-[18px] w-[18px]" />
            </span>
            <div>
              <p className="text-[12px] font-extrabold text-[#34443d]">
                E’lonlarim kuzatuvi
              </p>
              <p className="mt-0.5 text-[10px] text-[#84928a]">
                Yangi qiziqishlar haqida xabar oling
              </p>
            </div>
          </div>
          <button
            onClick={() => setIsAvailable((value) => !value)}
            className={`relative h-6 w-11 rounded-full transition ${
              isAvailable ? "bg-[#ff6b35]" : "bg-[#d6dfd8]"
            }`}
            aria-label="Kuzatuv bildirishnomalari"
            aria-pressed={isAvailable}
          >
            <span
              className={`absolute top-1 h-4 w-4 rounded-full bg-white shadow-sm transition-transform ${
                isAvailable ? "translate-x-6" : "translate-x-1"
              }`}
            />
          </button>
        </div>
      </section>

      <section className="mt-5 px-5">
        <button
          onClick={() => showNotice("Sozlamalar ochiladi")}
          className="flex w-full items-center gap-3 border-b border-[#e6ebe5] py-3 text-left"
        >
          <Settings2 className="h-[18px] w-[18px] text-[#718078]" />
          <span className="flex-1 text-[12px] font-bold text-[#4a5b52]">
            Hisob sozlamalari
          </span>
          <ChevronRight className="h-4 w-4 text-[#a5b1aa]" />
        </button>
        <button
          onClick={() => showNotice("Yordam markazi ochiladi")}
          className="flex w-full items-center gap-3 py-3 text-left"
        >
          <CircleHelp className="h-[18px] w-[18px] text-[#718078]" />
          <span className="flex-1 text-[12px] font-bold text-[#4a5b52]">
            Yordam markazi
          </span>
          <ChevronRight className="h-4 w-4 text-[#a5b1aa]" />
        </button>
      </section>

      {notice && (
        <div
          role="status"
          className="fixed bottom-[92px] left-1/2 z-40 flex -translate-x-1/2 items-center gap-2 rounded-full bg-[#17211e] px-4 py-3 text-[11px] font-bold text-white shadow-xl"
        >
          <Check className="h-4 w-4 text-[#ff9a73]" />
          {notice}
        </div>
      )}

      {isEditing && (
        <div className="fixed inset-0 z-50 flex items-end justify-center bg-[#17211e]/35 p-0 backdrop-blur-[2px]">
          <div className="w-full max-w-[440px] rounded-t-[28px] bg-[#f6f7f4] p-5 shadow-2xl">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-[10px] font-bold uppercase tracking-[0.16em] text-[#ff6b35]">
                  Shaxsiy ma’lumotlar
                </p>
                <h3 className="mt-1 text-[20px] font-extrabold tracking-[-0.04em] text-[#17211e]">
                  Profilni tahrirlash
                </h3>
              </div>
              <button
                onClick={() => setIsEditing(false)}
                className="flex h-9 w-9 items-center justify-center rounded-full border border-[#dfe6df] bg-white text-[#718078]"
                aria-label="Yopish"
              >
                <X className="h-4 w-4" />
              </button>
            </div>
            <div className="mt-5 space-y-3">
              <label className="block">
                <span className="mb-1.5 block text-[11px] font-bold text-[#63736a]">
                  Ism va familiya
                </span>
                <input
                  defaultValue="Mohira Sattorova"
                  className="h-12 w-full rounded-2xl border border-[#dfe6df] bg-white px-4 text-[13px] font-semibold text-[#34443d] outline-none ring-[#ff6b35] focus:ring-2"
                />
              </label>
            </div>
            <button
              onClick={() => {
                setIsEditing(false);
                showNotice("Profil ma’lumotlari saqlandi");
              }}
              className="mt-5 flex h-12 w-full items-center justify-center rounded-2xl bg-[#ff6b35] text-[13px] font-extrabold text-white transition hover:bg-[#ed5e2b] active:scale-[0.98]"
            >
              Saqlash
            </button>
          </div>
        </div>
      )}
    </AppShell>
  );
}
export function LogoMonogram() {
  return (
    <main className="min-h-screen bg-[#f3f8ff] p-8 font-sans text-[#183b5b]">
      <div className="mx-auto flex max-w-sm flex-col items-center justify-center gap-8 rounded-[32px] border border-[#d7e8f4] bg-white p-10 shadow-[0_18px_50px_rgba(57,117,166,0.12)]">
        <div className="text-center">
          <p className="text-[10px] font-black uppercase tracking-[0.25em] text-[#419fe7]">Variant 03 · BB monogram</p>
          <h1 className="mt-2 text-2xl font-black tracking-[-0.06em]">Compact mark</h1>
          <p className="mt-2 text-sm leading-6 text-[#6f8ca2]">Telegram ikonkasida, avatar va kichik o‘lchamlarda eng aniq ko‘rinadigan yechim.</p>
        </div>

        <div className="relative flex h-44 w-44 items-center justify-center rounded-[46px] bg-gradient-to-br from-[#245b86] to-[#419fe7] shadow-[0_18px_30px_rgba(65,159,231,0.24)]">
          <div className="absolute inset-5 rounded-[30px] border border-white/25" />
          <div className="relative flex items-center text-[74px] font-black leading-none tracking-[-0.18em] text-white">
            <span>B</span>
            <span className="ml-[-10px] text-[#bfe7ff]">B</span>
          </div>
          <div className="absolute bottom-7 h-1.5 w-10 rounded-full bg-[#bfe7ff]" />
        </div>

        <div className="text-center">
          <p className="text-2xl font-black tracking-[-0.06em]">Bozor Bot</p>
          <p className="mt-1 text-[10px] font-bold uppercase tracking-[0.22em] text-[#7897ad]">Simple. Local. Useful.</p>
        </div>
      </div>
    </main>
  );
}
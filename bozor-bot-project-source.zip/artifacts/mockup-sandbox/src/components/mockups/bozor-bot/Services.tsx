import { useMemo, useState } from "react";
import {
  ArrowRight,
  ArrowUpDown,
  BadgeCheck,
  Bookmark,
  Check,
  ChevronDown,
  Clock3,
  Laptop,
  MessageCircle,
  Paintbrush,
  Plus,
  Search,
  ShieldCheck,
  SlidersHorizontal,
  Sparkles,
  Star,
  Wrench,
  X,
  Zap,
} from "lucide-react";

import { AppShell } from "./_shared/AppShell";

type Category = "Barchasi" | "Ta'mirlash" | "Go'zallik" | "Texnika" | "Tozalash";
type Provider = {
  id: number;
  name: string;
  initials: string;
  tone: string;
  title: string;
  category: Exclude<Category, "Barchasi">;
  skills: string[];
  rating: string;
  reviews: number;
  response: string;
  price: string;
  verified?: boolean;
  accent: string;
};

const categories: Array<{ name: Category; count: string; icon: typeof Wrench }> = [
  { name: "Barchasi", count: "128", icon: Sparkles },
  { name: "Ta'mirlash", count: "46", icon: Wrench },
  { name: "Go'zallik", count: "31", icon: Paintbrush },
  { name: "Texnika", count: "24", icon: Laptop },
  { name: "Tozalash", count: "27", icon: ShieldCheck },
];

const providers: Provider[] = [
  {
    id: 1,
    name: "Jasur Usta",
    initials: "JU",
    tone: "bg-[#ffe0cf] text-[#b94e2c]",
    title: "Santexnika va isitish tizimi",
    category: "Ta'mirlash",
    skills: ["Suv quvuri", "Kotel", "Aralashgich"],
    rating: "4.9",
    reviews: 38,
    response: "12 daqiqada",
    price: "80 000 so'mdan",
    verified: true,
    accent: "bg-[#fff0e7]",
  },
  {
    id: 2,
    name: "Dilnoza Beauty",
    initials: "DB",
    tone: "bg-[#e7e1fb] text-[#6653a1]",
    title: "Uyda manikyur va pedikyur",
    category: "Go'zallik",
    skills: ["Manikyur", "Gel-lak", "Pedikyur"],
    rating: "5.0",
    reviews: 24,
    response: "25 daqiqada",
    price: "120 000 so'mdan",
    verified: true,
    accent: "bg-[#f2effb]",
  },
  {
    id: 3,
    name: "Bekzod Elektrik",
    initials: "BE",
    tone: "bg-[#d8eef0] text-[#27717b]",
    title: "Elektrik va aqlli uy sozlamalari",
    category: "Texnika",
    skills: ["Rozetka", "Yoritish", "Router"],
    rating: "4.8",
    reviews: 17,
    response: "18 daqiqada",
    price: "70 000 so'mdan",
    accent: "bg-[#e8f6f6]",
  },
  {
    id: 4,
    name: "Ozoda Toza",
    initials: "OT",
    tone: "bg-[#e4efd6] text-[#5e7d3f]",
    title: "Kvartira va ofis tozaligi",
    category: "Tozalash",
    skills: ["General", "Deraza", "Ofis"],
    rating: "4.9",
    reviews: 42,
    response: "40 daqiqada",
    price: "150 000 so'mdan",
    verified: true,
    accent: "bg-[#eff6e9]",
  },
];

function categoryIcon(category: Category) {
  const item = categories.find((entry) => entry.name === category);
  const Icon = item?.icon ?? Sparkles;
  return <Icon className="h-[17px] w-[17px]" />;
}

export function Services() {
  const [query, setQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState<Category>("Barchasi");
  const [showFilters, setShowFilters] = useState(false);
  const [showPublish, setShowPublish] = useState(false);
  const [onlyVerified, setOnlyVerified] = useState(false);
  const [sortByRating, setSortByRating] = useState(false);
  const [savedIds, setSavedIds] = useState<number[]>([2]);
  const [messageId, setMessageId] = useState<number | null>(null);
  const [published, setPublished] = useState(false);

  const filteredProviders = useMemo(() => {
    const normalized = query.trim().toLocaleLowerCase("uz");
    const result = providers.filter((provider) => {
      const matchesQuery =
        !normalized ||
        [provider.name, provider.title, ...provider.skills]
          .join(" ")
          .toLocaleLowerCase("uz")
          .includes(normalized);
      const matchesCategory =
        selectedCategory === "Barchasi" || provider.category === selectedCategory;
      const matchesVerified = !onlyVerified || provider.verified;
      return matchesQuery && matchesCategory && matchesVerified;
    });

    return sortByRating
      ? [...result].sort((a, b) => Number(b.rating) - Number(a.rating))
      : result;
  }, [onlyVerified, query, selectedCategory, sortByRating]);

  const toggleSaved = (id: number) => {
    setSavedIds((current) =>
      current.includes(id) ? current.filter((savedId) => savedId !== id) : [...current, id],
    );
  };

  return (
    <AppShell active="search" title="Xizmatlar">
      <section className="px-5 pb-2 pt-6">
        <div className="mb-5 flex items-start justify-between gap-3">
          <div>
            <p className="mb-1 text-[11px] font-bold uppercase tracking-[0.18em] text-[#ff6b35]">
              Qoraqalpog‘istondan toping
            </p>
            <h2 className="max-w-[280px] text-[28px] font-extrabold leading-[1.03] tracking-[-0.06em] text-[#17211e]">
              Kerakli usta
              <br />
              <span className="text-[#ff6b35]">shu atrofda.</span>
            </h2>
          </div>
          <button
            onClick={() => setShowPublish(true)}
            className="mt-1 flex h-11 w-11 shrink-0 items-center justify-center rounded-[15px] bg-[#17211e] text-white shadow-[0_9px_20px_rgba(23,33,30,0.18)] transition hover:-translate-y-0.5 focus:outline-none focus:ring-2 focus:ring-[#ff6b35] focus:ring-offset-2"
            aria-label="Xizmat profilini joylash"
          >
            <Plus className="h-5 w-5" />
          </button>
        </div>

        <div className="relative flex h-[52px] items-center gap-3 rounded-[18px] border border-[#dfe8df] bg-white px-4 shadow-[0_8px_24px_rgba(48,69,56,0.06)]">
          <Search className="h-[19px] w-[19px] shrink-0 text-[#8a9a91]" />
          <input
            value={query}
            onChange={(event) => setQuery(event.target.value)}
            placeholder="Usta, xizmat yoki ko'nikma"
            className="min-w-0 flex-1 bg-transparent text-[13px] font-medium text-[#17211e] outline-none placeholder:text-[#99a79f]"
            aria-label="Xizmat qidirish"
          />
          <button
            onClick={() => setShowFilters(true)}
            className={`flex h-8 w-8 shrink-0 items-center justify-center rounded-[10px] transition ${
              showFilters ? "bg-[#17211e] text-white" : "bg-[#fff0e7] text-[#ff6b35]"
            }`}
            aria-label="Filtrlarni ochish"
          >
            <SlidersHorizontal className="h-[16px] w-[16px]" />
          </button>
        </div>

      </section>

      <section className="mt-4">
        <div className="mb-3 flex items-center justify-between px-5">
          <h3 className="text-[14px] font-extrabold tracking-[-0.02em] text-[#23332c]">Xizmat turini tanlang</h3>
          <span className="text-[11px] font-semibold text-[#95a39b]">{filteredProviders.length} ta topildi</span>
        </div>
        <div className="flex gap-2 overflow-x-auto px-5 pb-1 [scrollbar-width:none] [&::-webkit-scrollbar]:hidden">
          {categories.map(({ name, count }) => {
            const active = selectedCategory === name;
            return (
              <button
                key={name}
                onClick={() => setSelectedCategory(name)}
                className={`flex shrink-0 items-center gap-2 rounded-[14px] px-3.5 py-2.5 text-[11px] font-bold transition ${
                  active
                    ? "bg-[#ff6b35] text-white shadow-[0_7px_16px_rgba(255,107,53,0.2)]"
                    : "border border-[#e2e9e1] bg-white text-[#64746c] hover:border-[#ffb99d]"
                }`}
              >
                <span className={active ? "text-white" : "text-[#ff6b35]"}>{categoryIcon(name)}</span>
                {name}
                <span className={active ? "text-[#ffe4d7]" : "text-[#a0ada5]"}>{count}</span>
              </button>
            );
          })}
        </div>
      </section>

      <section className="mt-5 px-5">
        <div className="mb-3 flex items-center justify-between">
          <div>
            <p className="text-[10px] font-bold uppercase tracking-[0.15em] text-[#ff6b35]">Faol xizmat ko‘rsatuvchilar</p>
            <h3 className="mt-0.5 text-[19px] font-extrabold tracking-[-0.04em] text-[#17211e]">Bugun javob beradiganlar</h3>
          </div>
          <button
            onClick={() => setSortByRating((current) => !current)}
            className={`flex items-center gap-1.5 rounded-full px-2.5 py-2 text-[10px] font-bold transition ${
              sortByRating ? "bg-[#17211e] text-white" : "bg-[#edf3ec] text-[#66766d]"
            }`}
            aria-label="Reyting bo'yicha saralash"
          >
            <ArrowUpDown className="h-3.5 w-3.5" />
            Reyting
          </button>
        </div>

        <div className="space-y-3">
          {filteredProviders.map((provider) => {
            const saved = savedIds.includes(provider.id);
            const messaged = messageId === provider.id;
            return (
              <article
                key={provider.id}
                className="rounded-[20px] border border-[#e2e9e1] bg-white p-4 shadow-[0_9px_24px_rgba(54,72,60,0.055)] transition hover:-translate-y-0.5"
              >
                <div className="flex items-start gap-3">
                  <div className={`flex h-12 w-12 shrink-0 items-center justify-center rounded-[16px] text-[12px] font-extrabold ${provider.tone}`}>
                    {provider.initials}
                  </div>
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-1.5">
                      <h4 className="truncate text-[14px] font-extrabold text-[#1c2b24]">{provider.name}</h4>
                      {provider.verified && <BadgeCheck className="h-4 w-4 shrink-0 fill-[#ff6b35] text-white" />}
                    </div>
                    <p className="mt-0.5 truncate text-[12px] font-medium text-[#627169]">{provider.title}</p>
                    <div className="mt-1.5 flex items-center gap-2 text-[10px] font-semibold text-[#85938b]">
                      <span className="flex items-center gap-1 text-[#b36b23]"><Star className="h-3 w-3 fill-current" /> {provider.rating} <span className="text-[#9ba8a0]">({provider.reviews})</span></span>
                      <span className="h-1 w-1 rounded-full bg-[#cbd5cd]" />
                      <span>{provider.response} javob</span>
                    </div>
                  </div>
                  <button
                    onClick={() => toggleSaved(provider.id)}
                    className={`flex h-8 w-8 shrink-0 items-center justify-center rounded-full transition ${
                      saved ? "bg-[#fff0e7] text-[#ff6b35]" : "bg-[#f4f7f3] text-[#91a098]"
                    }`}
                    aria-label={saved ? "Saqlangan xizmatni olib tashlash" : "Xizmatni saqlash"}
                  >
                    <Bookmark className={`h-4 w-4 ${saved ? "fill-current" : ""}`} />
                  </button>
                </div>
                <div className="mt-3 flex gap-1.5 overflow-hidden">
                  {provider.skills.map((skill) => (
                    <span key={skill} className={`shrink-0 rounded-md px-2 py-1 text-[10px] font-bold text-[#607068] ${provider.accent}`}>
                      {skill}
                    </span>
                  ))}
                </div>
                <div className="mt-3 flex items-center justify-between border-t border-[#edf1ed] pt-3">
                  <div>
                    <p className="text-[10px] font-semibold text-[#9aa79f]">Boshlang'ich narx</p>
                    <p className="mt-0.5 text-[12px] font-extrabold text-[#26372e]">{provider.price}</p>
                  </div>
                  <div className="flex items-center gap-1 text-[10px] font-bold text-[#6c7c73]">
                    <Clock3 className="h-3.5 w-3.5 text-[#ff6b35]" />
                    {provider.response}
                  </div>
                  <button
                    onClick={() => setMessageId(messaged ? null : provider.id)}
                    className={`flex items-center gap-1.5 rounded-[10px] px-3 py-2 text-[10px] font-extrabold transition ${
                      messaged ? "bg-[#e7f4e9] text-[#458157]" : "bg-[#17211e] text-white hover:bg-[#2b4035]"
                    }`}
                  >
                    {messaged ? <Check className="h-3.5 w-3.5" /> : <MessageCircle className="h-3.5 w-3.5" />}
                    {messaged ? "Yuborildi" : "Yozish"}
                  </button>
                </div>
              </article>
            );
          })}
        </div>

        {filteredProviders.length === 0 && (
          <div className="rounded-[20px] border border-dashed border-[#d6e1d7] bg-[#f8fbf7] px-5 py-8 text-center">
            <div className="mx-auto flex h-11 w-11 items-center justify-center rounded-2xl bg-[#fff0e7] text-[#ff6b35]">
              <Search className="h-5 w-5" />
            </div>
            <h4 className="mt-3 text-[14px] font-extrabold text-[#26372e]">Hozircha mos xizmat topilmadi</h4>
            <p className="mx-auto mt-1 max-w-[240px] text-[12px] leading-5 text-[#84928a]">Boshqa xizmat turini sinab ko‘ring.</p>
            <button
              onClick={() => {
                setQuery("");
                setSelectedCategory("Barchasi");
              }}
              className="mt-4 text-[11px] font-extrabold text-[#ff6b35]"
            >
              Filtrlarni tozalash
            </button>
          </div>
        )}
      </section>

      <button
        onClick={() => setShowPublish(true)}
        className="mx-5 mt-5 flex w-[calc(100%-40px)] items-center justify-between rounded-[19px] bg-[#17211e] px-4 py-4 text-left text-white shadow-[0_12px_24px_rgba(23,33,30,0.16)] transition hover:-translate-y-0.5"
      >
        <span className="flex items-center gap-3">
          <span className="flex h-10 w-10 items-center justify-center rounded-[13px] bg-[#ff6b35]"><Plus className="h-5 w-5" /></span>
          <span>
            <span className="block text-[12px] font-extrabold">Xizmatingizni taklif qiling</span>
            <span className="mt-0.5 block text-[10px] font-medium text-[#b9c7be]">Yangi mijozlar sizni topsin</span>
          </span>
        </span>
        <ArrowRight className="h-4 w-4 text-[#ffb79a]" />
      </button>

      {showFilters && (
        <div className="fixed inset-0 z-40 flex items-end justify-center bg-[#17211e]/30 px-3 pb-3 backdrop-blur-[2px]" role="dialog" aria-modal="true" aria-label="Filtrlar">
          <div className="w-full max-w-[414px] rounded-[24px] bg-[#f9fbf8] p-5 shadow-[0_-14px_40px_rgba(23,33,30,0.18)]">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-[10px] font-bold uppercase tracking-[0.15em] text-[#ff6b35]">Saralash</p>
                <h3 className="mt-1 text-[20px] font-extrabold tracking-[-0.04em] text-[#17211e]">Sizga mos ustalar</h3>
              </div>
              <button onClick={() => setShowFilters(false)} className="flex h-9 w-9 items-center justify-center rounded-full bg-white text-[#63746b]" aria-label="Filtrlarni yopish">
                <X className="h-4 w-4" />
              </button>
            </div>
            <div className="mt-5 space-y-3">
              <button onClick={() => setOnlyVerified((current) => !current)} className="flex w-full items-center justify-between rounded-[14px] bg-white px-3.5 py-3 text-left">
                <span><span className="block text-[12px] font-extrabold text-[#26372e]">Tekshirilgan profillar</span><span className="mt-0.5 block text-[10px] text-[#91a098]">Hujjatlari tasdiqlangan ustalar</span></span>
                <span className={`flex h-6 w-10 items-center rounded-full p-1 transition ${onlyVerified ? "bg-[#ff6b35] justify-end" : "bg-[#dce6dc] justify-start"}`}><span className="h-4 w-4 rounded-full bg-white shadow-sm" /></span>
              </button>
              <button onClick={() => setSortByRating((current) => !current)} className="flex w-full items-center justify-between rounded-[14px] bg-white px-3.5 py-3 text-left">
                <span><span className="block text-[12px] font-extrabold text-[#26372e]">Yuqori reyting avval</span><span className="mt-0.5 block text-[10px] text-[#91a098]">Mijozlar bahosiga ko'ra</span></span>
                <span className={`flex h-6 w-10 items-center rounded-full p-1 transition ${sortByRating ? "bg-[#ff6b35] justify-end" : "bg-[#dce6dc] justify-start"}`}><span className="h-4 w-4 rounded-full bg-white shadow-sm" /></span>
              </button>
            </div>
            <button onClick={() => setShowFilters(false)} className="mt-4 flex h-11 w-full items-center justify-center rounded-[14px] bg-[#17211e] text-[12px] font-extrabold text-white">Natijalarni ko'rsatish</button>
          </div>
        </div>
      )}

      {showPublish && (
        <div className="fixed inset-0 z-40 flex items-end justify-center bg-[#17211e]/30 px-3 pb-3 backdrop-blur-[2px]" role="dialog" aria-modal="true" aria-label="Xizmat profilini joylash">
          <div className="w-full max-w-[414px] rounded-[24px] bg-[#f9fbf8] p-5 shadow-[0_-14px_40px_rgba(23,33,30,0.18)]">
            <div className="flex items-start justify-between">
              <div>
                <p className="text-[10px] font-bold uppercase tracking-[0.15em] text-[#ff6b35]">Yangi imkoniyat</p>
                <h3 className="mt-1 max-w-[250px] text-[21px] font-extrabold leading-tight tracking-[-0.04em] text-[#17211e]">Xizmatingizni e’lon qiling</h3>
              </div>
              <button onClick={() => setShowPublish(false)} className="flex h-9 w-9 items-center justify-center rounded-full bg-white text-[#63746b]" aria-label="Profil formasini yopish"><X className="h-4 w-4" /></button>
            </div>
            <div className="mt-4 rounded-[15px] border border-[#f2c3ae] bg-[#fff0e7] p-3.5">
              <p className="text-[11px] font-bold leading-5 text-[#8d4b33]">Xizmatingizni qisqa yozing, narxni belgilang — qo'shnilar sizga bevosita yozadi.</p>
            </div>
            <div className="mt-4 space-y-2.5">
              <input className="h-11 w-full rounded-[13px] border border-[#dfe8df] bg-white px-3.5 text-[12px] font-medium outline-none placeholder:text-[#9aa79f] focus:border-[#ff9a75]" placeholder="Ismingiz yoki ustaxona nomi" />
              <div className="grid grid-cols-2 gap-2.5">
                <button className="flex h-11 items-center justify-between rounded-[13px] border border-[#dfe8df] bg-white px-3.5 text-left text-[11px] font-bold text-[#75837b]">Xizmat turi <ChevronDown className="h-3.5 w-3.5" /></button>
                <button className="flex h-11 items-center justify-between rounded-[13px] border border-[#dfe8df] bg-white px-3.5 text-left text-[11px] font-bold text-[#75837b]">Tuman yoki shahar <ChevronDown className="h-3.5 w-3.5" /></button>
              </div>
            </div>
            <button
              onClick={() => {
                setPublished(true);
                setShowPublish(false);
              }}
              className="mt-4 flex h-11 w-full items-center justify-center gap-2 rounded-[14px] bg-[#ff6b35] text-[12px] font-extrabold text-white shadow-[0_8px_18px_rgba(255,107,53,0.22)]"
            >
              <Sparkles className="h-4 w-4" /> Profilni boshlash
            </button>
          </div>
        </div>
      )}

      {published && (
        <button
          onClick={() => setPublished(false)}
          className="fixed bottom-[88px] left-1/2 z-50 flex -translate-x-1/2 items-center gap-2 rounded-full bg-[#17211e] px-4 py-3 text-[11px] font-bold text-white shadow-[0_10px_24px_rgba(23,33,30,0.25)]"
        >
          <Check className="h-4 w-4 text-[#8ed29c]" /> Ajoyib, profil tayyorlanmoqda
        </button>
      )}
    </AppShell>
  );
}
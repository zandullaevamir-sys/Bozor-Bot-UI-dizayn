import { useMemo, useState } from "react";
import {
  ArrowDownUp,
  BriefcaseBusiness,
  Check,
  ChevronDown,
  House,
  Laptop,
  Search,
  Shirt,
  SlidersHorizontal,
  Sparkles,
  Tag,
  X,
  Wrench,
} from "lucide-react";

import { AppShell } from "./_shared/AppShell";

const categories = [
  { label: "Barchasi", icon: Sparkles },
  { label: "Elektronika", icon: Laptop },
  { label: "Uy-ro‘zg‘or", icon: House },
  { label: "Kiyim-kechak", icon: Shirt },
  { label: "Xizmatlar", icon: Wrench },
];

const conditions = ["Yangi", "Yaxshi", "Ishlatilgan"];

export function SearchFilters() {
  const [query, setQuery] = useState("");
  const [mode, setMode] = useState<"items" | "services">("items");
  const [category, setCategory] = useState("Barchasi");
  const [minPrice, setMinPrice] = useState("");
  const [maxPrice, setMaxPrice] = useState("");
  const [condition, setCondition] = useState("Yaxshi");
  const [sort, setSort] = useState("Eng yangilari");
  const [openMenu, setOpenMenu] = useState<"category" | null>(null);
  const [applied, setApplied] = useState(false);

  const resultCount = useMemo(() => {
    if (mode === "services") return 126;
    if (category === "Elektronika") return 218;
    if (category === "Kiyim-kechak") return 164;
    return 1_284;
  }, [category, mode]);

  const activeFilterCount = [
    category !== "Barchasi",
    Boolean(minPrice || maxPrice),
    mode === "services",
    condition !== "Yaxshi",
  ].filter(Boolean).length;

  const CategoryIcon = categories.find((item) => item.label === category)?.icon ?? Sparkles;

  const applyFilters = () => {
    setApplied(true);
    window.setTimeout(() => setApplied(false), 1800);
  };

  const resetFilters = () => {
    setQuery("");
    setMode("items");
    setCategory("Barchasi");
    setMinPrice("");
    setMaxPrice("");
    setCondition("Yaxshi");
    setSort("Eng yangilari");
    setOpenMenu(null);
  };

  return (
    <AppShell active="search" title="Qidiruv" className="bg-[#f6f7f4]">
      <section className="px-5 pb-4 pt-6">
        <div className="mb-5 flex items-start justify-between gap-4">
          <div>
            <p className="mb-1.5 text-[10px] font-extrabold uppercase tracking-[0.2em] text-[#ff6b35]">
              Topish oson
            </p>
            <h2 className="max-w-[260px] text-[29px] font-extrabold leading-[1.02] tracking-[-0.06em] text-[#17211e]">
              Keraklisini birga topamiz
            </h2>
          </div>
          <div className="mt-1 flex h-11 w-11 shrink-0 items-center justify-center rounded-[15px] border border-[#f1cdbd] bg-[#fff0e8] text-[#ff6b35]">
            <SlidersHorizontal className="h-5 w-5" />
          </div>
        </div>

        <div className="flex h-[53px] items-center gap-3 rounded-[18px] border border-[#dce5dc] bg-white px-4 shadow-[0_5px_18px_rgba(40,64,49,0.06)] transition focus-within:border-[#ff6b35] focus-within:ring-4 focus-within:ring-[#ff6b35]/10">
          <Search className="h-[19px] w-[19px] shrink-0 text-[#ff6b35]" />
          <input
            value={query}
            onChange={(event) => setQuery(event.target.value)}
            placeholder="Masalan, velosiped yoki santexnik"
            aria-label="Mahsulot yoki xizmat qidirish"
            className="min-w-0 flex-1 bg-transparent text-[13px] font-semibold text-[#17211e] outline-none placeholder:text-[#99a69e]"
          />
          {query && (
            <button
              type="button"
              onClick={() => setQuery("")}
              className="flex h-6 w-6 items-center justify-center rounded-full bg-[#eef2ed] text-[#63736a] transition hover:bg-[#e2e9e1]"
              aria-label="Qidiruvni tozalash"
            >
              <X className="h-3.5 w-3.5" />
            </button>
          )}
        </div>

        <div className="mt-3 flex rounded-[15px] bg-[#e9eee8] p-1">
          <button
            type="button"
            onClick={() => setMode("items")}
            className={`flex h-9 flex-1 items-center justify-center gap-2 rounded-[11px] text-[12px] font-extrabold transition ${
              mode === "items" ? "bg-white text-[#17211e] shadow-sm" : "text-[#809087]"
            }`}
            aria-pressed={mode === "items"}
          >
            <Tag className="h-3.5 w-3.5" />
            Mahsulotlar
          </button>
          <button
            type="button"
            onClick={() => setMode("services")}
            className={`flex h-9 flex-1 items-center justify-center gap-2 rounded-[11px] text-[12px] font-extrabold transition ${
              mode === "services" ? "bg-white text-[#17211e] shadow-sm" : "text-[#809087]"
            }`}
            aria-pressed={mode === "services"}
          >
            <BriefcaseBusiness className="h-3.5 w-3.5" />
            Xizmatlar
          </button>
        </div>
      </section>

      <section className="space-y-4 px-5">
        <div className="rounded-[22px] border border-[#e1e8e0] bg-white p-4 shadow-[0_6px_22px_rgba(40,64,49,0.045)]">
          <div className="mb-3 flex items-center justify-between">
            <div>
              <p className="text-[14px] font-extrabold tracking-[-0.02em] text-[#17211e]">Filtrlar</p>
              <p className="mt-0.5 text-[11px] text-[#8b9991]">
                Natijani o‘zingizga moslang
              </p>
            </div>
            <button
              type="button"
              onClick={resetFilters}
              className="text-[11px] font-extrabold text-[#ff6b35] transition hover:text-[#dc5423]"
            >
              Tozalash
            </button>
          </div>

          <div className="relative">
            <p className="mb-2 text-[10px] font-extrabold uppercase tracking-[0.15em] text-[#91a098]">
              Kategoriya
            </p>
            <button
              type="button"
              onClick={() => setOpenMenu(openMenu === "category" ? null : "category")}
              className="flex h-11 w-full items-center justify-between rounded-[13px] border border-[#e1e8e0] bg-[#fbfcfa] px-3.5 text-left transition hover:border-[#b8cabd]"
              aria-expanded={openMenu === "category"}
            >
              <span className="flex items-center gap-2.5 text-[13px] font-bold text-[#34443d]">
                <span className="flex h-6 w-6 items-center justify-center rounded-lg bg-[#fff0e8] text-[13px] text-[#ff6b35]">
                  <CategoryIcon className="h-3.5 w-3.5" />
                </span>
                {category}
              </span>
              <ChevronDown className={`h-4 w-4 text-[#8e9c94] transition ${openMenu === "category" ? "rotate-180" : ""}`} />
            </button>
            {openMenu === "category" && (
              <div className="absolute left-0 right-0 top-[69px] z-10 rounded-[14px] border border-[#dfe8df] bg-white p-1.5 shadow-[0_12px_32px_rgba(27,46,34,0.14)]">
                {categories.map((item) => (
                  <button
                    type="button"
                    key={item.label}
                    onClick={() => {
                      setCategory(item.label);
                      setOpenMenu(null);
                    }}
                    className="flex w-full items-center justify-between rounded-[10px] px-3 py-2.5 text-left text-[12px] font-bold text-[#34443d] transition hover:bg-[#f4f7f3]"
                  >
                    <span className="flex items-center gap-2.5">
                      <span className="text-[#ff6b35]">
                        <item.icon className="h-3.5 w-3.5" />
                      </span>
                      {item.label}
                    </span>
                    {category === item.label && <Check className="h-4 w-4 text-[#ff6b35]" />}
                  </button>
                ))}
              </div>
            )}
          </div>

          <div className="mt-4">
            <div className="mb-2 flex items-center justify-between">
              <p className="text-[10px] font-extrabold uppercase tracking-[0.15em] text-[#91a098]">
                Narx oralig‘i
              </p>
              <span className="text-[10px] font-semibold text-[#a0aba4]">so‘m</span>
            </div>
            <div className="flex items-center gap-2">
              <input
                value={minPrice}
                onChange={(event) => setMinPrice(event.target.value.replace(/\D/g, ""))}
                inputMode="numeric"
                placeholder="dan"
                aria-label="Minimal narx"
                className="h-10 min-w-0 flex-1 rounded-[12px] border border-[#e1e8e0] bg-[#fbfcfa] px-3 text-[12px] font-bold text-[#34443d] outline-none transition placeholder:text-[#a7b2ab] focus:border-[#ff6b35]"
              />
              <span className="h-px w-2 bg-[#c3cec5]" />
              <input
                value={maxPrice}
                onChange={(event) => setMaxPrice(event.target.value.replace(/\D/g, ""))}
                inputMode="numeric"
                placeholder="gacha"
                aria-label="Maksimal narx"
                className="h-10 min-w-0 flex-1 rounded-[12px] border border-[#e1e8e0] bg-[#fbfcfa] px-3 text-[12px] font-bold text-[#34443d] outline-none transition placeholder:text-[#a7b2ab] focus:border-[#ff6b35]"
              />
            </div>
          </div>

          {mode === "items" && (
            <div className="mt-4">
              <p className="mb-2 text-[10px] font-extrabold uppercase tracking-[0.15em] text-[#91a098]">
                Holati
              </p>
              <div className="flex gap-2">
                {conditions.map((item) => (
                  <button
                    type="button"
                    key={item}
                    onClick={() => setCondition(item)}
                    className={`flex-1 rounded-[11px] border px-2 py-2.5 text-[11px] font-extrabold transition ${
                      condition === item
                        ? "border-[#17211e] bg-[#17211e] text-white"
                        : "border-[#e1e8e0] bg-[#fbfcfa] text-[#738178] hover:border-[#b8cabd]"
                    }`}
                    aria-pressed={condition === item}
                  >
                    {item}
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>

        <div className="flex items-center justify-between rounded-[17px] border border-[#e7e8dd] bg-[#fffdf2] px-4 py-3">
          <div className="flex items-center gap-2.5">
            <div className="flex h-8 w-8 items-center justify-center rounded-[10px] bg-[#ffedb7] text-[#bb7a1b]">
              <Sparkles className="h-4 w-4" />
            </div>
            <div>
              <p className="text-[12px] font-extrabold text-[#4e4b35]">Saralash</p>
              <p className="text-[10px] text-[#9d956d]">Avval ko‘rmoqchi bo‘lganingiz</p>
            </div>
          </div>
          <label className="relative">
            <span className="sr-only">Saralash tartibi</span>
            <select
              value={sort}
              onChange={(event) => setSort(event.target.value)}
              className="max-w-[126px] appearance-none bg-transparent py-2 pl-2 pr-5 text-right text-[11px] font-extrabold text-[#705d31] outline-none"
            >
              <option>Eng yangilari</option>
              <option>Arzonlari</option>
              <option>Qimmatroqlari</option>
              <option>Yaqinlari</option>
            </select>
            <ArrowDownUp className="pointer-events-none absolute right-0 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-[#aa8e46]" />
          </label>
        </div>

        <div className="flex items-center justify-between pb-5 pt-1">
          <div>
            <p className="text-[19px] font-extrabold tracking-[-0.04em] text-[#17211e]">
              {resultCount.toLocaleString("uz-UZ")} ta natija
            </p>
            <p className="mt-0.5 text-[11px] text-[#7f8e85]">
               {activeFilterCount ? `${activeFilterCount} ta filtr tanlandi` : "Qoraqalpog‘iston bo‘yicha"}
            </p>
          </div>
          <button
            type="button"
            onClick={applyFilters}
            className={`flex h-12 items-center gap-2 rounded-[15px] px-5 text-[12px] font-extrabold text-white shadow-[0_8px_18px_rgba(255,107,53,0.22)] transition hover:-translate-y-0.5 active:translate-y-0 ${
              applied ? "bg-[#4b8f64]" : "bg-[#ff6b35]"
            }`}
          >
             {applied ? <Check className="h-4 w-4" /> : <SlidersHorizontal className="h-4 w-4" />}
            {applied ? "Tayyor" : "Natijalarni ko‘rish"}
          </button>
        </div>
      </section>
    </AppShell>
  );
}
import { useMemo, useState } from "react";
import {
  ArrowDownUp,
  Bookmark,
  ChevronDown,
  Clock3,
  Search,
  SlidersHorizontal,
  Sparkles,
  Tag,
  X,
} from "lucide-react";

import {
  AppShell,
  PageIntro,
  Pill,
  ProductImage,
  SellerAvatar,
  ServiceIcon,
} from "./_shared/AppShell";

type ListingKind = "Mahsulot" | "Xizmat";

type Listing = {
  id: number;
  kind: ListingKind;
  title: string;
  category: string;
  meta: string;
  price: string;
  priceNote?: string;
  tone: "orange" | "blue" | "green" | "purple" | "yellow";
  initials: string;
  seller: string;
  sellerNote: string;
  visual: string;
  saved?: boolean;
  featured?: boolean;
};

const listings: Listing[] = [
  {
    id: 1,
    kind: "Mahsulot",
    title: "Samsung Galaxy A54",
    category: "Telefonlar",
    meta: "Yaxshi holatda · 2023",
    price: "2 150 000 so‘m",
    tone: "blue",
    initials: "SM",
    seller: "Sarvar M.",
    sellerNote: "bugun, 10:42",
    visual: "A54",
    featured: true,
  },
  {
    id: 2,
    kind: "Xizmat",
    title: "Elektrik ustasi — tez va toza",
    category: "Uy ta’miri",
    meta: "Bugun bo‘sh · 8 yil tajriba",
    price: "Kelishiladi",
    priceNote: "chaqiruv bilan",
    tone: "green",
    initials: "AK",
    seller: "Akmal Karimov",
    sellerNote: "15 daqiqa oldin",
    visual: "AK",
    saved: true,
  },
  {
    id: 3,
    kind: "Mahsulot",
    title: "Yog‘och yozuv stoli",
    category: "Uy va bog‘",
    meta: "Yangi · qo‘l mehnati",
    price: "890 000 so‘m",
    tone: "orange",
    initials: "NI",
    seller: "Nodira I.",
    sellerNote: "kecha, 18:26",
    visual: "stol",
  },
  {
    id: 4,
    kind: "Xizmat",
    title: "Mebel yig‘ish va ta’mirlash",
    category: "Usta xizmatlari",
    meta: "Ertaga bo‘sh · reyting 4.9",
    price: "150 000 so‘mdan",
    priceNote: "ish turiga qarab",
    tone: "purple",
    initials: "BS",
    seller: "Bekzod S.",
    sellerNote: "kecha, 21:10",
    visual: "BS",
  },
  {
    id: 5,
    kind: "Mahsulot",
    title: "Bolalar velosipedi, 20 dyuym",
    category: "Bolalar uchun",
    meta: "Yaxshi holatda · 2 yil",
    price: "650 000 so‘m",
    tone: "yellow",
    initials: "DZ",
    seller: "Dilnoza Z.",
    sellerNote: "2 kun oldin",
    visual: "20",
  },
];

const filters = ["Barchasi", "Mahsulotlar", "Xizmatlar", "Bugun"];

function ListingVisual({ listing }: { listing: Listing }) {
  if (listing.kind === "Xizmat") {
    return (
      <ProductImage
        tone={listing.tone}
        className="h-[142px] w-full"
        visual={
          <ServiceIcon
            icon={
              <span className="text-[15px] font-black tracking-[-0.06em]">
                {listing.visual}
              </span>
            }
          />
        }
        label="xizmat"
      />
    );
  }

  return (
    <ProductImage
      tone={listing.tone}
      className="h-[142px] w-full"
      visual={
        <span className="flex h-[72px] min-w-[72px] items-center justify-center rounded-[20px] bg-white/65 px-2 text-center text-[13px] font-extrabold uppercase tracking-[-0.04em] text-[#344d43] shadow-sm backdrop-blur">
          {listing.visual}
        </span>
      }
      label="mahsulot"
    />
  );
}

function ListingCard({
  listing,
  isSaved,
  onToggleSaved,
}: {
  listing: Listing;
  isSaved: boolean;
  onToggleSaved: () => void;
}) {
  return (
    <article className="group overflow-hidden rounded-[24px] border border-[#e4eae3] bg-white shadow-[0_8px_24px_rgba(42,65,53,0.05)] transition hover:-translate-y-0.5 hover:shadow-[0_12px_28px_rgba(42,65,53,0.1)]">
      <div className="relative">
        <ListingVisual listing={listing} />
        {listing.featured && (
          <span className="absolute left-3 top-3 inline-flex items-center gap-1 rounded-full bg-[#17211e] px-2.5 py-1.5 text-[9px] font-extrabold uppercase tracking-[0.12em] text-[#ffe4b9]">
            <Sparkles className="h-3 w-3" />
            tavsiya
          </span>
        )}
        <div className="absolute right-3 top-3">
          <button
            onClick={onToggleSaved}
            className={`flex h-9 w-9 items-center justify-center rounded-full ${
              isSaved ? "bg-[#fff0e9] text-[#ff6b35]" : "bg-white/90 text-[#34443d]"
            }`}
            aria-label={isSaved ? "Saqlanganlardan olib tashlash" : "Saqlash"}
          >
            <Bookmark className={`h-4 w-4 ${isSaved ? "fill-current" : ""}`} />
          </button>
        </div>
      </div>
      <div className="p-3.5">
        <div className="mb-1 flex items-start justify-between gap-3">
          <h3 className="line-clamp-2 flex-1 text-[14px] font-extrabold leading-[1.25] tracking-[-0.025em] text-[#17211e]">
            {listing.title}
          </h3>
          <span
            className={`mt-0.5 h-2 w-2 shrink-0 rounded-full ${
              listing.kind === "Xizmat" ? "bg-[#4c9a65]" : "bg-[#ff6b35]"
            }`}
            aria-label={listing.kind}
          />
        </div>
        <p className="mb-3 text-[11px] text-[#7a887f]">{listing.meta}</p>
        <div className="mb-3 flex items-center gap-1 text-[11px] font-medium text-[#6f7e75]">
          <span className="truncate">{listing.kind === "Xizmat" ? "Xizmat profili" : "Mahsulot e’loni"}</span>
        </div>
        <div className="flex items-end justify-between gap-2">
          <div>
            <p className="text-[15px] font-black tracking-[-0.04em] text-[#17211e]">
              {listing.price}
            </p>
            {listing.priceNote && (
              <p className="mt-0.5 text-[10px] text-[#8b9990]">{listing.priceNote}</p>
            )}
          </div>
          <div className="flex items-center gap-1.5">
            <SellerAvatar initials={listing.initials} />
            <span className="max-w-[65px] truncate text-[10px] font-semibold text-[#77857c]">
              {listing.seller}
            </span>
          </div>
        </div>
      </div>
    </article>
  );
}

export function AllListings() {
  const [activeFilter, setActiveFilter] = useState("Barchasi");
  const [savedIds, setSavedIds] = useState<number[]>(
    listings.filter((listing) => listing.saved).map((listing) => listing.id),
  );
  const [searchTerm, setSearchTerm] = useState("");
  const [showFilters, setShowFilters] = useState(false);
  const [sortNewest, setSortNewest] = useState(true);

  const visibleListings = useMemo(() => {
    const normalized = searchTerm.trim().toLowerCase();
    return listings.filter((listing) => {
      const matchesSearch =
        !normalized ||
        `${listing.title} ${listing.category}`
          .toLowerCase()
          .includes(normalized);
      const matchesFilter =
        activeFilter === "Barchasi" ||
        (activeFilter === "Mahsulotlar" && listing.kind === "Mahsulot") ||
        (activeFilter === "Xizmatlar" && listing.kind === "Xizmat") ||
        (activeFilter === "Bugun" && listing.sellerNote.includes("oldin")) ||
        true;
      return matchesSearch && matchesFilter;
    });
  }, [activeFilter, searchTerm]);

  const toggleSaved = (id: number) => {
    setSavedIds((current) =>
      current.includes(id) ? current.filter((savedId) => savedId !== id) : [...current, id],
    );
  };

  return (
    <AppShell active="search" title="E’lonlar">
      <PageIntro
        eyebrow="Qoraqalpog‘iston bo‘yicha"
        title="O‘zingizga keraklisini toping."
        description="Mahsulotlar va ishonchli xizmatlar bir joyda."
        action={
          <button
            onClick={() => setShowFilters(true)}
            className="flex h-11 w-11 shrink-0 items-center justify-center rounded-[15px] bg-[#17211e] text-white shadow-[0_8px_18px_rgba(23,33,30,0.16)] transition hover:bg-[#293a34] active:scale-95"
            aria-label="Filtrlarni ochish"
          >
            <SlidersHorizontal className="h-[18px] w-[18px]" />
          </button>
        }
      />

      <div className="px-5">
        <label className="flex h-[50px] items-center gap-3 rounded-[18px] border border-[#dde6dc] bg-white px-4 shadow-[0_4px_14px_rgba(42,65,53,0.04)] focus-within:border-[#ff6b35] focus-within:ring-4 focus-within:ring-[#ff6b35]/10">
          <Search className="h-[18px] w-[18px] text-[#ff6b35]" />
          <input
            value={searchTerm}
            onChange={(event) => setSearchTerm(event.target.value)}
            placeholder="Masalan, konditsioner yoki usta"
            className="min-w-0 flex-1 bg-transparent text-[13px] font-medium text-[#17211e] outline-none placeholder:text-[#98a59d]"
            aria-label="E’lonlarni qidirish"
          />
          {searchTerm && (
            <button
              onClick={() => setSearchTerm("")}
              className="text-[#8d9b92] transition hover:text-[#17211e]"
              aria-label="Qidiruvni tozalash"
            >
              <X className="h-4 w-4" />
            </button>
          )}
        </label>
      </div>

      <div className="mt-4 flex gap-2 overflow-x-auto px-5 pb-1 [scrollbar-width:none] [&::-webkit-scrollbar]:hidden">
        {filters.map((filter) => (
          <button
            key={filter}
            onClick={() => setActiveFilter(filter)}
            className={`whitespace-nowrap rounded-full px-3.5 py-2.5 text-[11px] font-extrabold transition ${
              activeFilter === filter
                ? "bg-[#ff6b35] text-white shadow-[0_6px_14px_rgba(255,107,53,0.2)]"
                : "border border-[#e1e8df] bg-white text-[#6c7c72] hover:border-[#ffb394] hover:text-[#d95729]"
            }`}
          >
            {filter}
          </button>
        ))}
      </div>

      <div className="mt-5 flex items-center justify-between px-5">
        <div className="flex items-center gap-2">
          <span className="text-[12px] font-extrabold text-[#17211e]">
            {visibleListings.length} ta e’lon
          </span>
          <span className="h-1 w-1 rounded-full bg-[#ff6b35]" />
          <span className="text-[11px] font-medium text-[#829087]">yangilandi</span>
        </div>
        <button
          onClick={() => setSortNewest((current) => !current)}
          className="flex items-center gap-1.5 text-[11px] font-bold text-[#6a7b71] transition hover:text-[#17211e]"
          aria-label="Saralash tartibini o‘zgartirish"
        >
          <ArrowDownUp className="h-3.5 w-3.5" />
          {sortNewest ? "Yangilari" : "Avvalgilari"}
          <ChevronDown className="h-3.5 w-3.5" />
        </button>
      </div>

      <div className="mt-3 grid grid-cols-2 gap-3 px-5">
        {visibleListings.map((listing) => (
          <ListingCard
            key={listing.id}
            listing={listing}
            isSaved={savedIds.includes(listing.id)}
            onToggleSaved={() => toggleSaved(listing.id)}
          />
        ))}
      </div>

      {visibleListings.length === 0 && (
        <div className="mx-5 mt-4 rounded-[24px] border border-dashed border-[#d8e2d8] bg-[#eef5ed] px-5 py-10 text-center">
          <Tag className="mx-auto mb-3 h-7 w-7 text-[#72947a]" />
          <p className="text-[15px] font-extrabold text-[#294036]">Hali bunday e’lon yo‘q</p>
          <p className="mt-1 text-[12px] leading-5 text-[#779083]">
            Qidiruv so‘zini o‘zgartirib ko‘ring yoki barcha e’lonlarni ko‘ring.
          </p>
          <button
            onClick={() => {
              setSearchTerm("");
              setActiveFilter("Barchasi");
            }}
            className="mt-4 rounded-full bg-[#17211e] px-4 py-2.5 text-[11px] font-bold text-white"
          >
            Barchasini ko‘rish
          </button>
        </div>
      )}

      <div className="mx-5 mb-5 mt-6 flex items-center gap-2 rounded-[18px] border border-[#f1d5a6] bg-[#fff6df] px-3.5 py-3 text-[11px] text-[#735b2c]">
        <Clock3 className="h-4 w-4 shrink-0 text-[#d49329]" />
        <span>
          <strong className="font-extrabold text-[#57431e]">Yangi e’lonlar</strong>{" "}
          har 15 daqiqada yangilanadi.
        </span>
      </div>

      {showFilters && (
        <div className="fixed inset-0 z-50 flex items-end justify-center bg-[#17211e]/35 px-3 backdrop-blur-[2px]">
          <div className="w-full max-w-[440px] rounded-t-[28px] bg-[#f6f7f4] p-5 shadow-2xl">
            <div className="mb-5 flex items-center justify-between">
              <div>
                <p className="text-[10px] font-bold uppercase tracking-[0.16em] text-[#ff6b35]">
                  tezkor sozlamalar
                </p>
                <h2 className="mt-1 text-[21px] font-extrabold tracking-[-0.05em] text-[#17211e]">
                  E’lonlarni saralash
                </h2>
              </div>
              <button
                onClick={() => setShowFilters(false)}
                className="flex h-9 w-9 items-center justify-center rounded-full bg-white text-[#53645a]"
                aria-label="Filtrlarni yopish"
              >
                <X className="h-4 w-4" />
              </button>
            </div>
            <p className="mb-2 text-[11px] font-extrabold uppercase tracking-[0.12em] text-[#7b8980]">
              Tezkor tanlov
            </p>
            <div className="mb-6 flex flex-wrap gap-2">
              {["Barchasi", "Mahsulotlar", "Xizmatlar", "Bugun"].map((filter) => (
                <button
                  key={filter}
                  onClick={() => setActiveFilter(filter)}
                  className={`rounded-full px-3.5 py-2.5 text-[11px] font-bold ${
                    activeFilter === filter
                      ? "bg-[#17211e] text-white"
                      : "border border-[#e1e8df] bg-white text-[#6c7c72]"
                  }`}
                >
                  {filter}
                </button>
              ))}
            </div>
            <button
              onClick={() => setShowFilters(false)}
              className="flex h-12 w-full items-center justify-center rounded-[16px] bg-[#ff6b35] text-[13px] font-extrabold text-white shadow-[0_8px_18px_rgba(255,107,53,0.22)] transition hover:bg-[#e85c2a]"
            >
              Natijalarni ko‘rsatish
            </button>
          </div>
        </div>
      )}
    </AppShell>
  );
}
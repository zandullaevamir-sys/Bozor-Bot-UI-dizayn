export function LogoRobot() {
  return (
    <main className="min-h-screen bg-[#f3f8ff] p-8 font-sans text-[#183b5b]">
      <div className="mx-auto flex max-w-sm flex-col items-center justify-center gap-8 rounded-[32px] border border-[#d7e8f4] bg-white p-10 shadow-[0_18px_50px_rgba(57,117,166,0.12)]">
        <div className="text-center">
          <p className="text-[10px] font-black uppercase tracking-[0.25em] text-[#419fe7]">Variant 01 · Robot mascot</p>
          <h1 className="mt-2 text-2xl font-black tracking-[-0.06em]">Friendly signal</h1>
          <p className="mt-2 text-sm leading-6 text-[#6f8ca2]">Mavjud robot obrazini soddalashtirib, brendning do‘stona xarakterini saqlaydi.</p>
        </div>

        <div className="relative flex h-44 w-44 items-center justify-center rounded-[46px] bg-gradient-to-br from-[#dff3ff] to-[#b8e2fb] shadow-[0_18px_30px_rgba(65,159,231,0.2)]">
          <div className="absolute -top-4 h-8 w-1.5 rounded-full bg-[#277bb5]" />
          <div className="absolute -top-7 flex h-5 w-5 items-center justify-center rounded-full bg-[#419fe7] shadow-[0_0_0_6px_rgba(65,159,231,0.15)]" />
          <div className="relative flex h-28 w-32 items-center justify-center rounded-[32px] bg-[#2f83bd] shadow-[inset_0_-9px_0_rgba(17,71,108,0.18),0_12px_18px_rgba(34,102,151,0.22)]">
            <div className="absolute -left-3 top-9 h-10 w-4 rounded-full bg-[#78c8f3]" />
            <div className="absolute -right-3 top-9 h-10 w-4 rounded-full bg-[#78c8f3]" />
            <div className="flex h-16 w-20 items-center justify-center gap-5 rounded-[22px] bg-[#effaff]">
              <span className="h-4 w-4 rounded-full bg-[#2f83bd] shadow-[0_0_0_4px_rgba(47,131,189,0.12)]" />
              <span className="h-4 w-4 rounded-full bg-[#2f83bd] shadow-[0_0_0_4px_rgba(47,131,189,0.12)]" />
              <span className="absolute mt-9 h-1.5 w-7 rounded-full bg-[#78c8f3]" />
            </div>
          </div>
        </div>

        <div className="text-center">
          <p className="text-2xl font-black tracking-[-0.06em]">Bozor Bot</p>
          <p className="mt-1 text-[10px] font-bold uppercase tracking-[0.22em] text-[#7897ad]">Qaraqalpaqstan marketplace</p>
        </div>
      </div>
    </main>
  );
}
import { useMemo, useState } from "react";
import {
  ArrowLeft,
  ArrowRight,
  BadgeCheck,
  Camera,
  Check,
  ChevronDown,
  CircleHelp,
  FileText,
  Home,
  ImagePlus,
  MessageCircle,
  MoreHorizontal,
  Phone,
  Plus,
  RotateCcw,
  Send,
  ShieldCheck,
  Sparkles,
  Tag,
  Trash2,
  UserRound,
  Wrench,
  X,
} from "lucide-react";
import { AppShell } from "./_shared/AppShell";

type ListingKind = "product" | "service";
type Step = 1 | 2 | 3;

const categories = {
  product: ["Elektronika", "Uy-ro‘zg‘or", "Kiyim", "Bolalar uchun", "Avto", "Boshqa"],
  service: ["Ta’mirlash", "Tozalash", "Ta’lim", "Go‘zallik", "Yetkazib berish", "Boshqa"],
};

const districts = [
  "Nukus shahri",
  "Nukus tumani",
  "Amudaryo tumani",
  "Beruniy tumani",
  "Bo‘zatov tumani",
  "Chimboy tumani",
  "Ellikqal’a tumani",
  "Kegeyli tumani",
  "Mo‘ynoq tumani",
  "Qanliko‘l tumani",
  "Qorao‘zak tumani",
  "Qo‘ng‘irot tumani",
  "Shumanay tumani",
  "Taxtako‘pir tumani",
  "Taxiatosh shahri",
  "To‘rtko‘l tumani",
  "Xo‘jayli tumani",
];

export function CreateListing() {
  const [kind, setKind] = useState<ListingKind>("product");
  const [step, setStep] = useState<Step>(1);
  const [photos, setPhotos] = useState(1);
  const [published, setPublished] = useState(false);
  const [draftSaved, setDraftSaved] = useState(false);
  const [form, setForm] = useState({
    title: "",
    category: "Elektronika",
    price: "",
    pricing: "fixed",
    district: "Nukus shahri",
    description: "",
    contact: "chat",
  });

  const categoryOptions = categories[kind];
  const title = kind === "product" ? "Mahsulotingizga yangi uy toping" : "Hunarni qo‘shnilarga taniting";
  const listingName = form.title || (kind === "product" ? "iPhone 12 Pro, yaxshi holatda" : "Usta — konditsioner ta’miri");
  const priceLabel =
    kind === "service"
      ? form.pricing === "negotiable"
        ? "Kelishiladi"
        : form.price
          ? `${form.price} so‘m / xizmat`
          : "Narx kelishiladi"
      : form.price
        ? `${Number(form.price).toLocaleString("uz-UZ")} so‘m`
        : "Narx ko‘rsatilmagan";

  const progress = useMemo(() => (step / 3) * 100, [step]);

  const updateForm = (key: keyof typeof form, value: string) => {
    setForm((current) => ({ ...current, [key]: value }));
    setDraftSaved(false);
  };

  const goBack = () => {
    if (published) {
      setPublished(false);
      setStep(3);
      return;
    }
    if (step > 1) setStep((current) => (current - 1) as Step);
    else window.history.back();
  };

  const goNext = () => {
    if (step < 3) setStep((current) => (current + 1) as Step);
    else setPublished(true);
  };

  if (published) {
    return (
      <AppShell active="sell" title="E’lon berish" showBack onBack={goBack}>
        <div className="px-5 pb-8 pt-8">
          <div className="relative overflow-hidden rounded-[28px] bg-[#17211e] px-6 pb-7 pt-8 text-white shadow-[0_18px_45px_rgba(23,33,30,0.16)]">
            <span className="absolute -right-12 -top-16 h-40 w-40 rounded-full border-[18px] border-[#ff6b35]/30" />
            <span className="absolute -bottom-12 -left-16 h-36 w-36 rounded-full bg-[#ff6b35]/20" />
            <span className="relative flex h-16 w-16 items-center justify-center rounded-[22px] bg-[#ff6b35] shadow-[0_10px_25px_rgba(255,107,53,0.35)]">
              <Check className="h-8 w-8 stroke-[2.5]" />
            </span>
            <p className="relative mt-7 text-[11px] font-bold uppercase tracking-[0.18em] text-[#ffb395]">
              E’lon tayyor
            </p>
            <h2 className="relative mt-2 text-[29px] font-black leading-[1.04] tracking-[-0.06em]">
              Xaridorlar sizni
              <br />
              kutyapti.
            </h2>
            <p className="relative mt-3 max-w-[280px] text-[13px] leading-5 text-[#b9c8bf]">
              E’loningiz ko‘rib chiqilgach, Bozorda ko‘rinadi. Odatda bu bir necha daqiqa oladi.
            </p>
          </div>

          <div className="mt-4 rounded-[22px] border border-[#e4eae3] bg-white p-4 shadow-[0_8px_25px_rgba(55,76,62,0.05)]">
            <div className="flex items-start gap-3">
              <div className="flex h-14 w-14 shrink-0 items-center justify-center rounded-2xl bg-[#fff0e8] text-[#ff6b35]">
                {kind === "product" ? <Tag className="h-6 w-6" /> : <Wrench className="h-6 w-6" />}
              </div>
              <div className="min-w-0">
                <p className="truncate text-[15px] font-extrabold text-[#17211e]">{listingName}</p>
                <p className="mt-1 text-[12px] text-[#718078]">
                  {form.category} · {form.district}
                </p>
                <p className="mt-2 text-[13px] font-black text-[#ff6b35]">{priceLabel}</p>
              </div>
              <BadgeCheck className="ml-auto h-5 w-5 shrink-0 text-[#4b8f64]" />
            </div>
          </div>

          <button
            type="button"
            onClick={() => {
              setPublished(false);
              setStep(1);
              setForm({
                title: "",
                category: kind === "product" ? "Elektronika" : "Ta’mirlash",
                price: "",
                pricing: "fixed",
                district: "Nukus shahri",
                description: "",
                contact: "chat",
              });
              setPhotos(1);
            }}
            className="mt-5 flex h-12 w-full items-center justify-center gap-2 rounded-2xl border border-[#dfe6df] bg-white text-[13px] font-extrabold text-[#34443d] transition hover:border-[#ff6b35] hover:text-[#ff6b35]"
          >
            <Plus className="h-4 w-4" />
            Yana bir e’lon berish
          </button>
        </div>
      </AppShell>
    );
  }

  return (
    <AppShell
      active="sell"
      title="E’lon berish"
      showBack
      onBack={goBack}
      rightAction={
        <button
          type="button"
          onClick={() => setDraftSaved(true)}
          className="flex items-center gap-1.5 rounded-full border border-[#dfe6df] bg-white px-3 py-2 text-[11px] font-bold text-[#63736a] transition hover:border-[#ff6b35] hover:text-[#ff6b35]"
        >
          {draftSaved ? <Check className="h-3.5 w-3.5 text-[#4b8f64]" /> : <FileText className="h-3.5 w-3.5" />}
          {draftSaved ? "Saqlandi" : "Qoralama"}
        </button>
      }
    >
      <div className="px-5 pb-7 pt-5">
        <div className="mb-5 flex items-start justify-between gap-3">
          <div>
            <p className="text-[11px] font-bold uppercase tracking-[0.18em] text-[#ff6b35]">Yangi e’lon</p>
            <h2 className="mt-1 text-[26px] font-black leading-[1.05] tracking-[-0.055em] text-[#17211e]">{title}</h2>
          </div>
          <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-[15px] bg-[#fff0e8] text-[#ff6b35]">
            {kind === "product" ? <Tag className="h-5 w-5" /> : <Wrench className="h-5 w-5" />}
          </div>
        </div>

        <div className="rounded-[22px] bg-[#17211e] p-4 text-white shadow-[0_12px_30px_rgba(23,33,30,0.14)]">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-bold uppercase tracking-[0.14em] text-[#a9b9b0]">Qadam {step} / 3</span>
            <span className="text-[12px] font-bold text-[#ffb395]">{Math.round(progress)}% tayyor</span>
          </div>
          <div className="mt-3 grid grid-cols-3 gap-1.5" aria-label="E’lon yaratish jarayoni">
            {[1, 2, 3].map((item) => (
              <button
                type="button"
                key={item}
                onClick={() => item <= step && setStep(item as Step)}
                aria-label={`${item}-qadamga o‘tish`}
                className={`h-1.5 rounded-full transition ${item <= step ? "bg-[#ff6b35]" : "bg-[#43514a]"}`}
              />
            ))}
          </div>
          <div className="mt-3 flex justify-between text-[10px] font-bold text-[#a9b9b0]">
            <span className={step >= 1 ? "text-white" : ""}>Asosiy ma’lumot</span>
            <span className={step >= 2 ? "text-white" : ""}>Tafsilotlar</span>
            <span className={step >= 3 ? "text-white" : ""}>Tekshirish</span>
          </div>
        </div>

        {step === 1 && (
          <section className="mt-5 space-y-5">
            <div>
              <p className="mb-2.5 text-[13px] font-extrabold text-[#34443d]">Nima taklif qilasiz?</p>
              <div className="grid grid-cols-2 gap-2.5">
                {([
                  ["product", "Mahsulot", "Sotiladigan buyumlar", Tag],
                  ["service", "Xizmat", "Hunar va yordam", Wrench],
                ] as const).map(([value, label, caption, Icon]) => (
                  <button
                    type="button"
                    key={value}
                    onClick={() => {
                      setKind(value);
                      updateForm("category", value === "product" ? "Elektronika" : "Ta’mirlash");
                    }}
                    className={`relative rounded-[19px] border p-3.5 text-left transition ${
                      kind === value
                        ? "border-[#ff6b35] bg-[#fff4ee] shadow-[0_8px_20px_rgba(255,107,53,0.1)]"
                        : "border-[#e2e9e1] bg-white hover:border-[#ffb395]"
                    }`}
                  >
                    {kind === value && (
                      <span className="absolute right-3 top-3 flex h-5 w-5 items-center justify-center rounded-full bg-[#ff6b35] text-white">
                        <Check className="h-3 w-3" />
                      </span>
                    )}
                    <span className={`flex h-9 w-9 items-center justify-center rounded-xl ${kind === value ? "bg-[#ff6b35] text-white" : "bg-[#eef3ed] text-[#557066]"}`}>
                      <Icon className="h-4 w-4" />
                    </span>
                    <p className="mt-3 text-[13px] font-extrabold text-[#17211e]">{label}</p>
                    <p className="mt-0.5 text-[10px] text-[#718078]">{caption}</p>
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label htmlFor="listing-title" className="mb-2 block text-[13px] font-extrabold text-[#34443d]">
                Sarlavha
              </label>
              <input
                id="listing-title"
                value={form.title}
                onChange={(event) => updateForm("title", event.target.value)}
                placeholder={kind === "product" ? "Masalan: iPhone 12 Pro, 128 GB" : "Masalan: Konditsioner ta’miri"}
                className="h-12 w-full rounded-2xl border border-[#e0e8df] bg-white px-4 text-[13px] font-semibold text-[#17211e] outline-none transition placeholder:text-[#a0aca5] focus:border-[#ff6b35] focus:ring-4 focus:ring-[#ff6b35]/10"
              />
              <p className="mt-1.5 flex items-center gap-1 text-[10px] text-[#91a098]">
                <Sparkles className="h-3 w-3 text-[#ff6b35]" />
                Qisqa va aniq sarlavha tezroq topiladi
              </p>
            </div>

            <div>
              <label htmlFor="category" className="mb-2 block text-[13px] font-extrabold text-[#34443d]">
                Kategoriya
              </label>
              <div className="relative">
                <select
                  id="category"
                  value={form.category}
                  onChange={(event) => updateForm("category", event.target.value)}
                  className="h-12 w-full appearance-none rounded-2xl border border-[#e0e8df] bg-white px-4 pr-10 text-[13px] font-semibold text-[#34443d] outline-none focus:border-[#ff6b35] focus:ring-4 focus:ring-[#ff6b35]/10"
                >
                  {categoryOptions.map((category) => (
                    <option key={category}>{category}</option>
                  ))}
                </select>
                <ChevronDown className="pointer-events-none absolute right-4 top-1/2 h-4 w-4 -translate-y-1/2 text-[#718078]" />
              </div>
            </div>
          </section>
        )}

        {step === 2 && (
          <section className="mt-5 space-y-5">
            <div>
              <div className="mb-2.5 flex items-end justify-between">
                <div>
                  <p className="text-[13px] font-extrabold text-[#34443d]">{kind === "product" ? "Rasmlar" : "Muqova rasmi"}</p>
                  <p className="mt-1 text-[11px] text-[#91a098]">{kind === "product" ? "Yaxshi rasm ko‘proq ishonch uyg‘otadi" : "Xizmatingizni bir qarashda ko‘rsating"}</p>
                </div>
                <span className="text-[11px] font-bold text-[#ff6b35]">{photos}/5</span>
              </div>
              <div className="grid grid-cols-4 gap-2">
                {Array.from({ length: Math.min(photos, 4) }).map((_, index) => (
                  <div key={index} className={`relative flex aspect-square items-center justify-center overflow-hidden rounded-2xl ${index === 0 ? "bg-[#ffd6bd]" : index % 2 ? "bg-[#d8e9e2]" : "bg-[#e8e0cf]"}`}>
                    {index === 0 ? (
                      <>
                        <span className="h-12 w-12 rounded-[17px] border-2 border-[#ff6b35]/70 bg-[#fff0e8]/80" />
                        <span className="absolute bottom-3 left-3 h-2 w-7 rounded-full bg-[#ff6b35]/60" />
                        <span className="absolute right-3 top-3 h-3 w-3 rounded-full bg-[#ff6b35]" />
                      </>
                    ) : index === 1 ? (
                      <Home className="h-7 w-7 text-[#4e8068]" />
                    ) : (
                      <Camera className="h-6 w-6 text-[#8e7652]" />
                    )}
                    {index === 0 && (
                      <span className="absolute bottom-1.5 left-1.5 rounded bg-white/75 px-1 text-[8px] font-bold uppercase tracking-[0.1em] text-[#63736a]">
                        Asosiy
                      </span>
                    )}
                    {index > 0 && (
                      <button
                        type="button"
                        onClick={() => setPhotos((current) => Math.max(1, current - 1))}
                        aria-label="Rasmni olib tashlash"
                        className="absolute right-1.5 top-1.5 flex h-6 w-6 items-center justify-center rounded-full bg-white/85 text-[#63736a]"
                      >
                        <X className="h-3 w-3" />
                      </button>
                    )}
                  </div>
                ))}
                {photos < 4 && (
                  <button
                    type="button"
                    onClick={() => setPhotos((current) => Math.min(5, current + 1))}
                    className="flex aspect-square flex-col items-center justify-center rounded-2xl border border-dashed border-[#ffb395] bg-[#fff8f4] text-[#ff6b35] transition hover:bg-[#fff0e8]"
                  >
                    <ImagePlus className="h-5 w-5" />
                    <span className="mt-1 text-[9px] font-extrabold">Qo‘shish</span>
                  </button>
                )}
              </div>
              <p className="mt-2 flex items-center gap-1.5 text-[10px] text-[#91a098]">
                <CircleHelp className="h-3 w-3" />
                {kind === "product" ? "Birinchi rasm e’lon muqovasi bo‘ladi." : "Telefon raqami yoki yuzlarni rasmda ko‘rsatmaslik ma’qul."}
              </p>
            </div>

            <div>
              <p className="mb-2.5 text-[13px] font-extrabold text-[#34443d]">Narx</p>
              <div className="mb-2.5 grid grid-cols-2 gap-2">
                {[
                  ["fixed", kind === "product" ? "Aniq narx" : "Xizmat narxi"],
                  ["negotiable", "Kelishiladi"],
                ].map(([value, label]) => (
                  <button
                    type="button"
                    key={value}
                    onClick={() => updateForm("pricing", value)}
                    className={`rounded-xl border px-3 py-2.5 text-left text-[11px] font-bold transition ${form.pricing === value ? "border-[#17211e] bg-[#17211e] text-white" : "border-[#e0e8df] bg-white text-[#63736a]"}`}
                  >
                    {label}
                  </button>
                ))}
              </div>
              {form.pricing === "fixed" && (
                <div className="relative">
                  <input
                    inputMode="numeric"
                    value={form.price}
                    onChange={(event) => updateForm("price", event.target.value.replace(/\D/g, ""))}
                    placeholder={kind === "product" ? "Masalan: 3 200 000" : "Masalan: 250 000"}
                    className="h-12 w-full rounded-2xl border border-[#e0e8df] bg-white px-4 pr-16 text-[13px] font-semibold text-[#17211e] outline-none focus:border-[#ff6b35] focus:ring-4 focus:ring-[#ff6b35]/10"
                  />
                  <span className="pointer-events-none absolute right-4 top-1/2 -translate-y-1/2 text-[11px] font-bold text-[#91a098]">so‘m</span>
                </div>
              )}
            </div>

            <div>
              <label htmlFor="district" className="mb-2 block text-[13px] font-extrabold text-[#34443d]">
                Tuman yoki shahar
              </label>
              <div className="relative">
                <select
                  id="district"
                  value={form.district}
                  onChange={(event) => updateForm("district", event.target.value)}
                  className="h-12 w-full appearance-none rounded-2xl border border-[#e0e8df] bg-white px-4 pr-10 text-[13px] font-semibold text-[#34443d] outline-none focus:border-[#ff6b35]"
                >
                  {districts.map((district) => (
                    <option key={district}>{district}</option>
                  ))}
                </select>
                <ChevronDown className="pointer-events-none absolute right-4 top-1/2 h-4 w-4 -translate-y-1/2 text-[#718078]" />
              </div>
              <p className="mt-1.5 text-[10px] text-[#91a098]">Qoraqalpog‘iston tumanlari ro‘yxatidan tanlang.</p>
            </div>

            <div>
              <label htmlFor="description" className="mb-2 block text-[13px] font-extrabold text-[#34443d]">
                Qisqacha izoh <span className="font-medium text-[#a0aca5]">(ixtiyoriy)</span>
              </label>
              <textarea
                id="description"
                value={form.description}
                onChange={(event) => updateForm("description", event.target.value)}
                placeholder={kind === "product" ? "Holati, komplektatsiyasi va siz uchun muhim ma’lumotlar..." : "Tajriba, xizmat hududi va nimalarda yordam berishingizni yozing..."}
                rows={3}
                className="w-full resize-none rounded-2xl border border-[#e0e8df] bg-white px-4 py-3 text-[13px] font-medium leading-5 text-[#17211e] outline-none placeholder:text-[#a0aca5] focus:border-[#ff6b35] focus:ring-4 focus:ring-[#ff6b35]/10"
              />
            </div>

            <div>
              <p className="mb-2.5 text-[13px] font-extrabold text-[#34443d]">Siz bilan qanday bog‘lanishsin?</p>
              <div className="grid grid-cols-2 gap-2">
                {([
                  ["chat", "Bozor chatida", MessageCircle],
                  ["phone", "Telefon orqali", Phone],
                ] as const).map(([value, label, Icon]) => (
                  <button
                    type="button"
                    key={value}
                    onClick={() => updateForm("contact", value)}
                    className={`flex items-center gap-2.5 rounded-xl border p-3 text-left transition ${form.contact === value ? "border-[#ff6b35] bg-[#fff4ee]" : "border-[#e0e8df] bg-white"}`}
                  >
                    <Icon className={`h-4 w-4 ${form.contact === value ? "text-[#ff6b35]" : "text-[#718078]"}`} />
                    <span className="text-[11px] font-bold text-[#34443d]">{label}</span>
                    {form.contact === value && <Check className="ml-auto h-3.5 w-3.5 text-[#ff6b35]" />}
                  </button>
                ))}
              </div>
            </div>
          </section>
        )}

        {step === 3 && (
          <section className="mt-5">
            <div className="mb-4 flex items-center justify-between">
              <div>
                <p className="text-[13px] font-extrabold text-[#34443d]">E’loningiz shunday ko‘rinadi</p>
                <p className="mt-1 text-[11px] text-[#91a098]">Joylashdan oldin bir ko‘z tashlang</p>
              </div>
              <span className="rounded-full bg-[#e8f4eb] px-2.5 py-1 text-[10px] font-extrabold text-[#4b8f64]">Tekshirildi</span>
            </div>
            <div className="overflow-hidden rounded-[24px] border border-[#e0e8df] bg-white shadow-[0_10px_25px_rgba(55,76,62,0.07)]">
              <div className="relative flex h-[170px] items-center justify-center bg-[#ffdcca]">
                <span className="absolute -right-9 -top-10 h-28 w-28 rounded-full bg-white/30" />
                <span className="absolute -bottom-10 -left-8 h-28 w-28 rounded-full bg-[#ff6b35]/15" />
                <div className="relative flex h-24 w-24 items-center justify-center rounded-[28px] bg-white/55 text-[#ff6b35] shadow-sm">
                  {kind === "product" ? <Tag className="h-10 w-10" /> : <Wrench className="h-10 w-10" />}
                </div>
                <span className="absolute bottom-3 left-3 rounded-lg bg-white/80 px-2 py-1 text-[9px] font-bold uppercase tracking-[0.12em] text-[#63736a]">
                  {form.category}
                </span>
                <button type="button" onClick={() => setStep(2)} className="absolute right-3 top-3 flex h-8 items-center gap-1.5 rounded-full bg-white/85 px-3 text-[10px] font-bold text-[#34443d]">
                  <RotateCcw className="h-3 w-3" />
                  Tahrirlash
                </button>
              </div>
              <div className="p-4">
                <div className="flex items-start justify-between gap-3">
                  <h3 className="text-[18px] font-black leading-tight tracking-[-0.035em] text-[#17211e]">{listingName}</h3>
                  <MoreHorizontal className="h-5 w-5 shrink-0 text-[#91a098]" />
                </div>
                <p className="mt-2 text-[17px] font-black text-[#ff6b35]">{priceLabel}</p>
                <div className="mt-3 flex items-center gap-2 text-[11px] font-semibold text-[#718078]">
                  {form.district}
                </div>
                <p className="mt-3 border-t border-[#edf1ec] pt-3 text-[12px] leading-5 text-[#63736a]">
                  {form.description || "Mahsulot yoki xizmat haqida qo‘shimcha ma’lumot shu yerda ko‘rinadi."}
                </p>
                <div className="mt-4 flex items-center justify-between border-t border-[#edf1ec] pt-3">
                  <div className="flex items-center gap-2">
                    <span className="flex h-8 w-8 items-center justify-center rounded-full bg-[#dcebe2] text-[#387156]">
                      <UserRound className="h-4 w-4" />
                    </span>
                    <div>
                      <p className="text-[11px] font-bold text-[#34443d]">Sizning profilingiz</p>
                      <p className="text-[10px] text-[#91a098]">Yangi e’lon beruvchi</p>
                    </div>
                  </div>
                  <span className="flex items-center gap-1 text-[10px] font-bold text-[#4b8f64]">
                    <ShieldCheck className="h-3.5 w-3.5" />
                    Tasdiqlangan
                  </span>
                </div>
              </div>
            </div>

            <div className="mt-4 rounded-[18px] border border-[#dcebe2] bg-[#f1f8f2] p-3.5">
              <div className="flex gap-2.5">
                <ShieldCheck className="mt-0.5 h-4 w-4 shrink-0 text-[#4b8f64]" />
                <p className="text-[11px] leading-4 text-[#557066]">
                  E’loningiz Qoraqalpog‘iston bozorida ko‘rsatiladi. Tanlangan tuman: <strong className="text-[#34443d]">{form.district}</strong>. Shaxsiy ma’lumotlaringizni faqat tanlagan aloqa usulingiz orqali ulashamiz.
                </p>
              </div>
            </div>
          </section>
        )}

        <div className="mt-6 flex gap-2.5">
          {step > 1 && (
            <button
              type="button"
              onClick={() => setStep((current) => (current - 1) as Step)}
              className="flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl border border-[#dfe6df] bg-white text-[#34443d] transition hover:border-[#ff6b35] hover:text-[#ff6b35]"
              aria-label="Oldingi qadam"
            >
              <ArrowLeft className="h-4 w-4" />
            </button>
          )}
          <button
            type="button"
            onClick={goNext}
            className="flex h-12 flex-1 items-center justify-center gap-2 rounded-2xl bg-[#ff6b35] text-[13px] font-extrabold text-white shadow-[0_10px_22px_rgba(255,107,53,0.22)] transition hover:bg-[#f15d27] active:scale-[0.99]"
          >
            {step === 3 ? (
              <>
                <Send className="h-4 w-4" />
                E’lonni joylash
              </>
            ) : (
              <>
                Davom etish
                <ArrowRight className="h-4 w-4" />
              </>
            )}
          </button>
        </div>

        <p className="mt-4 flex items-center justify-center gap-1.5 text-center text-[10px] text-[#91a098]">
          <ShieldCheck className="h-3 w-3 text-[#4b8f64]" />
          Bozor hamjamiyati uchun xavfsiz va ochiq savdo
        </p>
      </div>
    </AppShell>
  );
}
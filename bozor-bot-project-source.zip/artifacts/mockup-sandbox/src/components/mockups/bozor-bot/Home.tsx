import { useMemo, useState } from "react";
import {
  ArrowRight,
  Armchair,
  Baby,
  Bike,
  ChevronRight,
  CircleCheck,
  Filter,
  Heart,
  Home as HomeIcon,
  Search,
  ShieldCheck,
  Shirt,
  Smartphone,
  Sparkles,
  Star,
  Wrench,
  X,
} from "lucide-react";
import {
  AppShell,
  Pill,
  ProductImage,
  SellerAvatar,
  ServiceIcon,
} from "./_shared/AppShell";

type Category = {
  label: string;
  icon: typeof Smartphone;
  tint: string;
};

const categories: Category[] = [
  { label: "Elektronika", icon: Smartphone, tint: "bg-[#e7f2ef] text-[#357466]" },
  { label: "Uy-ro‘zg‘or", icon: Armchair, tint: "bg-[#fff0de] text-[#b8662d]" },
  { label: "Kiyim", icon: Shirt, tint: "bg-[#f0e8f3] text-[#76507c]" },
  { label: "Bolalar", icon: Baby, tint: "bg-[#e8eef5] text-[#4a6b88]" },
  { label: "Transport", icon: Bike, tint: "bg-[#f8ebdc] text-[#9b622d]" },
];

const listings = [
  {
    title: "Samsung Galaxy A54",
    price: "2 150 000 so‘m",
    meta: "Yangi • 2 soat oldin",
    initials: "SA",
    tone: "orange" as const,
    visual: <Smartphone className="h-8 w-8" />,
  },
  {
    title: "Yog‘och yozuv stoli",
    price: "780 000 so‘m",
    meta: "Yaxshi holatda • 4 soat",
    initials: "MI",
    tone: "green" as const,
    visual: <Armchair className="h-8 w-8" />,
  },
  {
    title: "Shahar velosipedi",
    price: "1 050 000 so‘m",
    meta: "Kam ishlatilgan • kecha",
    initials: "AK",
    tone: "blue" as const,
    visual: <Bike className="h-8 w-8" />,
  },
];

export function Home() {
  const [query, setQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("Barchasi");
  const [saved, setSaved] = useState<string[]>([]);
  const [notice, setNotice] = useState("");
  const [filtersOpen, setFiltersOpen] = useState(false);

  const visibleListings = useMemo(() => {
    if (!query.trim()) return listings;
      return listings.filter((listing) =>
      listing.title.toLowerCase().includes(query.toLowerCase()),
    );
  }, [query]);

  const toggleSaved = (title: string) => {
    setSaved((current) =>
      current.includes(title) ? current.filter((item) => item !== title) : [...current, title],
    );
    setNotice(saved.includes(title) ? "Saqlanganlardan olib tashlandi" : "E’lon saqlandi");
    window.setTimeout(() => setNotice(""), 1900);
  };

  return (
    <AppShell active="home" title="Bozor Bot">
      <div className="overflow-hidden">
        <section className="px-5 pb-5 pt-6">
          <div className="mb-5 flex items-end justify-between gap-4">
            <div>
              <p className="mb-1.5 text-[11px] font-bold uppercase tracking-[0.18em] text-[#ff6b35]">
                Assalomu alaykum
              </p>
              <h2 className="max-w-[230px] text-[29px] font-extrabold leading-[1.03] tracking-[-0.065em] text-[#17211e]">
                Qoraqalpog‘istondagi
                <span className="block text-[#357466]">yaxshi topilmalar</span>
              </h2>
            </div>
            <div className="mb-1 rounded-full bg-[#e6f1e9] px-2.5 py-1.5 text-[10px] font-bold text-[#357466]">
              Qoraqalpog‘iston uchun
            </div>
          </div>

          <div className="relative overflow-hidden rounded-[26px] bg-[#173b35] p-5 text-white shadow-[0_14px_28px_rgba(23,59,53,0.16)]">
            <span className="absolute -right-10 -top-12 h-36 w-36 rounded-full border-[16px] border-[#ff9a64]/35" />
            <span className="absolute -bottom-16 right-10 h-36 w-36 rounded-full bg-[#ff6b35]/80" />
            <span className="absolute -bottom-10 -left-8 h-28 w-28 rounded-full border-[12px] border-[#6ba58a]/30" />
            <div className="relative z-10 max-w-[235px]">
              <div className="mb-3 inline-flex items-center gap-1.5 rounded-full bg-white/10 px-2.5 py-1 text-[10px] font-bold tracking-wide text-[#ffd3bf]">
                <Sparkles className="h-3 w-3" />
                Haftaning qulay taklifi
              </div>
              <h3 className="text-[23px] font-extrabold leading-[1.04] tracking-[-0.05em]">
                Uyga kerakli narsa
                <span className="block text-[#ffb08a]">bir qadam narida</span>
              </h3>
              <p className="mt-2 text-[12px] leading-[1.45] text-[#c4d8ce]">
                Ishonchli e’lonlarni toping va bugunoq kelishib oling.
              </p>
              <button
                onClick={() => setNotice("Yaqin takliflar ochildi")}
                className="mt-4 inline-flex items-center gap-2 rounded-full bg-[#ff6b35] px-3.5 py-2.5 text-[11px] font-extrabold text-white transition hover:bg-[#f45c28] active:scale-95"
              >
                Takliflarni ko‘rish
                <ArrowRight className="h-3.5 w-3.5" />
              </button>
            </div>
            <div className="absolute bottom-4 right-5 z-10 flex h-[74px] w-[74px] rotate-6 items-center justify-center rounded-[24px] border border-white/20 bg-[#f2b857] shadow-[0_10px_20px_rgba(0,0,0,0.14)]">
              <HomeIcon className="h-9 w-9 text-[#173b35]" strokeWidth={1.8} />
            </div>
          </div>
        </section>

        <section className="px-5">
          <div className="flex h-[50px] items-center gap-3 rounded-2xl border border-[#e2e9e1] bg-white px-4 shadow-[0_5px_14px_rgba(34,70,52,0.04)] focus-within:border-[#ff9b73] focus-within:ring-4 focus-within:ring-[#ffeadf]">
            <Search className="h-[18px] w-[18px] shrink-0 text-[#7e9187]" />
            <input
              aria-label="E’lon qidirish"
              value={query}
              onChange={(event) => setQuery(event.target.value)}
              placeholder="Nima izlayapsiz?"
              className="min-w-0 flex-1 bg-transparent text-[13px] font-medium text-[#17211e] outline-none placeholder:text-[#91a098]"
            />
            {query && (
              <button
                onClick={() => setQuery("")}
                aria-label="Qidiruvni tozalash"
                className="text-[#91a098] transition hover:text-[#17211e]"
              >
                <X className="h-4 w-4" />
              </button>
            )}
            <button
              onClick={() => setFiltersOpen((open) => !open)}
              aria-label="Filtrlarni ochish"
              className={`flex h-8 w-8 items-center justify-center rounded-xl transition ${
                filtersOpen ? "bg-[#173b35] text-white" : "bg-[#fff1e9] text-[#ff6b35]"
              }`}
            >
              <Filter className="h-4 w-4" />
            </button>
          </div>
          {filtersOpen && (
            <div className="mt-2 flex items-center gap-2 rounded-2xl border border-[#e8eee7] bg-[#fbfcfa] p-2.5">
              <Pill active>Yangi e’lonlar</Pill>
              <Pill icon={<CircleCheck className="h-3 w-3" />}>Tekshirilganlar</Pill>
            </div>
          )}
        </section>

        <section className="mt-6">
          <div className="mb-3 flex items-center justify-between px-5">
            <h3 className="text-[16px] font-extrabold tracking-[-0.03em] text-[#17211e]">Bo‘limlar</h3>
            <button
              onClick={() => setNotice("Barcha bo‘limlar tez orada")}
              className="text-[11px] font-bold text-[#ff6b35] transition hover:text-[#d95320]"
            >
              Barchasi
            </button>
          </div>
          <div className="flex gap-3 overflow-x-auto px-5 pb-1 [scrollbar-width:none] [&::-webkit-scrollbar]:hidden">
            <button
              onClick={() => setSelectedCategory("Barchasi")}
              className="flex min-w-[68px] flex-col items-center gap-2 text-center"
            >
              <span
                className={`flex h-[52px] w-[52px] items-center justify-center rounded-[18px] transition ${
                  selectedCategory === "Barchasi"
                    ? "bg-[#ff6b35] text-white shadow-[0_8px_16px_rgba(255,107,53,0.24)]"
                    : "bg-white text-[#60736a] ring-1 ring-[#e2e9e1]"
                }`}
              >
                <Sparkles className="h-5 w-5" />
              </span>
              <span className="text-[10px] font-bold text-[#63736a]">Barchasi</span>
            </button>
            {categories.map(({ label, icon: Icon, tint }) => (
              <button
                key={label}
                onClick={() => {
                  setSelectedCategory(label);
                  setNotice(`${label} bo‘limi tanlandi`);
                }}
                className="flex min-w-[68px] flex-col items-center gap-2 text-center"
              >
                <span
                  className={`flex h-[52px] w-[52px] items-center justify-center rounded-[18px] transition ${
                    selectedCategory === label ? "ring-2 ring-[#ff6b35] ring-offset-2" : ""
                  } ${tint}`}
                >
                  <Icon className="h-5 w-5" />
                </span>
                <span className="max-w-[68px] text-[10px] font-bold leading-3 text-[#63736a]">
                  {label}
                </span>
              </button>
            ))}
          </div>
        </section>

        <section className="mt-7">
          <div className="mb-3 flex items-end justify-between px-5">
            <div>
              <p className="mb-1 text-[10px] font-bold uppercase tracking-[0.16em] text-[#ff6b35]">
                Sizga yaqin
              </p>
              <h3 className="text-[19px] font-extrabold tracking-[-0.04em] text-[#17211e]">
                Bugungi topilmalar
              </h3>
            </div>
            <button
              onClick={() => setNotice("Barcha e’lonlar ochildi")}
              className="flex items-center gap-0.5 text-[12px] font-extrabold text-[#357466]"
            >
              Hammasi <ChevronRight className="h-4 w-4" />
            </button>
          </div>
          <div className="flex gap-3 overflow-x-auto px-5 pb-2 [scrollbar-width:none] [&::-webkit-scrollbar]:hidden">
            {visibleListings.length ? (
              visibleListings.map((listing) => (
                <article key={listing.title} className="min-w-[190px] max-w-[190px]">
                  <div className="relative">
                    <ProductImage
                      tone={listing.tone}
                      visual={listing.visual}
                      label="yaqin"
                      className="h-[145px] w-full"
                    />
                    <div className="absolute right-2 top-2">
                      <button
                        onClick={() => toggleSaved(listing.title)}
                        aria-label={`${listing.title} ${saved.includes(listing.title) ? "saqlangan" : "saqlash"}`}
                        className={`flex h-9 w-9 items-center justify-center rounded-full transition active:scale-90 ${
                          saved.includes(listing.title)
                            ? "bg-[#fff0e9] text-[#ff6b35]"
                            : "bg-white/90 text-[#34443d]"
                        }`}
                      >
                        <Heart className={`h-4 w-4 ${saved.includes(listing.title) ? "fill-current" : ""}`} />
                      </button>
                    </div>
                  </div>
                  <div className="px-0.5 pt-2.5">
                    <h4 className="truncate text-[13px] font-extrabold text-[#17211e]">{listing.title}</h4>
                    <p className="mt-1 text-[13px] font-extrabold text-[#ff6b35]">{listing.price}</p>
                    <p className="mt-1 truncate text-[10px] font-medium text-[#819089]">{listing.meta}</p>
                    <div className="mt-2 flex items-center gap-1.5">
                      <SellerAvatar initials={listing.initials} />
                       <span className="truncate text-[10px] font-bold text-[#63736a]">Tasdiqlangan sotuvchi</span>
                    </div>
                  </div>
                </article>
              ))
            ) : (
              <div className="flex w-full items-center gap-3 rounded-2xl border border-dashed border-[#d7e2d9] bg-[#fbfcfa] p-4">
                <Search className="h-5 w-5 text-[#8ca096]" />
                <p className="text-[12px] font-medium text-[#63736a]">Bu qidiruv bo‘yicha e’lon topilmadi.</p>
              </div>
            )}
          </div>
        </section>

        <section className="mx-5 mt-7 overflow-hidden rounded-[22px] border border-[#dbeadf] bg-[#eff7f0]">
          <div className="flex items-center gap-3 p-4">
            <ServiceIcon icon={<Wrench className="h-5 w-5" />} />
            <div className="min-w-0 flex-1">
              <p className="text-[10px] font-bold uppercase tracking-[0.14em] text-[#4b8f64]">Xizmat kerakmi?</p>
              <h3 className="mt-1 text-[15px] font-extrabold tracking-[-0.03em] text-[#173b35]">
                 Kerakli ustalarni toping
              </h3>
              <p className="mt-1 text-[11px] leading-4 text-[#6c8275]">Ta’mirlash, tozalash, dars va boshqa xizmatlar.</p>
            </div>
            <button
              onClick={() => setNotice("Xizmatlar bo‘limi ochildi")}
              aria-label="Xizmatlarni ko‘rish"
              className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-[#173b35] text-white transition hover:bg-[#25554c] active:scale-95"
            >
              <ArrowRight className="h-4 w-4" />
            </button>
          </div>
          <div className="flex items-center gap-3 border-t border-[#dbeadf] px-4 py-2.5 text-[10px] font-bold text-[#638070]">
            <ShieldCheck className="h-4 w-4 text-[#4b8f64]" />
             <span>Tekshirilgan xizmat profillari</span>
            <Star className="ml-auto h-3.5 w-3.5 fill-[#f2b857] text-[#f2b857]" />
            <span>4.9</span>
          </div>
        </section>

        <div className="h-4" />
      </div>

      {notice && (
        <div className="fixed bottom-[90px] left-1/2 z-40 flex -translate-x-1/2 items-center gap-2 rounded-full bg-[#173b35] px-4 py-2.5 text-[11px] font-bold text-white shadow-[0_10px_24px_rgba(23,59,53,0.22)]">
          <CircleCheck className="h-3.5 w-3.5 text-[#9ed0a9]" />
          {notice}
        </div>
      )}
    </AppShell>
  );
}
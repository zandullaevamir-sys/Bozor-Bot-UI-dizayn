import { useMemo, useState, type ReactNode } from "react";
import {
  ArrowRight,
  BadgeCheck,
  Banknote,
  BriefcaseBusiness,
  Check,
  ChevronDown,
  Clock3,
  House,
  MessageCircle,
  Phone,
  Plus,
  ShieldCheck,
  Sparkles,
  Star,
  UserRound,
  X,
} from "lucide-react";
import { AppShell, ServiceIcon } from "./_shared/AppShell";

type ContactPreference = "Qo‘ng‘iroq" | "Telegram" | "Xabar";

const categories = ["Uy ta’miri", "Tozalash", "Go‘zallik", "Ta’lim", "Yetkazib berish"];
const skills = ["Santexnika", "Elektrik", "Kafel terish", "Bo‘yash", "Mayda ta’mir"];
const districts = [
  "Nukus shahri",
  "Nukus tumani",
  "Amudaryo tumani",
  "Beruniy tumani",
  "Chimboy tumani",
  "Ellikqal’a tumani",
  "Kegeyli tumani",
  "Mo‘ynoq tumani",
  "Qanliko‘l tumani",
  "Qorao‘zak tumani",
  "Qo‘ng‘irot tumani",
  "Shumanay tumani",
  "Taxtako‘pir tumani",
  "Taxiatosh shahri",
  "To‘rtko‘l tumani",
  "Xo‘jayli tumani",
];

function FieldLabel({ children, optional = false }: { children: ReactNode; optional?: boolean }) {
  return (
    <div className="mb-2 flex items-center justify-between">
      <label className="text-[12px] font-bold tracking-[-0.01em] text-[#26352f]">{children}</label>
      {optional && <span className="text-[10px] font-medium text-[#94a29b]">ixtiyoriy</span>}
    </div>
  );
}

function Choice({
  active,
  children,
  onClick,
}: {
  active: boolean;
  children: ReactNode;
  onClick: () => void;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      aria-pressed={active}
      className={`flex min-h-10 items-center gap-2 rounded-xl border px-3 text-left text-[11px] font-bold transition ${
        active
          ? "border-[#17211e] bg-[#17211e] text-white shadow-[0_5px_12px_rgba(23,33,30,0.14)]"
          : "border-[#e0e8df] bg-white text-[#65756d] hover:border-[#ff6b35] hover:text-[#26352f]"
      }`}
    >
      {active && <Check className="h-3.5 w-3.5 shrink-0" />}
      {children}
    </button>
  );
}

export function ServiceForm() {
  const [step, setStep] = useState(1);
  const [saved, setSaved] = useState(false);
  const [published, setPublished] = useState(false);
  const [name, setName] = useState("Javlon");
  const [category, setCategory] = useState("Uy ta’miri");
  const [selectedSkills, setSelectedSkills] = useState<string[]>(["Santexnika", "Elektrik"]);
  const [offer, setOffer] = useState(
    "Uyda suv quvurlari, kran va elektr mayda ta’mirlarini toza va o‘z vaqtida bajaraman.",
  );
  const [district, setDistrict] = useState("Nukus shahri");
  const [price, setPrice] = useState("80 000");
  const [availability, setAvailability] = useState("Bugun va ertaga");
  const [contact, setContact] = useState<ContactPreference>("Telegram");

  const progress = Math.round((step / 3) * 100);
  const displaySkills = useMemo(() => selectedSkills.slice(0, 3), [selectedSkills]);

  const toggleSkill = (skill: string) => {
    setSelectedSkills((current) =>
      current.includes(skill) ? current.filter((item) => item !== skill) : [...current, skill],
    );
    setSaved(false);
  };

  const goBack = () => {
    if (step > 1) setStep((current) => current - 1);
  };

  const goNext = () => {
    if (step < 3) {
      setStep((current) => current + 1);
      setSaved(false);
    } else {
      setPublished(true);
      setSaved(true);
    }
  };

  return (
    <AppShell
      active="sell"
      title="Xizmat berish"
      showBack
      onBack={goBack}
      rightAction={
        <button
          type="button"
          onClick={() => setSaved(true)}
          className={`rounded-full px-3.5 py-2 text-[11px] font-extrabold transition ${
            saved ? "bg-[#e8f3e9] text-[#3b7851]" : "bg-[#fff0e8] text-[#e45425]"
          }`}
        >
          {saved ? "Saqlandi" : "Saqlash"}
        </button>
      }
    >
      <section className="px-5 pb-5 pt-5">
        <div className="mb-4 flex items-start justify-between gap-4">
          <div>
            <p className="mb-1 flex items-center gap-1.5 text-[10px] font-extrabold uppercase tracking-[0.17em] text-[#ff6b35]">
              <Sparkles className="h-3 w-3" />
              Ustalar uchun
            </p>
            <h2 className="max-w-[275px] text-[26px] font-extrabold leading-[1.03] tracking-[-0.055em] text-[#17211e]">
              Qoraqalpog‘istonda xizmat toping.
            </h2>
            <p className="mt-2 max-w-[300px] text-[13px] leading-[1.45] text-[#718078]">
               O‘zingizni tanishtiring, xizmatlaringizni yozing — mijozlar sizni tez topadi.
            </p>
          </div>
          <div className="relative flex h-14 w-14 shrink-0 items-center justify-center rounded-[19px] bg-[#17211e] text-[#ff8a5d] shadow-[0_10px_22px_rgba(23,33,30,0.18)]">
            <BriefcaseBusiness className="h-6 w-6" />
            <span className="absolute -bottom-1.5 -right-1.5 flex h-6 w-6 items-center justify-center rounded-full border-2 border-[#f6f7f4] bg-[#ff6b35] text-white">
              <Plus className="h-3.5 w-3.5" />
            </span>
          </div>
        </div>

        <div className="rounded-[18px] border border-[#e0e8df] bg-white p-3.5 shadow-[0_5px_18px_rgba(45,65,55,0.04)]">
          <div className="mb-2.5 flex items-center justify-between">
            <span className="text-[10px] font-extrabold uppercase tracking-[0.12em] text-[#6c7d74]">
              Profil tayyorligi
            </span>
            <span className="text-[11px] font-extrabold text-[#ff6b35]">{progress}%</span>
          </div>
          <div className="h-2 overflow-hidden rounded-full bg-[#edf1ec]">
            <div
              className="h-full rounded-full bg-[#ff6b35] transition-all duration-300"
              style={{ width: `${progress}%` }}
            />
          </div>
          <div className="mt-3 flex items-center justify-between text-[10px] font-bold">
            {["Siz haqingizda", "Xizmatlar", "Ko‘rinish"].map((label, index) => (
              <span key={label} className={index + 1 <= step ? "text-[#17211e]" : "text-[#a1ada6]"}>
                <span
                  className={`mr-1 inline-flex h-4 w-4 items-center justify-center rounded-full text-[9px] ${
                    index + 1 <= step ? "bg-[#17211e] text-white" : "bg-[#edf1ec] text-[#8c9b93]"
                  }`}
                >
                  {index + 1}
                </span>
                {label}
              </span>
            ))}
          </div>
        </div>
      </section>

      {step === 1 && (
        <section className="space-y-5 px-5 pb-6">
          <div>
            <FieldLabel>Ismingiz</FieldLabel>
            <div className="flex items-center gap-3 rounded-2xl border border-[#dfe8df] bg-white px-4 py-3 shadow-sm transition focus-within:border-[#ff6b35] focus-within:ring-4 focus-within:ring-[#ff6b35]/10">
              <UserRound className="h-[18px] w-[18px] text-[#ff6b35]" />
              <input
                value={name}
                onChange={(event) => setName(event.target.value)}
                className="min-w-0 flex-1 bg-transparent text-[14px] font-bold text-[#17211e] outline-none placeholder:text-[#a1ada6]"
                placeholder="Masalan, Javlon"
                aria-label="Ismingiz"
              />
            </div>
          </div>
          <div>
            <FieldLabel>Asosiy yo‘nalish</FieldLabel>
            <div className="grid grid-cols-2 gap-2">
              {categories.map((item) => (
                <Choice key={item} active={category === item} onClick={() => setCategory(item)}>
                  {item}
                </Choice>
              ))}
            </div>
          </div>
          <div className="rounded-2xl bg-[#fff0e8] p-4">
            <div className="flex gap-3">
              <ShieldCheck className="mt-0.5 h-5 w-5 shrink-0 text-[#e45425]" />
              <div>
                <p className="text-[12px] font-extrabold text-[#74331f]">Ishonchli profil bo‘ling</p>
                <p className="mt-1 text-[11px] leading-4 text-[#9b5b45]">
                  To‘liq ism va aniq yo‘nalish mijozga tanlov qilishni osonlashtiradi.
                </p>
              </div>
            </div>
          </div>
        </section>
      )}

      {step === 2 && (
        <section className="space-y-5 px-5 pb-6">
          <div>
            <div className="mb-2 flex items-end justify-between">
              <FieldLabel>Qanday ishlarni bilasiz?</FieldLabel>
              <span className="mb-2 text-[10px] font-bold text-[#ff6b35]">{selectedSkills.length} tanlandi</span>
            </div>
            <div className="flex flex-wrap gap-2">
              {skills.map((skill) => (
                <Choice key={skill} active={selectedSkills.includes(skill)} onClick={() => toggleSkill(skill)}>
                  {skill}
                </Choice>
              ))}
            </div>
          </div>
          <div>
            <FieldLabel>Xizmatingiz haqida</FieldLabel>
            <div className="rounded-2xl border border-[#dfe8df] bg-white p-3.5 shadow-sm transition focus-within:border-[#ff6b35] focus-within:ring-4 focus-within:ring-[#ff6b35]/10">
              <textarea
                value={offer}
                onChange={(event) => setOffer(event.target.value)}
                rows={4}
                maxLength={180}
                className="w-full resize-none bg-transparent text-[13px] leading-5 text-[#26352f] outline-none placeholder:text-[#a1ada6]"
                placeholder="Mijozga nimalarda yordam bera olishingizni yozing..."
                aria-label="Xizmatingiz haqida"
              />
              <p className="text-right text-[10px] font-semibold text-[#a1ada6]">{offer.length}/180</p>
            </div>
          </div>
          <div>
             <FieldLabel>Qaysi tuman yoki shaharda ishlaysiz?</FieldLabel>
             <div className="relative">
               <select
                 value={district}
                 onChange={(event) => setDistrict(event.target.value)}
                 aria-label="Tuman yoki shahar"
                 className="h-12 w-full appearance-none rounded-2xl border border-[#dfe8df] bg-white px-4 pr-10 text-[13px] font-bold text-[#26352f] outline-none focus:border-[#ff6b35]"
               >
                 {districts.map((item) => <option key={item}>{item}</option>)}
               </select>
               <ChevronDown className="pointer-events-none absolute right-4 top-1/2 h-4 w-4 text-[#98a69f]" />
             </div>
             <p className="mt-2 text-[10px] font-medium text-[#87958d]">Qoraqalpog‘iston tumanlari ro‘yxatidan tanlang.</p>
          </div>
        </section>
      )}

      {step === 3 && (
        <section className="space-y-5 px-5 pb-6">
          <div className="grid grid-cols-2 gap-3">
            <div>
              <FieldLabel>Boshlang‘ich narx</FieldLabel>
              <div className="flex items-center gap-2 rounded-2xl border border-[#dfe8df] bg-white px-3.5 py-3 shadow-sm transition focus-within:border-[#ff6b35] focus-within:ring-4 focus-within:ring-[#ff6b35]/10">
                <Banknote className="h-[17px] w-[17px] text-[#ff6b35]" />
                <input
                  value={price}
                  onChange={(event) => setPrice(event.target.value)}
                  className="min-w-0 flex-1 bg-transparent text-[13px] font-bold text-[#26352f] outline-none"
                  aria-label="Boshlang'ich narx"
                />
              </div>
              <p className="mt-1.5 text-[10px] font-medium text-[#87958d]">so‘m / xizmat</p>
            </div>
            <div>
              <FieldLabel>Bo‘sh vaqtingiz</FieldLabel>
              <button
                type="button"
                onClick={() => setAvailability(availability === "Bugun va ertaga" ? "Kechki payt" : "Bugun va ertaga")}
                className="flex w-full items-center gap-2 rounded-2xl border border-[#dfe8df] bg-white px-3.5 py-3 text-left shadow-sm transition hover:border-[#ff6b35]"
              >
                <Clock3 className="h-[17px] w-[17px] shrink-0 text-[#ff6b35]" />
                <span className="min-w-0 flex-1 truncate text-[12px] font-bold text-[#26352f]">{availability}</span>
              </button>
              <p className="mt-1.5 text-[10px] font-medium text-[#87958d]">bosib o‘zgartiring</p>
            </div>
          </div>
          <div>
            <FieldLabel>Mijozlar siz bilan qanday bog‘lansin?</FieldLabel>
            <div className="grid grid-cols-3 gap-2">
              {(["Qo‘ng‘iroq", "Telegram", "Xabar"] as ContactPreference[]).map((item) => (
                <Choice key={item} active={contact === item} onClick={() => setContact(item)}>
                  {item === "Qo‘ng‘iroq" && <Phone className="h-3.5 w-3.5" />}
                  {item === "Telegram" && <MessageCircle className="h-3.5 w-3.5" />}
                  {item === "Xabar" && <MessageCircle className="h-3.5 w-3.5" />}
                  <span className="truncate">{item}</span>
                </Choice>
              ))}
            </div>
          </div>

          <div className="rounded-[22px] border border-[#dfe8df] bg-[#fffdf9] p-4 shadow-[0_8px_20px_rgba(45,65,55,0.05)]">
            <div className="mb-3 flex items-center justify-between">
              <div>
                <p className="text-[10px] font-extrabold uppercase tracking-[0.12em] text-[#ff6b35]">Mijoz ko‘radi</p>
                <p className="mt-1 text-[14px] font-extrabold tracking-[-0.02em] text-[#17211e]">Xizmat kartangiz</p>
              </div>
              <BadgeCheck className="h-5 w-5 text-[#4b8f64]" />
            </div>
            <div className="flex gap-3">
              <ServiceIcon icon={<House className="h-5 w-5" />} />
              <div className="min-w-0 flex-1">
                <p className="truncate text-[14px] font-extrabold text-[#17211e]">
                  {name || "Ismingiz"} — {category}
                </p>
                <div className="mt-1 flex items-center gap-1 text-[10px] font-semibold text-[#7b8982]">
                   {district}
                </div>
              </div>
              <div className="flex items-start gap-1 text-[11px] font-extrabold text-[#bd741c]">
                <Star className="h-3.5 w-3.5 fill-current" /> 5.0
              </div>
            </div>
            <p className="mt-3 line-clamp-2 text-[11px] leading-4 text-[#687970]">{offer}</p>
            <div className="mt-3 flex flex-wrap gap-1.5">
              {displaySkills.map((skill) => (
                <span key={skill} className="rounded-md bg-[#edf5ed] px-2 py-1 text-[9px] font-bold text-[#4b7658]">
                  {skill}
                </span>
              ))}
              {selectedSkills.length > 3 && (
                <span className="rounded-md bg-[#f2f3ee] px-2 py-1 text-[9px] font-bold text-[#78867e]">
                  +{selectedSkills.length - 3}
                </span>
              )}
            </div>
          </div>
        </section>
      )}

      <section className="sticky bottom-[78px] z-10 border-t border-[#e6ebe5] bg-[#f6f7f4]/95 px-5 py-3 backdrop-blur-xl">
        {published && (
          <div className="mb-3 flex items-center gap-2 rounded-xl bg-[#eaf5ed] px-3 py-2 text-[11px] font-bold text-[#387651]">
            <Check className="h-4 w-4" />
             Profilingiz joylandi. Endi mijozlar sizni topadi.
            <button type="button" onClick={() => setPublished(false)} className="ml-auto" aria-label="Xabarni yopish">
              <X className="h-3.5 w-3.5" />
            </button>
          </div>
        )}
        <button
          type="button"
          onClick={goNext}
          className="flex h-12 w-full items-center justify-center gap-2 rounded-2xl bg-[#ff6b35] text-[13px] font-extrabold text-white shadow-[0_10px_22px_rgba(255,107,53,0.24)] transition hover:bg-[#e95a27] active:translate-y-px"
        >
          {step < 3 ? "Davom etish" : published ? "Profilni yangilash" : "Profilni joylash"}
          <ArrowRight className="h-4 w-4" />
        </button>
        <p className="mt-2 text-center text-[10px] font-medium text-[#8d9a93]">
          {step < 3 ? "Keyinroq davom ettirish uchun saqlab qo‘ying" : "Joylash bepul, xohlagan payt o‘zgartirasiz"}
        </p>
      </section>
    </AppShell>
  );
}
export function LogoMarket() {
  return (
    <main className="min-h-screen bg-[#f3f8ff] p-8 font-sans text-[#183b5b]">
      <div className="mx-auto flex max-w-sm flex-col items-center justify-center gap-8 rounded-[32px] border border-[#d7e8f4] bg-white p-10 shadow-[0_18px_50px_rgba(57,117,166,0.12)]">
        <div className="text-center">
          <p className="text-[10px] font-black uppercase tracking-[0.25em] text-[#419fe7]">Variant 02 · Market symbol</p>
          <h1 className="mt-2 text-2xl font-black tracking-[-0.06em]">Marketplace first</h1>
          <p className="mt-2 text-sm leading-6 text-[#6f8ca2]">Savdo, xizmat va xarid ma’nosini bir qarashda yetkazadigan belgi.</p>
        </div>

        <div className="relative flex h-44 w-44 items-center justify-center rounded-[46px] bg-[#e3f4ff]">
          <div className="absolute left-10 top-8 h-7 w-20 rounded-t-[18px] border-[5px] border-[#2f83bd] border-b-0" />
          <div className="relative mt-4 h-24 w-28 rounded-[18px] rounded-tl-[10px] rounded-tr-[10px] bg-[#419fe7] shadow-[0_14px_22px_rgba(65,159,231,0.24)]">
            <div className="absolute -left-3 top-0 h-10 w-3 rounded-full bg-[#2f83bd]" />
            <div className="absolute -right-3 top-0 h-10 w-3 rounded-full bg-[#2f83bd]" />
            <div className="absolute left-1/2 top-8 flex h-12 w-16 -translate-x-1/2 items-center justify-center rounded-[18px] bg-[#effaff]">
              <span className="h-3 w-3 rounded-full bg-[#2f83bd]" />
              <span className="ml-3 h-3 w-3 rounded-full bg-[#2f83bd]" />
              <span className="absolute bottom-2 h-1 w-6 rounded-full bg-[#78c8f3]" />
            </div>
          </div>
          <div className="absolute bottom-7 left-12 h-3 w-3 rounded-full bg-[#2f83bd]" />
          <div className="absolute bottom-7 right-12 h-3 w-3 rounded-full bg-[#2f83bd]" />
        </div>

        <div className="text-center">
          <p className="text-2xl font-black tracking-[-0.06em]">Bozor Bot</p>
          <p className="mt-1 text-[10px] font-bold uppercase tracking-[0.22em] text-[#7897ad]">Top. Sot. Xizmat qil.</p>
        </div>
      </div>
    </main>
  );
}
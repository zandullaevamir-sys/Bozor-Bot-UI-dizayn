import { integer, pgTable, serial, text, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";
import { usersTable } from "./users";

export const adConversationsTable = pgTable("ad_conversations", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => usersTable.id),
  subject: text("subject").notNull(),
  status: text("status").notNull().default("open"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow().$onUpdate(() => new Date()),
});

export const insertAdConversationSchema = createInsertSchema(adConversationsTable).omit({ id: true, createdAt: true, updatedAt: true });
export type InsertAdConversation = z.infer<typeof insertAdConversationSchema>;
export type AdConversation = typeof adConversationsTable.$inferSelect;
import { createInsertSchema } from "drizzle-zod";
import { boolean, integer, numeric, pgTable, serial, text, timestamp } from "drizzle-orm/pg-core";
import { z } from "zod/v4";

export const serviceProfilesTable = pgTable("service_profiles", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  title: text("title").notNull(),
  bio: text("bio").notNull(),
  skills: text("skills").array().notNull(),
  category: text("category").notNull(),
  district: text("district").notNull(),
  phone: text("phone").notNull(),
  rating: numeric("rating", { precision: 3, scale: 2, mode: "number" }).notNull().default(5),
  verified: boolean("verified").notNull().default(false),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const insertServiceProfileSchema = createInsertSchema(serviceProfilesTable).omit({
  id: true,
  createdAt: true,
});

export type InsertServiceProfile = z.infer<typeof insertServiceProfileSchema>;
export type ServiceProfile = typeof serviceProfilesTable.$inferSelect;
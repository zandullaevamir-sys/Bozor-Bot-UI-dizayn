import { integer, pgTable, serial, text, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";
import { adConversationsTable } from "./ad-conversations";
import { usersTable } from "./users";

export const adMessagesTable = pgTable("ad_messages", {
  id: serial("id").primaryKey(),
  conversationId: integer("conversation_id").notNull().references(() => adConversationsTable.id, { onDelete: "cascade" }),
  senderId: integer("sender_id").notNull().references(() => usersTable.id),
  body: text("body").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const insertAdMessageSchema = createInsertSchema(adMessagesTable).omit({ id: true, createdAt: true });
export type InsertAdMessage = z.infer<typeof insertAdMessageSchema>;
export type AdMessage = typeof adMessagesTable.$inferSelect;